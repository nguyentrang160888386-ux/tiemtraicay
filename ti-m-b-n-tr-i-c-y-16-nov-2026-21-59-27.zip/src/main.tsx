import './index.css';
import './firebaseCloud';
import './translations_id';
import './portUI';
import './coupleUI';
import './game.js';



