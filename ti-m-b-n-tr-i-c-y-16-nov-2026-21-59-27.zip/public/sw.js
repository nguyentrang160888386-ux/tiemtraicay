/*
 * Tiệm Bán Trái Cây — offline service worker (hand-written, no dependencies).
 *
 * Registered by src/main.tsx in production builds only. At build time the
 * `ttc-sw-manifest` plugin in vite.config.ts rewrites BUILD_ID (a hash of the
 * whole build) and PRECACHE (the app shell + hashed assets + fonts), so every
 * deploy gets a fresh, versioned cache and old caches are deleted.
 *
 * Strategy (same-origin GET only; everything else goes straight to the network):
 *   page navigations  network first (≤ 3.5 s), cached shell when offline / lie-fi,
 *                     so a deploy is picked up as soon as the phone is online
 *   everything else   cache first, then network (and cached for next time)
 *
 * In the dev server this file is served as-is (BUILD_ID 'dev'): it then just
 * removes itself and its caches, so a stale worker can never shadow Vite.
 */
const BUILD_ID = 'dev';
const PRECACHE = ["./apple-touch-icon.png","./assets/be-vietnam-pro-latin-800-normal-BpHZASpI.woff2","./assets/be-vietnam-pro-latin-ext-800-normal-GEpNgheG.woff2","./assets/be-vietnam-pro-vietnamese-800-normal-D4LFh2W4.woff2","./assets/bungee-latin-400-normal-Dfnurram.woff2","./assets/bungee-latin-ext-400-normal-DWzJMwsA.woff2","./assets/bungee-vietnamese-400-normal-B6gKbkHm.woff2","./assets/index-CUVGYWLv.css","./assets/index-DAgH4yHE.js","./assets/pangolin-latin-400-normal-Cx-z2UDT.woff2","./assets/pangolin-latin-ext-400-normal-DrUaq5ce.woff2","./assets/pangolin-vietnamese-400-normal-BOKlOuY0.woff2","./assets/patrick-hand-latin-400-normal-B7HHA2Vw.woff2","./assets/patrick-hand-latin-ext-400-normal-Dno5CMlI.woff2","./assets/patrick-hand-vietnamese-400-normal-65jA92mZ.woff2","./assets/vt323-latin-400-normal-wDgJuOC9.woff2","./assets/vt323-latin-ext-400-normal-iUdYUaX4.woff2","./assets/vt323-vietnamese-400-normal-D0VnvwZ9.woff2","./icon-192.png","./icon-512.png","./icon-maskable-512.png","./icon.svg","./index.html","./manifest.webmanifest"];

const PREFIX = 'ttc-';
const CACHE = PREFIX + BUILD_ID;
const SHELL = ['./', './index.html', './manifest.webmanifest', './icon.svg'];
const NAV_TIMEOUT_MS = 3500;

self.addEventListener('install', (event) => {
  if (BUILD_ID === 'dev') {
    self.skipWaiting();
    return;
  }
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE);
      const urls = [...new Set([...SHELL, ...PRECACHE])];
      // One by one: a single missing file must not abort the whole install.
      await Promise.all(urls.map((u) => cache.add(new Request(u, { cache: 'reload' })).catch(() => undefined)));
      // Activate the new service worker immediately so new deployments take effect without waiting for tabs to close.
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k.startsWith(PREFIX) && k !== CACHE).map((k) => caches.delete(k)));
      if (BUILD_ID === 'dev') {
        await caches.delete(CACHE);
        await self.registration.unregister();
        return;
      }
      await self.clients.claim();
      const clientList = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      for (const client of clientList) {
        client.postMessage({ type: 'TTC_SW_UPDATED', buildId: BUILD_ID });
      }
    })(),
  );
});

self.addEventListener('fetch', (event) => {
  if (BUILD_ID === 'dev') return;
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.endsWith('/version.json') || url.pathname.endsWith('/sw.js')) return;
  if (req.mode === 'navigate') event.respondWith(instantNav(req, event));
  else event.respondWith(cacheFirst(req));
});

async function fromCache(req) {
  const cache = await caches.open(CACHE);
  return (
    (await cache.match(req, { ignoreSearch: true, ignoreVary: true })) ||
    (await cache.match('./index.html', { ignoreVary: true })) ||
    (await cache.match('./', { ignoreVary: true }))
  );
}

async function instantNav(req, event) {
  const cachedPromise = fromCache(req).catch(() => undefined);
  const networkUpdate = fetch(new Request(req, { cache: 'no-store' }))
    .then(async (res) => {
      if (res && res.ok) {
        const cache = await caches.open(CACHE);
        await cache.put(req, res.clone()).catch(() => undefined);
      }
      return res;
    })
    .catch(() => undefined);

  const timeoutPromise = new Promise((resolve) =>
    setTimeout(() => resolve(undefined), NAV_TIMEOUT_MS),
  );

  const fresh = await Promise.race([networkUpdate, timeoutPromise]);
  if (fresh && fresh.ok) {
    return fresh;
  }

  const cached = await cachedPromise;
  if (cached) {
    event.waitUntil(networkUpdate);
    return cached;
  }

  const eventualFresh = await networkUpdate;
  if (eventualFresh) return eventualFresh;

  return new Response(
    '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><body style="font:18px system-ui;padding:24px;background:#f4e6c8">Chưa có mạng — mở lại khi có mạng một lần để tiệm tải về máy nha.</body>',
    { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8' } },
  );
}

async function cacheFirst(req) {
  const cache = await caches.open(CACHE);
  // ignoreVary: module scripts / fonts are CORS-mode requests (Origin header) while the
  // precache was filled without one; a `Vary: Origin` response would never match.
  const hit = await cache.match(req, { ignoreVary: true });
  if (hit) return hit;
  try {
    const res = await fetch(req);
    const ct = (res.headers && res.headers.get('content-type')) || '';
    const isHtmlFallback =
      ct.includes('text/html') && !req.url.endsWith('.html') && !req.url.endsWith('/');
    if (isHtmlFallback) {
      const loose = await cache.match(req, { ignoreSearch: true, ignoreVary: true });
      if (loose) return loose;
      return new Response('', { status: 404, statusText: 'Not Found' });
    }
    if (res.ok && res.type === 'basic') {
      cache.put(req, res.clone()).catch(() => undefined);
    }
    return res;
  } catch (err) {
    const loose = await cache.match(req, { ignoreSearch: true, ignoreVary: true });
    if (loose) return loose;
    throw err;
  }
}
