// Giao diện Kết Hôn & Cửa Hàng Cặp Đôi & Cặp Đôi Đã Kết Hôn (Nâng cấp chuyên nghiệp, sang trọng & ấm áp)
import type { CoupleMilestoneDef, CoupleProposalInfo, CoupleRingDef } from './firebaseCloud';

export interface CoupleUIRuntime {
  U: (type: any, props?: any, key?: any) => any;
  C: any;
  useState: <T>(init: T | (() => T)) => [T, (v: T | ((prev: T) => T)) => void];
  useEffect: (fn: () => void | (() => void), deps?: any[]) => void;
  useRef: <T>(init: T) => { current: T };
  useCloudState: () => any;
  CloudAccountSection: any;
  EB: any;
  cB: any;
  H: { play: (sfx: string) => void };
  G: (text: string, kind?: 'info' | 'good' | 'bad', ms?: number) => void;
  P: (money: number) => string;
  R: (text: string) => string;
  fp: (vi: string, en: string) => string;
  wa: () => string;
}

type CoupleTabId = 'marry' | 'shop';
type MarriedSubTabId = 'home' | 'milestones' | 'shop';

function trC(rt: CoupleUIRuntime, vi: string, en: string, id?: string): string {
  const lang = rt.wa?.() || 'vi';
  if (lang === 'id' && id) return id;
  return rt.fp ? rt.fp(vi, en) : lang === 'en' ? en : vi;
}

function getLoveTier(points: number) {
  if (points >= 6500) {
    return {
      level: 5,
      badge: '👑',
      nameVi: 'Trăm Năm Hạnh Phúc',
      nameEn: '100 Years of Bliss',
      nameId: 'Bahagia Selamanya',
      nextTarget: 6500,
      prevTarget: 3200,
      color: '#ffd23f',
      accent: '#ff6b8b',
    };
  }
  if (points >= 3200) {
    return {
      level: 4,
      badge: '💎',
      nameVi: 'Vợ Chồng Đại Gia',
      nameEn: 'Prosperous Couple',
      nameId: 'Pasangan Sultan',
      nextTarget: 6500,
      prevTarget: 3200,
      color: '#38bdf8',
      accent: '#fbbf24',
    };
  }
  if (points >= 1500) {
    return {
      level: 3,
      badge: '💖',
      nameVi: 'Gắn Kết Keo Sơn',
      nameEn: 'Forever Bonded',
      nameId: 'Ikatan Abadi',
      nextTarget: 3200,
      prevTarget: 1500,
      color: '#fb7185',
      accent: '#fde047',
    };
  }
  if (points >= 600) {
    return {
      level: 2,
      badge: '💞',
      nameVi: 'Tâm Đầu Ý Hợp',
      nameEn: 'Two Hearts One Beat',
      nameId: 'Sehati Sejiwa',
      nextTarget: 1500,
      prevTarget: 600,
      color: '#f472b6',
      accent: '#fcd34d',
    };
  }
  return {
    level: 1,
    badge: '🌸',
    nameVi: 'Mới Yêu Ngọt Ngào',
    nameEn: 'Sweet Beginning',
    nameId: 'Awal yang Manis',
    nextTarget: 600,
    prevTarget: 0,
    color: '#fda4af',
    accent: '#fef08a',
  };
}

// ============================================================
// PIXEL-ART CANVAS: SÂN VƯỜN TÌNH YÊU / TIỆM ĐÔI HẠNH PHÚC
// ============================================================

function CoupleSceneCanvas(props: {
  rt: CoupleUIRuntime;
  isMarried: boolean;
  myShop: string;
  partnerShop: string;
  ringKey: string;
  heartBurstRef: { current: number };
}) {
  const { rt, isMarried, ringKey, heartBurstRef } = props;
  const { U, useRef, useEffect } = rt;
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;

    const W = 220;
    const H = 82;

    const pxOn = (c: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, color: string) => {
      c.fillStyle = color;
      c.fillRect(x | 0, y | 0, w | 0, h | 0);
    };

    const drawMiniHeartOn = (c: CanvasRenderingContext2D, cx: number, cy: number, color: string, outline = '#4a0e20') => {
      const x = cx | 0;
      const y = cy | 0;
      pxOn(c, x - 2, y - 2, 2, 1, outline);
      pxOn(c, x + 1, y - 2, 2, 1, outline);
      pxOn(c, x - 3, y - 1, 7, 2, color);
      pxOn(c, x - 2, y + 1, 5, 1, color);
      pxOn(c, x - 1, y + 2, 3, 1, color);
      pxOn(c, x, y + 3, 1, 1, color);
      pxOn(c, x - 2, y - 1, 1, 1, '#fff5f8');
    };

    const drawMiniShopOn = (c: CanvasRenderingContext2D, x: number, y: number, awning1: string, awning2: string, bodyColor: string) => {
      pxOn(c, x - 2, y + 30, 44, 3, 'rgba(30, 12, 20, 0.35)');
      pxOn(c, x, y + 10, 40, 21, '#2b1d16');
      pxOn(c, x + 2, y + 12, 36, 17, bodyColor);
      pxOn(c, x + 5, y + 15, 30, 8, '#3a2318');
      pxOn(c, x + 6, y + 16, 28, 6, '#ffe9a8');
      pxOn(c, x + 7, y + 20, 6, 3, '#ff6b6b');
      pxOn(c, x + 14, y + 20, 6, 3, '#ffd23f');
      pxOn(c, x + 21, y + 20, 6, 3, '#7cc456');
      pxOn(c, x + 28, y + 20, 5, 3, '#ff9e1c');
      pxOn(c, x + 4, y + 23, 32, 6, '#9a622c');
      pxOn(c, x + 5, y + 24, 30, 2, '#c88a4b');
      pxOn(c, x - 3, y + 3, 46, 9, '#2b1d16');
      for (let i = 0; i < 7; i++) {
        pxOn(c, x - 1 + i * 6, y + 5, 6, 5, i % 2 === 0 ? awning1 : awning2);
        pxOn(c, x - 1 + i * 6, y + 10, 5, 1, i % 2 === 0 ? awning1 : awning2);
      }
      pxOn(c, x + 8, y - 2, 24, 6, '#2b1d16');
      pxOn(c, x + 9, y - 1, 22, 4, '#ffd23f');
      pxOn(c, x + 11, y, 18, 2, '#a31428');
    };

    // Pre-render static scenery once to an offscreen canvas (eliminates per-frame gradient/shop/arch overhead)
    const bgCanvas = document.createElement('canvas');
    bgCanvas.width = W;
    bgCanvas.height = H;
    const bgCtx = bgCanvas.getContext('2d');
    if (bgCtx) {
      bgCtx.imageSmoothingEnabled = false;
      const skyGrad = bgCtx.createLinearGradient(0, 0, 0, H);
      if (isMarried) {
        skyGrad.addColorStop(0, '#4a0e28');
        skyGrad.addColorStop(0.55, '#8c1d46');
        skyGrad.addColorStop(1, '#d94862');
      } else {
        skyGrad.addColorStop(0, '#2e1636');
        skyGrad.addColorStop(0.58, '#6b2246');
        skyGrad.addColorStop(1, '#b83b5e');
      }
      bgCtx.fillStyle = skyGrad;
      bgCtx.fillRect(0, 0, W, H);

      bgCtx.fillStyle = isMarried ? 'rgba(255, 226, 138, 0.20)' : 'rgba(255, 210, 140, 0.14)';
      bgCtx.beginPath();
      bgCtx.arc(W / 2, 34, 28, 0, Math.PI * 2);
      bgCtx.fill();
      bgCtx.fillStyle = isMarried ? 'rgba(255, 238, 170, 0.32)' : 'rgba(255, 226, 160, 0.24)';
      bgCtx.beginPath();
      bgCtx.arc(W / 2, 34, 19, 0, Math.PI * 2);
      bgCtx.fill();

      // Lantern strings
      for (let i = 0; i < 9; i++) {
        const sx = 12 + i * 24;
        const sy = 6 + Math.round(Math.sin(i * 0.8) * 3);
        const lanternDrop = Math.round(Math.sin(i * 0.45) * 4);
        pxOn(bgCtx, sx, 3, 1, sy + lanternDrop - 2, 'rgba(255, 215, 106, 0.35)');
      }

      // Cobblestone courtyard
      pxOn(bgCtx, 0, 62, W, 20, '#3d2228');
      pxOn(bgCtx, 0, 62, W, 3, '#6e3b44');
      pxOn(bgCtx, 0, 65, W, 17, '#522e36');
      for (let gx = 4; gx < W; gx += 16) {
        pxOn(bgCtx, gx, 68, 10, 3, '#683b45');
        pxOn(bgCtx, gx + 6, 74, 10, 3, '#45242b');
      }

      // Red carpet
      pxOn(bgCtx, W / 2 - 22, 63, 44, 19, '#8a1222');
      pxOn(bgCtx, W / 2 - 20, 63, 40, 19, '#c81e32');
      pxOn(bgCtx, W / 2 - 18, 63, 2, 19, '#ffd23f');
      pxOn(bgCtx, W / 2 + 16, 63, 2, 19, '#ffd23f');

      // Left & Right mini fruit shops
      drawMiniShopOn(bgCtx, 10, 33, '#e23b2e', '#fffdf4', '#fff5d6');
      drawMiniShopOn(bgCtx, W - 50, 33, '#f7c844', '#2f7a3a', '#fff5d6');

      // Floral Wedding Arch
      const ax = W / 2 - 22;
      const ay = 18;
      pxOn(bgCtx, ax + 2, ay + 12, 5, 34, '#5c2818');
      pxOn(bgCtx, ax + 3, ay + 12, 3, 34, '#fffdf4');
      pxOn(bgCtx, ax + 37, ay + 12, 5, 34, '#5c2818');
      pxOn(bgCtx, ax + 38, ay + 12, 3, 34, '#fffdf4');
      pxOn(bgCtx, ax, ay + 6, 44, 8, '#1f5226');
      pxOn(bgCtx, ax + 4, ay + 2, 36, 6, '#2f7a3a');
      pxOn(bgCtx, ax + 10, ay, 24, 4, '#4fae45');
      const flowerPositions = [
        [ax + 2, ay + 8, '#ff6b8b'],
        [ax + 8, ay + 4, '#ffd23f'],
        [ax + 15, ay + 1, '#ff4d6d'],
        [ax + 22, ay + 1, '#fff5f8'],
        [ax + 29, ay + 1, '#ff4d6d'],
        [ax + 35, ay + 4, '#ffd23f'],
        [ax + 40, ay + 8, '#ff6b8b'],
      ];
      for (const [fx, fy, fc] of flowerPositions) {
        pxOn(bgCtx, fx as number, fy as number, 3, 3, fc as string);
        pxOn(bgCtx, (fx as number) + 1, (fy as number) + 1, 1, 1, '#fffdf6');
      }
    }

    const px = (x: number, y: number, w: number, h: number, color: string) => pxOn(ctx, x, y, w, h, color);
    const drawMiniHeart = (cx: number, cy: number, color: string, outline = '#4a0e20') => drawMiniHeartOn(ctx, cx, cy, color, outline);

    const drawCharacter = (x: number, y: number, shirt: string, hair: string, isBride: boolean, bob: number) => {
      const by = (y + bob) | 0;
      px(x + 2, y + 14, 3, 4, '#2b1d16');
      px(x + 7, y + 14, 3, 4, '#2b1d16');
      px(x, by + 7, 12, 8, '#2b1d16');
      px(x + 1, by + 8, 10, 6, shirt);
      if (isBride) {
        px(x + 3, by + 8, 6, 2, '#fff5f8');
        px(x + 4, by + 10, 4, 4, '#ffd23f');
      } else {
        px(x + 5, by + 8, 2, 5, '#ffd23f');
      }
      px(x + 1, by, 10, 8, '#2b1d16');
      px(x + 2, by + 1, 8, 6, '#ffdfb8');
      px(x + 1, by - 1, 10, 3, hair);
      if (isBride) {
        px(x, by + 1, 2, 5, hair);
        px(x + 10, by + 1, 2, 5, hair);
        px(x + 4, by - 2, 4, 2, '#ffd23f');
        px(x + 5, by - 3, 2, 1, '#ff4d6d');
      }
      px(x + 3, by + 4, 1, 2, '#2b1d16');
      px(x + 8, by + 4, 1, 2, '#2b1d16');
      px(x + 2, by + 5, 1, 1, '#ff8da6');
      px(x + 9, by + 5, 1, 1, '#ff8da6');
    };

    const particles: Array<{ x: number; y: number; vx: number; vy: number; c: string; s: number; seed: number }> = [];
    for (let i = 0; i < 10; i++) {
      particles.push({
        x: 18 + ((i * 19) % (W - 36)),
        y: 12 + ((i * 23) % (H - 28)),
        vx: (i % 2 === 0 ? 1 : -1) * 0.25,
        vy: -0.45 - (i % 3) * 0.15,
        c: i % 3 === 0 ? '#ffd23f' : i % 2 === 0 ? '#ff6b8b' : '#ffb3c6',
        s: i % 3 === 0 ? 2 : 1,
        seed: i,
      });
    }

    let rafId = 0;
    let lastDraw = 0;
    const startMs = typeof performance !== 'undefined' ? performance.now() : Date.now();
    const ay = 18;

    const render = (now: number) => {
      rafId = window.requestAnimationFrame(render);
      if (typeof document !== 'undefined' && document.hidden) return;
      if (lastDraw && now - lastDraw < 66) return; // ~15fps crisp pixel cadence (low CPU/GPU)
      lastDraw = now;

      const t = (now - startMs) * 0.001;
      ctx.drawImage(bgCanvas, 0, 0);

      // Twinkling lanterns
      for (let i = 0; i < 9; i++) {
        const sx = 12 + i * 24;
        const sy = 6 + Math.round(Math.sin(i * 0.8) * 3);
        const lanternDrop = Math.round(Math.sin(i * 0.45) * 4);
        const glow = (Math.sin(t * 2.5 + i) + 1) * 0.5;
        px(sx - 2, sy + lanternDrop, 5, 5, glow > 0.5 ? '#ffd23f' : '#ff9e1c');
        px(sx - 1, sy + lanternDrop + 1, 3, 3, '#fff6c9');
        px(sx - 1, sy + lanternDrop - 1, 3, 1, '#5c1808');
      }

      // Center Emblem
      const bobCenter = Math.round(Math.sin(t * 2.8) * 1.2);
      if (isMarried) {
        px(W / 2 - 7, ay + 8 + bobCenter, 14, 12, '#5c1808');
        px(W / 2 - 6, ay + 9 + bobCenter, 12, 10, '#ffd23f');
        drawMiniHeart(W / 2, ay + 13 + bobCenter, '#d91e36');
      } else {
        const ringColor = ringKey === 'diamond' ? '#ff4d6d' : ringKey === 'gold' ? '#ffd23f' : '#e2e8f0';
        px(W / 2 - 6, ay + 11 + bobCenter, 12, 9, '#7a1224');
        px(W / 2 - 5, ay + 12 + bobCenter, 10, 7, '#b81d33');
        px(W / 2 - 3, ay + 9 + bobCenter, 6, 5, ringColor);
        px(W / 2 - 1, ay + 7 + bobCenter, 2, 2, '#ffffff');
      }

      // Characters in center
      const bob1 = Math.sin(t * 3.5) > 0 ? -1 : 0;
      const bob2 = Math.sin(t * 3.5 + 1.4) > 0 ? -1 : 0;
      drawCharacter(W / 2 - 16, 46, '#d92638', '#2b1d16', false, bob1);
      drawCharacter(W / 2 + 4, 46, '#e83b5a', '#3a1f16', true, bob2);

      // Floating heart between couple
      const heartY = 38 + Math.round(Math.sin(t * 3.2) * 1.5);
      drawMiniHeart(W / 2, heartY, '#ff4d6d');

      // Lightweight floating particles (deterministic wrap, zero random churn)
      const burstActive = now - (heartBurstRef.current || 0) < 1800;
      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy * (burstActive ? 1.8 : 1);
        if (p.y < 6 || p.x < 10 || p.x > W - 10) {
          p.y = H - 14;
          p.x = 20 + ((p.seed * 29 + Math.floor(t * 17)) % (W - 40));
        }
        if (burstActive && p.seed % 2 === 0) {
          drawMiniHeart(p.x, p.y, '#ff4d6d');
        } else {
          px(p.x, p.y, p.s, p.s, p.c);
        }
      }
    };

    rafId = window.requestAnimationFrame(render);
    return () => window.cancelAnimationFrame(rafId);
  }, [isMarried, ringKey]);

  return U('div', {
    class: 'cp-stage-wrap',
    children: [
      U('canvas', {
        ref: canvasRef,
        width: 220,
        height: 82,
        class: 'cp-stage-canvas pixel',
      }),
      U('div', {
        class: 'cp-stage-overlay',
        children: isMarried
          ? [
              U('span', { class: 'cp-stage-pill left', children: `🏪 ${props.myShop}` }),
              U('span', { class: 'cp-stage-pill mid', children: '💞' }),
              U('span', { class: 'cp-stage-pill right', children: `🏪 ${props.partnerShop}` }),
            ]
          : [
              U('span', {
                class: 'cp-stage-banner',
                children: `✨ ${trC(rt, 'Kết Duyên Chủ Tiệm · Chung Tay Xây Đắp Quầy Quả', 'Unite Shop Owners · Grow Together in Love', 'Jodoh Pemilik Toko · Membangun Toko Bersama')} ✨`,
              }),
            ],
      }),
    ],
  });
}

// ============================================================
// MÀN HÌNH CHÍNH: COUPLE MODAL (KẾT HÔN, CỬA HÀNG & ĐÃ KẾT HÔN)
// ============================================================

export function renderCoupleModal(props: { open?: boolean; inline?: boolean; onClose?: () => void }, rt: CoupleUIRuntime) {
  const { U, C, useState, useEffect, useRef, useCloudState, CloudAccountSection, EB, cB, H, G, P, R } = rt;
  const t = useCloudState();

  const [tab, setTab] = useState<CoupleTabId>('marry');
  const [marriedTab, setMarriedTab] = useState<MarriedSubTabId>('home');
  const [codeInput, setCodeInput] = useState('');
  const [copied, setCopied] = useState(false);
  const [divorceStep, setDivorceStep] = useState(false);
  const [, setCdTick] = useState(0);
  const heartBurstRef = useRef<number>(0);

  const user = t?.user;
  const busy = !!t?.coupleBusy || !!t?.syncing;
  const shop = t?.getShopSnapshot?.() || {
    hasShop: false,
    shopName: R('Tiệm Trái Cây'),
    level: 1,
    money: 0,
    day: 1,
    owner: 'anh',
    ownedRings: [],
  };
  const curLevel = Math.max(1, shop.level || 1);
  const unlocked = curLevel >= 2;
  const myCode = t?.marryCode || '';
  const ownedRings: string[] = t?.ownedRings || [];
  const rings: CoupleRingDef[] = t?.coupleRings || [];
  const milestones: CoupleMilestoneDef[] = t?.coupleMilestones || [];
  const claimed: number[] = t?.coupleClaimedMilestones || [];
  const cs = t?.coupleState || { status: 'single' };
  const isMarried = cs.status === 'married' && !!cs.partnerUid;
  const outProp: CoupleProposalInfo | null = t?.outgoingProposal || null;
  const inProps: CoupleProposalInfo[] = t?.incomingProposals || [];
  const selectedRingId: string =
    t?.selectedRingId && ownedRings.includes(t.selectedRingId)
      ? t.selectedRingId
      : ownedRings[ownedRings.length - 1] || t?.selectedRingId || 'ring_silver';
  const marriedDays: number = t?.getMarriedDays?.() || 1;
  const totalHearts: number = t?.getTotalCoupleHearts?.() || 0;
  const totalPoints: number = t?.getTotalCouplePoints?.() || 0;
  const dailyRem: { freeLeft: number; giftLeft: number } = t?.getDailyHeartRemaining?.() || { freeLeft: 3, giftLeft: 3 };
  const lastGiftText: string = t?.lastPartnerGiftText || '';
  const marriedRing: CoupleRingDef = t?.getRingDef?.(cs.ringId) || rings[0];
  const selectedRingDef: CoupleRingDef = t?.getRingDef?.(selectedRingId) || rings[0];
  const cooldownMs: number = t?.getCoupleCooldownRemainingMs?.() || 0;
  const inCooldown = cooldownMs > 0;
  const cooldownStr: string = t?.formatCoupleCooldown?.(rt.wa?.() !== 'vi' ? 'en' : 'vi') || '24h';

  const myHeartsSent = Number(cs.myHeartsSent) || 0;
  const myPointsSent = Number(cs.myPointsSent) || 0;
  const partnerHeartsRec = Number(t?.partnerHeartsReceived) || 0;
  const partnerPointsRec = Number(t?.partnerPointsReceived) || 0;

  useEffect(() => {
    if (!props.open) return;
    t?.setRealtimeViewOpen?.('couple', true);
    t?.refreshCoupleState?.();
    const tm = inCooldown ? setInterval(() => setCdTick((x) => x + 1), 15000) : null;
    return () => {
      if (tm) clearInterval(tm);
      t?.setRealtimeViewOpen?.('couple', false);
    };
  }, [props.open, inCooldown]);

  if (!props.open) return null;

  const copyCode = () => {
    if (!myCode) return;
    H.play('tap');
    const u = typeof window !== 'undefined' ? window.location.href.split('?')[0].split('#')[0] : '';
    const shareText = trC(
      rt,
      `Vào game Tiệm Bán Trái Cây kết hôn và mở tiệm cặp đôi cùng mình nha! 💍💕\nMã kết hôn của mình: ${myCode}\n👉 Vào game ngay tại: ${u}`,
      `Play The Saigon Fruit Shop, marry me and run our couple shop together! 💍💕\nMy marriage code: ${myCode}\n👉 Play now at: ${u}`,
      `Ayo main Toko Buah Saigon, menikah dan kelola toko pasangan bersamaku! 💍💕\nKode nikahku: ${myCode}\n👉 Main di: ${u}`
    );
    try {
      if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(shareText);
      } else {
        throw 0;
      }
    } catch {
      try {
        const el = document.createElement('textarea');
        el.value = shareText;
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
      } catch {}
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    G(
      trC(
        rt,
        'Đã sao chép lời mời & Mã Kết Hôn!',
        'Copied invitation & Marriage Code!',
        'Undangan & Kode Nikah berhasil disalin!'
      ),
      'good',
      2400
    );
  };

  const copyCodeOnly = () => {
    if (!myCode) return;
    H.play('tap');
    try {
      navigator.clipboard?.writeText?.(myCode);
    } catch {}
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    G(trC(rt, `Đã sao chép mã: ${myCode}`, `Copied code: ${myCode}`, `Kode disalin: ${myCode}`), 'good', 2000);
  };

  const onSelectRing = (id: string) => {
    H.play('tap');
    if (t) {
      t.selectedRingId = id;
      t.emit?.();
    }
  };

  const onBuyRing = async (rId: string) => {
    if (busy) return;
    H.play('tap');
    const ok = await t?.buyCoupleRing?.(rId);
    if (ok) {
      heartBurstRef.current = typeof performance !== 'undefined' ? performance.now() : Date.now();
    }
  };

  const onPropose = async () => {
    if (busy) return;
    H.play('tap');
    const ok = await t?.sendMarriageProposal?.(codeInput, selectedRingId);
    if (ok) {
      setCodeInput('');
      heartBurstRef.current = typeof performance !== 'undefined' ? performance.now() : Date.now();
    }
  };

  const onCancelProp = async () => {
    if (busy) return;
    H.play('tap');
    await t?.cancelMarriageProposal?.();
  };

  const onAcceptProp = async (p: CoupleProposalInfo) => {
    if (busy) return;
    H.play('tap');
    const ok = await t?.acceptMarriageProposal?.(p);
    if (ok) {
      heartBurstRef.current = typeof performance !== 'undefined' ? performance.now() : Date.now();
    }
  };

  const onDeclineProp = async (p: CoupleProposalInfo) => {
    if (busy) return;
    H.play('tap');
    await t?.declineMarriageProposal?.(p);
  };

  const onSendHeart = async (kind: 'free' | 'gift') => {
    if (busy) return;
    H.play('tap');
    const ok = await t?.sendCoupleHeart?.(kind);
    if (ok) {
      heartBurstRef.current = typeof performance !== 'undefined' ? performance.now() : Date.now();
    }
  };

  const onClaimMilestone = async (m: CoupleMilestoneDef) => {
    if (busy) return;
    H.play('tap');
    await t?.claimCoupleMilestone?.(m.id);
  };

  const onConfirmDivorce = async () => {
    if (busy) return;
    H.play('tap');
    const ok = await t?.divorceCouple?.();
    if (ok) setDivorceStep(false);
  };

  const fmtDate = (ms?: number) => {
    if (!ms) return '---';
    try {
      const d = new Date(ms);
      const pad = (n: number) => String(n).padStart(2, '0');
      return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
    } catch {
      return '---';
    }
  };

  const loveTier = getLoveTier(totalPoints);
  const claimableCount = milestones.filter((m) => !claimed.includes(m.id) && totalPoints >= m.targetPoints).length;

  // ============================================================
  // RENDER: CỬA HÀNG CẶP ĐÔI (NHẪN CẦU HÔN & VẬT PHẨM TÌNH YÊU)
  // ============================================================
  const renderShopSection = (isMarriedMode = false) => {
    const ringStyles: Record<
      string,
      {
        tierBadgeVi: string;
        tierBadgeEn: string;
        gradient: string;
        borderColor: string;
        pedestalBg: string;
        glowColor: string;
        tagColor: string;
        perkVi: string;
        perkEn: string;
      }
    > = {
      ring_silver: {
        tierBadgeVi: 'BẠC THANH KHIẾT',
        tierBadgeEn: 'PURE SILVER',
        gradient: 'linear-gradient(135deg, #ffffff 0%, #f1f5f9 100%)',
        borderColor: '#475569',
        pedestalBg: 'radial-gradient(circle at 50% 35%, #ffffff 0%, #dbeafe 65%, #94a3b8 100%)',
        glowColor: '#64748b',
        tagColor: '#334155',
        perkVi: 'Khởi đầu nhẹ nhàng · Đính ngọc hoa bưởi thơm ngát',
        perkEn: 'Sweet start · Fragrant pomelo blossom gem',
      },
      ring_gold: {
        tierBadgeVi: 'VÀNG 24K PHÚ QUÝ',
        tierBadgeEn: 'ROYAL 24K GOLD',
        gradient: 'linear-gradient(135deg, #fffdf0 0%, #fef3c7 100%)',
        borderColor: '#b45309',
        pedestalBg: 'radial-gradient(circle at 50% 35%, #fffbeb 0%, #fde68a 60%, #f59e0b 100%)',
        glowColor: '#d97706',
        tagColor: '#92400e',
        perkVi: 'Được yêu thích nhất · Vàng ròng óng ánh tài lộc',
        perkEn: 'Most Popular · Gleaming 24K gold of prosperity',
      },
      ring_diamond: {
        tierBadgeVi: 'KIM CƯƠNG VĨNH CỬU',
        tierBadgeEn: 'ETERNAL RUBY DIAMOND',
        gradient: 'linear-gradient(135deg, #fff5f7 0%, #ffe4e6 55%, #fef3c7 100%)',
        borderColor: '#be123c',
        pedestalBg: 'radial-gradient(circle at 50% 35%, #fff1f2 0%, #fecdd3 55%, #f43f5e 100%)',
        glowColor: '#e11d48',
        tagColor: '#9f1239',
        perkVi: 'Đẳng cấp Đại Gia · Mở khóa ngay Mốc Thưởng #1 (200K)!',
        perkEn: 'Supreme Luxury · Instantly unlocks Milestone #1 (200K)!',
      },
    };

    return U('div', {
      class: 'cp-section-stack',
      children: [
        // Banner tiệm kim hoàn
        U('div', {
          class: 'cp-boutique-banner',
          children: [
            U('div', {
              class: 'cp-boutique-banner-top',
              children: [
                U('div', {
                  class: 'cp-boutique-title-wrap',
                  children: [
                    U('span', { class: 'cp-boutique-kicker', children: trC(rt, 'TIỆM KIM HOÀN & QUÀ CẶP ĐÔI', 'JEWELRY & COUPLE BOUTIQUE', 'BUTIK CINCIN & PASANGAN') }),
                    U('h4', { class: 'cp-boutique-title', children: trC(rt, 'Bộ Sưu Tập Nhẫn Cầu Hôn', 'Wedding Ring Collection', 'Koleksi Cincin Pernikahan') }),
                  ],
                }),
                U('div', {
                  class: 'cp-wallet-pill',
                  children: [
                    U('small', { children: trC(rt, 'Két tiệm', 'Shop Cash', 'Kas Toko') }),
                    U('b', { children: P(shop.money) }),
                  ],
                }),
              ],
            }),
            U('p', {
              class: 'cp-boutique-desc',
              children: trC(
                rt,
                'Người gửi lời cầu hôn cần có 1 chiếc Nhẫn trong túi. Nhẫn chỉ trừ khi đối phương bấm Đồng Ý! Nhẫn càng cao cấp, Điểm Thân Mật khởi đầu càng lớn.',
                'Proposer needs 1 Ring in bag. The ring is only consumed when your partner accepts! Higher tier rings grant massive starting Love Points.',
                'Pengaju perlu 1 Cincin di tas. Cincin hanya terpakai saat pasangan menerima!'
              ),
            }),
          ],
        }),

        // Danh sách 3 Nhẫn trưng bày trên bệ nhung
        U('div', {
          class: 'cp-ring-showcase',
          children: rings.map((r) => {
            const owned = ownedRings.includes(r.id);
            const isEquippedMarried = isMarried && cs.ringId === r.id;
            const isSelected = !isMarried && owned && selectedRingId === r.id;
            const canBuy = unlocked && !owned && shop.hasShop && shop.money >= r.price;
            const st = ringStyles[r.id] || ringStyles.ring_gold;

            return U(
              'div',
              {
                class: `cp-ring-card ${r.key} ${owned || isEquippedMarried ? 'owned' : ''} ${isSelected ? 'selected' : ''}`,
                style: { background: st.gradient },
                children: [
                  U('div', {
                    class: 'cp-ring-card-ribbon',
                    children: [
                      U('span', {
                        class: `cp-ring-tier-tag ${r.key}`,
                        children: trC(rt, st.tierBadgeVi, st.tierBadgeEn),
                      }),
                      isEquippedMarried
                        ? U('span', {
                            class: 'cp-ring-status-badge married',
                            children: `💍 ${trC(rt, 'Nhẫn Đính Ước', 'Wedding Ring', 'Cincin Nikah')}`,
                          })
                        : owned
                        ? U('span', {
                            class: 'cp-ring-status-badge owned',
                            children: `✓ ${trC(rt, 'Đã có trong túi', 'In Your Bag', 'Di Tas')}`,
                          })
                        : U('span', {
                            class: 'cp-ring-bonus-pill',
                            children: `+${r.bonusPoints} ${trC(rt, 'Điểm 💕', 'Love Pts 💕', 'Poin 💕')}`,
                          }),
                    ],
                  }),

                  U('div', {
                    class: 'cp-ring-card-main',
                    children: [
                      // Bệ nhung trưng bày nhẫn
                      U('div', {
                        class: `cp-ring-pedestal ${r.key}`,
                        style: { background: st.pedestalBg },
                        children: [
                          U('div', { class: 'cp-ring-halo' }),
                          U(EB, { id: r.sprite, px: 38 }),
                          U('div', { class: 'cp-ring-cushion' }),
                        ],
                      }),

                      // Thông tin nhẫn
                      U('div', {
                        class: 'cp-ring-info',
                        children: [
                          U('div', {
                            class: 'cp-ring-name',
                            children: trC(rt, r.name, r.nameEn),
                          }),
                          U('div', {
                            class: 'cp-ring-desc',
                            children: trC(rt, r.desc, r.descEn),
                          }),
                          U('div', {
                            class: 'cp-ring-perk',
                            children: `✨ ${trC(rt, st.perkVi, st.perkEn)}`,
                          }),
                        ],
                      }),
                    ],
                  }),

                  U('div', {
                    class: 'cp-ring-card-foot',
                    children: [
                      U('div', {
                        class: 'cp-ring-price-col',
                        children: [
                          U('small', { children: trC(rt, 'Giá niêm yết', 'Boutique Price', 'Harga') }),
                          U('b', { class: 'cp-ring-price-val', children: P(r.price) }),
                        ],
                      }),
                      U('button', {
                        type: 'button',
                        disabled: (!canBuy && !owned) || busy,
                        onClick: () => {
                          if (owned) {
                            onSelectRing(r.id);
                            if (!isMarriedMode) setTab('marry');
                          } else {
                            onBuyRing(r.id);
                          }
                        },
                        class: `cp-action-btn ${owned ? 'green' : canBuy ? 'gold' : 'disabled'}`,
                        children: owned
                          ? isMarriedMode
                            ? trC(rt, '✓ Đã sở hữu', '✓ Owned', '✓ Dimiliki')
                            : isSelected
                            ? trC(rt, '💍 Đang chọn cầu hôn ›', '💍 Selected Ring ›', '💍 Dipilih ›')
                            : trC(rt, 'Chọn nhẫn này ›', 'Select Ring ›', 'Pilih Cincin ›')
                          : !unlocked
                          ? trC(rt, '🔒 Mở ở Cấp 2', '🔒 Lv.2 Required', '🔒 Buka Lv.2')
                          : shop.money < r.price
                          ? trC(rt, 'Chưa đủ tiền', 'Not enough cash', 'Uang kurang')
                          : trC(rt, '🛒 Mua Nhẫn Ngay', '🛒 Buy Ring', '🛒 Beli Cincin'),
                      }),
                    ],
                  }),
                ],
              },
              r.id
            );
          }),
        }),

        // Quầy Quà Tặng Hằng Ngày
        U('div', {
          class: 'cp-card cp-gift-showcase-card',
          children: [
            U('div', {
              class: 'cp-card-head',
              children: [
                U('span', {
                  class: 'cp-card-title',
                  children: [
                    U(EB, { id: 'ui.love_basket', px: 18 }),
                    U('span', { children: trC(rt, 'Đặc Quyền Quà Tặng Sau Kết Hôn', 'Married Couple Daily Gifts', 'Hadiah Harian Pasangan') }),
                  ],
                }),
                U('span', {
                  class: 'cp-card-sub-badge',
                  children: trC(rt, 'Mỗi ngày 6 lượt', '6x / Day', '6x / Hari'),
                }),
              ],
            }),
            U('div', {
              class: 'cp-gift-preview-grid',
              children: [
                U('div', {
                  class: 'cp-gift-preview-item pink',
                  children: [
                    U('div', { class: 'cp-gift-preview-ico', children: U(cB, { id: 'heart', size: 24 }) }),
                    U('div', {
                      class: 'cp-gift-preview-txt',
                      children: [
                        U('b', { children: trC(rt, 'Tim Ngọt Ngào', 'Sweet Heart', 'Hati Manis') }),
                        U('small', { children: trC(rt, 'Miễn phí 3 lượt/ngày · +15 Điểm 💕', 'Free 3x/day · +15 Love Pts 💕', 'Gratis 3x/hari · +15 Poin 💕') }),
                      ],
                    }),
                  ],
                }),
                U('div', {
                  class: 'cp-gift-preview-item gold',
                  children: [
                    U('div', { class: 'cp-gift-preview-ico', children: U(EB, { id: 'ui.love_basket', px: 26 }) }),
                    U('div', {
                      class: 'cp-gift-preview-txt',
                      children: [
                        U('b', { children: trC(rt, 'Giỏ Trái Cây Tình Yêu', 'Love Fruit Basket', 'Keranjang Buah Cinta') }),
                        U('small', { children: trC(rt, '50.000đ (3 lượt/ngày) · +50 Điểm 💕', '50,000đ (3x/day) · +50 Love Pts 💕', '50.000đ (3x/hari) · +50 Poin 💕') }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
      ],
    });
  };

  // ============================================================
  // RENDER: DANH SÁCH MỐC THƯỞNG CẶP ĐÔI (DÙNG CHUNG CHO CẢ 2 TRẠNG THÁI)
  // ============================================================
  const renderMilestonesSection = () => {
    const maxTarget = milestones[milestones.length - 1]?.targetPoints || 6500;
    const overallPct = Math.min(100, Math.round((totalPoints / maxTarget) * 100));

    return U('div', {
      class: 'cp-section-stack',
      children: [
        // Tổng quan tiến độ thân mật
        U('div', {
          class: 'cp-card cp-ms-summary-card',
          children: [
            U('div', {
              class: 'cp-ms-summary-top',
              children: [
                U('div', {
                  children: [
                    U('div', {
                      class: 'cp-ms-tier-badge',
                      children: `${loveTier.badge} ${trC(rt, `Cấp Tình Cảm Lv.${loveTier.level}: ${loveTier.nameVi}`, `Love Tier Lv.${loveTier.level}: ${loveTier.nameEn}`, `Level Cinta Lv.${loveTier.level}: ${loveTier.nameId}`)}`,
                    }),
                    U('div', {
                      class: 'cp-ms-total-pts',
                      children: [
                        U('strong', { children: totalPoints.toLocaleString('vi-VN') }),
                        U('span', { children: ` / ${maxTarget.toLocaleString('vi-VN')} ${trC(rt, 'Điểm Thân Mật 💕', 'Love Points 💕', 'Poin Cinta 💕')}` }),
                      ],
                    }),
                  ],
                }),
                U('div', {
                  class: 'cp-ms-total-reward-box',
                  children: [
                    U('small', { children: trC(rt, 'Tổng quỹ thưởng', 'Total Rewards', 'Total Hadiah') }),
                    U('b', { children: P(12900000) }),
                  ],
                }),
              ],
            }),
            U('div', {
              class: 'cp-ms-master-bar',
              children: U('div', {
                class: 'cp-ms-master-fill',
                style: { width: `${overallPct}%` },
              }),
            }),
            U('div', {
              class: 'cp-ms-summary-hint',
              children: isMarried
                ? trC(
                    rt,
                    '💡 Cả hai chủ tiệm cùng tặng Tim và Giỏ Trái Cây mỗi ngày để tích điểm mở khóa toàn bộ 12.900.000đ tiền thưởng!',
                    '💡 Both partners send Hearts and Fruit Baskets daily to unlock all 12,900,000đ in cash rewards!',
                    '💡 Kirim Hati & Keranjang Buah setiap hari bersama pasangan untuk membuka total hadiah 12.900.000đ!'
                  )
                : trC(
                    rt,
                    '💡 Sau khi kết hôn, hai bạn sẽ cùng tích lũy Điểm Thân Mật để nhận tới 12.900.000đ tiền thưởng vào két tiệm!',
                    '💡 Once married, build Love Points together to claim up to 12,900,000đ for your shop!',
                    '💡 Setelah menikah, kumpulkan Poin Cinta bersama untuk klaim hadiah hingga 12.900.000đ!'
                  ),
            }),
          ],
        }),

        // Lộ trình 5 mốc thưởng
        U('div', {
          class: 'cp-ms-list',
          children: milestones.map((m, idx) => {
            const isClaimed = claimed.includes(m.id);
            const reached = totalPoints >= m.targetPoints;
            const canClaim = isMarried && !isClaimed && reached;
            const pct = Math.min(100, Math.round((totalPoints / m.targetPoints) * 100));
            const stepIcons = ['🌸', '💞', '💖', '💎', '👑'];

            return U(
              'div',
              {
                class: `cp-ms-row ${isClaimed ? 'claimed' : canClaim ? 'claimable' : reached ? 'reached' : ''}`,
                children: [
                  U('div', {
                    class: 'cp-ms-step-badge',
                    children: [
                      U('span', { class: 'cp-ms-step-emo', children: stepIcons[idx] || '💝' }),
                      U('small', { children: `#${m.id}` }),
                    ],
                  }),
                  U('div', {
                    class: 'cp-ms-info',
                    children: [
                      U('div', {
                        class: 'cp-ms-title-row',
                        children: [
                          U('b', { class: 'cp-ms-title', children: trC(rt, m.title, m.titleEn) }),
                          U('span', { class: 'cp-ms-reward-tag', children: `+${P(m.reward)}` }),
                        ],
                      }),
                      U('div', {
                        class: 'cp-ms-prog-wrap',
                        children: [
                          U('div', {
                            class: 'cp-ms-prog-bar',
                            children: U('div', {
                              class: 'cp-ms-prog-fill',
                              style: { width: `${pct}%` },
                            }),
                          }),
                          U('span', {
                            class: 'cp-ms-prog-txt',
                            children: `${Math.min(totalPoints, m.targetPoints).toLocaleString('vi-VN')}/${m.targetPoints.toLocaleString('vi-VN')} 💕`,
                          }),
                        ],
                      }),
                    ],
                  }),
                  U('button', {
                    type: 'button',
                    disabled: !canClaim || busy,
                    onClick: () => onClaimMilestone(m),
                    class: `cp-ms-btn ${isClaimed ? 'done' : canClaim ? 'ready' : 'locked'}`,
                    children: isClaimed
                      ? trC(rt, '✓ Đã nhận', '✓ Claimed', '✓ Diklaim')
                      : canClaim
                      ? trC(rt, '🎁 Nhận Ngay', '🎁 Claim', '🎁 Klaim')
                      : !isMarried
                      ? trC(rt, 'Kết hôn mở', 'Marry 1st', 'Menikah dulu')
                      : `${pct}%`,
                  }),
                ],
              },
              m.id
            );
          }),
        }),
      ],
    });
  };

  // ============================================================
  // RENDER: GIAO DIỆN ĐÃ KẾT HÔN (TỔ ẤM CẶP ĐÔI & SỔ HỒNG)
  // ============================================================
  const renderMarriedScreen = () => {
    const nextMs = milestones.find((m) => totalPoints < m.targetPoints) || milestones[milestones.length - 1];
    const nextMsPct = nextMs ? Math.min(100, Math.round((totalPoints / nextMs.targetPoints) * 100)) : 100;

    return U(C, {
      children: [
        // Thanh chuyển nhánh trong Tổ Ấm Đã Kết Hôn
        U('div', {
          class: 'cp-tabs cp-tabs-3',
          children: [
            U('button', {
              type: 'button',
              class: `cp-tab-btn ${marriedTab === 'home' ? 'active' : ''}`,
              onClick: () => {
                H.play('tap');
                setMarriedTab('home');
              },
              children: [
                U(EB, { id: 'ui.couple', px: 17 }),
                U('span', { children: trC(rt, 'Tổ Ấm Đôi', 'Love Home', 'Rumah Cinta') }),
              ],
            }),
            U('button', {
              type: 'button',
              class: `cp-tab-btn ${marriedTab === 'milestones' ? 'active' : ''}`,
              onClick: () => {
                H.play('tap');
                setMarriedTab('milestones');
              },
              children: [
                U(EB, { id: 'ui.qua_tang', px: 17 }),
                U('span', { children: trC(rt, 'Mốc Thưởng', 'Rewards', 'Hadiah') }),
                claimableCount > 0 &&
                  U('span', {
                    class: 'cp-tab-badge',
                    children: String(claimableCount),
                  }),
              ],
            }),
            U('button', {
              type: 'button',
              class: `cp-tab-btn ${marriedTab === 'shop' ? 'active' : ''}`,
              onClick: () => {
                H.play('tap');
                setMarriedTab('shop');
              },
              children: [
                U(EB, { id: 'ui.ring_diamond', px: 17 }),
                U('span', { children: trC(rt, 'Tiệm Nhẫn', 'Ring Shop', 'Toko Cincin') }),
              ],
            }),
          ],
        }),

        marriedTab === 'milestones'
          ? renderMilestonesSection()
          : marriedTab === 'shop'
          ? renderShopSection(true)
          : U('div', {
              class: 'cp-section-stack',
              children: [
                // 1. GIẤY CHỨNG NHẬN KẾT HÔN HOÀNG GIA (SỔ HỒNG CẶP ĐÔI)
                U('div', {
                  class: 'cp-cert-card',
                  children: [
                    // 4 góc hoa văn vàng kim
                    U('i', { class: 'cp-cert-corner tl' }),
                    U('i', { class: 'cp-cert-corner tr' }),
                    U('i', { class: 'cp-cert-corner bl' }),
                    U('i', { class: 'cp-cert-corner br' }),

                    U('div', {
                      class: 'cp-cert-header',
                      children: [
                        U('span', {
                          class: 'cp-cert-ribbon',
                          children: [
                            U(EB, { id: 'ui.couple', px: 14 }),
                            U('span', { children: trC(rt, 'GIẤY CHỨNG NHẬN KẾT HÔN', 'ROYAL MARRIAGE CERTIFICATE', 'SERTIFIKAT PERNIKAHAN') }),
                          ],
                        }),
                      ],
                    }),

                    // Hai bảng hiệu tiệm + Nhẫn cưới + Con dấu Song Hỷ ở giữa
                    U('div', {
                      class: 'cp-cert-couple-stage',
                      children: [
                        U('div', {
                          class: 'cp-cert-spouse-box mine',
                          children: [
                            U('div', { class: 'cp-cert-avatar', children: '🏪' }),
                            U('div', {
                              class: 'cp-cert-spouse-role',
                              children: trC(rt, 'Tiệm Của Bạn', 'Your Shop', 'Tokomu'),
                            }),
                            U('div', {
                              class: 'cp-cert-spouse-name',
                              children: shop.shopName || 'Tiệm Trái Cây',
                            }),
                          ],
                        }),

                        U('div', {
                          class: 'cp-cert-center-seal',
                          children: [
                            U('div', {
                              class: 'cp-cert-hy-seal',
                              title: trC(rt, 'Song Hỷ', 'Double Happiness', 'Kebahagiaan Ganda'),
                              children: '囍',
                            }),
                            U('div', {
                              class: 'cp-cert-ring-badge',
                              children: [
                                U(EB, { id: marriedRing?.sprite || 'ui.ring_gold', px: 20 }),
                              ],
                            }),
                          ],
                        }),

                        U('div', {
                          class: 'cp-cert-spouse-box partner',
                          children: [
                            U('div', { class: 'cp-cert-avatar partner', children: '💖' }),
                            U('div', {
                              class: 'cp-cert-spouse-role',
                              children: trC(rt, 'Bạn Đời', 'Spouse Shop', 'Pasangan'),
                            }),
                            U('div', {
                              class: 'cp-cert-spouse-name',
                              children: cs.partnerShop || 'Tiệm Người Thương',
                            }),
                          ],
                        }),
                      ],
                    }),

                    // Thanh cấp độ tình cảm & tiến độ mốc kế tiếp
                    U('div', {
                      class: 'cp-cert-love-meter',
                      children: [
                        U('div', {
                          class: 'cp-cert-love-row',
                          children: [
                            U('span', {
                              class: 'cp-cert-love-rank',
                              children: `${loveTier.badge} ${trC(rt, loveTier.nameVi, loveTier.nameEn, loveTier.nameId)} (Lv.${loveTier.level})`,
                            }),
                            U('span', {
                              class: 'cp-cert-love-pts',
                              children: `${totalPoints.toLocaleString('vi-VN')} / ${(nextMs?.targetPoints || 6500).toLocaleString('vi-VN')} 💕`,
                            }),
                          ],
                        }),
                        U('div', {
                          class: 'cp-cert-bar-track',
                          children: U('div', {
                            class: 'cp-cert-bar-fill',
                            style: { width: `${nextMsPct}%` },
                          }),
                        }),
                      ],
                    }),

                    // 3 Ô chỉ số vàng ngà
                    U('div', {
                      class: 'cp-cert-stats-grid',
                      children: [
                        U('div', {
                          class: 'cp-cert-stat-item',
                          children: [
                            U('small', { children: trC(rt, 'Bên nhau', 'Together', 'Bersama') }),
                            U('strong', { class: 'red', children: trC(rt, `${marriedDays} ngày`, `${marriedDays} days`, `${marriedDays} hari`) }),
                            U('span', { children: fmtDate(cs.marriedAt) }),
                          ],
                        }),
                        U('div', {
                          class: 'cp-cert-stat-item',
                          children: [
                            U('small', { children: trC(rt, 'Tổng Tim', 'Total Hearts', 'Total Hati') }),
                            U('strong', {
                              class: 'pink',
                              children: [U(cB, { id: 'heart', size: 13 }), U('span', { children: String(totalHearts) })],
                            }),
                            U('span', { children: trC(rt, `Bạn ${myHeartsSent} · Ấy ${partnerHeartsRec}`, `You ${myHeartsSent} · Partner ${partnerHeartsRec}`) }),
                          ],
                        }),
                        U('div', {
                          class: 'cp-cert-stat-item',
                          children: [
                            U('small', { children: trC(rt, 'Điểm Thân Mật', 'Love Points', 'Poin Cinta') }),
                            U('strong', { class: 'gold', children: `${totalPoints.toLocaleString('vi-VN')} đ` }),
                            U('span', { children: trC(rt, marriedRing?.name || 'Nhẫn cưới', marriedRing?.nameEn || 'Wedding Ring') }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),

                // 2. GỬI TẶNG YÊU THƯƠNG MỖI NGÀY
                U('div', {
                  class: 'cp-card cp-daily-love-card',
                  children: [
                    U('div', {
                      class: 'cp-card-head',
                      children: [
                        U('span', {
                          class: 'cp-card-title',
                          children: [
                            U(cB, { id: 'heart', size: 16 }),
                            U('span', { children: trC(rt, 'Vun Đắp Tình Cảm Hằng Ngày', 'Daily Love & Affection', 'Kasih Sayang Harian') }),
                          ],
                        }),
                        U('span', {
                          class: 'cp-wallet-mini',
                          children: `${trC(rt, 'Két:', 'Cash:', 'Kas:')} ${P(shop.money)}`,
                        }),
                      ],
                    }),

                    // Nhật ký yêu thương vừa nhận
                    lastGiftText
                      ? U('div', {
                          class: 'cp-partner-log active',
                          children: [
                            U('span', { class: 'cp-partner-log-ico', children: '💌' }),
                            U('span', { class: 'cp-partner-log-txt', children: lastGiftText }),
                          ],
                        })
                      : U('div', {
                          class: 'cp-partner-log',
                          children: [
                            U('span', { class: 'cp-partner-log-ico', children: '💞' }),
                            U('span', {
                              class: 'cp-partner-log-txt',
                              children: trC(
                                rt,
                                `Đã gửi: ${myPointsSent} điểm · Người thương gửi: ${partnerPointsRec} điểm (+${marriedRing?.bonusPoints || 30} điểm nhẫn)`,
                                `You sent: ${myPointsSent} pts · Partner sent: ${partnerPointsRec} pts (+${marriedRing?.bonusPoints || 30} ring bonus)`
                              ),
                            }),
                          ],
                        }),

                    U('div', {
                      class: 'cp-gift-actions-grid',
                      children: [
                        // Nút Tặng Tim Miễn Phí
                        U('div', {
                          class: `cp-gift-action-box pink ${dailyRem.freeLeft <= 0 ? 'done' : ''}`,
                          children: [
                            U('div', {
                              class: 'cp-gift-action-top',
                              children: [
                                U('div', {
                                  class: 'cp-gift-action-icon pink',
                                  children: U(cB, { id: 'heart', size: 26 }),
                                }),
                                U('div', {
                                  class: 'cp-gift-action-meta',
                                  children: [
                                    U('b', { children: trC(rt, 'Thả Tim Ngọt Ngào', 'Send Sweet Heart', 'Kirim Hati Manis') }),
                                    U('span', {
                                      class: 'cp-gift-gain-tag',
                                      children: trC(rt, '+1 Tim · +15 Điểm 💕', '+1 Heart · +15 Pts 💕', '+1 Hati · +15 Poin 💕'),
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            U('div', {
                              class: 'cp-gift-dots-row',
                              children: [
                                U('span', { children: trC(rt, 'Lượt hôm nay:', 'Today:', 'Hari ini:') }),
                                U('div', {
                                  class: 'cp-gift-dots',
                                  children: [0, 1, 2].map((idx) =>
                                    U('i', { class: `cp-dot ${idx < dailyRem.freeLeft ? 'on' : 'used'}` }, idx)
                                  ),
                                }),
                                U('b', { children: `${dailyRem.freeLeft}/3` }),
                              ],
                            }),
                            U('button', {
                              type: 'button',
                              disabled: busy || dailyRem.freeLeft <= 0,
                              onClick: () => onSendHeart('free'),
                              class: `cp-action-btn block ${dailyRem.freeLeft > 0 ? 'pink' : 'disabled'}`,
                              children:
                                dailyRem.freeLeft > 0
                                  ? trC(rt, '💗 Tặng Tim Miễn Phí', '💗 Send Free Heart', '💗 Kirim Hati Gratis')
                                  : trC(rt, '✓ Đã tặng hết hôm nay', '✓ All Sent Today', '✓ Selesai Hari Ini'),
                            }),
                          ],
                        }),

                        // Nút Tặng Giỏ Trái Cây Tình Yêu
                        U('div', {
                          class: `cp-gift-action-box gold ${dailyRem.giftLeft <= 0 ? 'done' : ''}`,
                          children: [
                            U('div', {
                              class: 'cp-gift-action-top',
                              children: [
                                U('div', {
                                  class: 'cp-gift-action-icon gold',
                                  children: U(EB, { id: 'ui.love_basket', px: 28 }),
                                }),
                                U('div', {
                                  class: 'cp-gift-action-meta',
                                  children: [
                                    U('b', { children: trC(rt, 'Giỏ Trái Cây Tình Yêu', 'Love Fruit Basket', 'Keranjang Buah Cinta') }),
                                    U('span', {
                                      class: 'cp-gift-gain-tag gold',
                                      children: trC(rt, '+3 Tim · +50 Điểm 💕', '+3 Hearts · +50 Pts 💕', '+3 Hati · +50 Poin 💕'),
                                    }),
                                  ],
                                }),
                              ],
                            }),
                            U('div', {
                              class: 'cp-gift-dots-row',
                              children: [
                                U('span', { children: trC(rt, 'Lượt hôm nay:', 'Today:', 'Hari ini:') }),
                                U('div', {
                                  class: 'cp-gift-dots',
                                  children: [0, 1, 2].map((idx) =>
                                    U('i', { class: `cp-dot gold ${idx < dailyRem.giftLeft ? 'on' : 'used'}` }, idx)
                                  ),
                                }),
                                U('b', { children: `${dailyRem.giftLeft}/3` }),
                              ],
                            }),
                            U('button', {
                              type: 'button',
                              disabled: busy || dailyRem.giftLeft <= 0 || shop.money < 50000,
                              onClick: () => onSendHeart('gift'),
                              class: `cp-action-btn block ${dailyRem.giftLeft > 0 && shop.money >= 50000 ? 'gold' : 'disabled'}`,
                              children:
                                dailyRem.giftLeft <= 0
                                  ? trC(rt, '✓ Đã tặng hết hôm nay', '✓ All Sent Today', '✓ Selesai Hari Ini')
                                  : shop.money < 50000
                                  ? trC(rt, 'Cần 50.000đ trong két', 'Need 50,000đ', 'Perlu 50.000đ')
                                  : trC(rt, '🧺 Tặng Giỏ Quà (50K)', '🧺 Send Basket (50K)', '🧺 Kirim Keranjang (50K)'),
                            }),
                          ],
                        }),
                      ],
                    }),
                  ],
                }),

                // 3. MỐC THƯỞNG NỔI BẬT TIẾP THEO (RÚT GỌN + NÚT XEM TẤT CẢ)
                U('div', {
                  class: 'cp-card cp-quick-ms-card',
                  children: [
                    U('div', {
                      class: 'cp-card-head',
                      children: [
                        U('span', {
                          class: 'cp-card-title',
                          children: [
                            U(EB, { id: 'ui.qua_tang', px: 16 }),
                            U('span', { children: trC(rt, 'Mốc Thưởng Cặp Đôi', 'Couple Milestones', 'Hadiah Pasangan') }),
                          ],
                        }),
                        U('button', {
                          type: 'button',
                          class: 'cp-link-pill',
                          onClick: () => {
                            H.play('tap');
                            setMarriedTab('milestones');
                          },
                          children: trC(
                            rt,
                            `Xem tất cả (${claimed.length}/${milestones.length}) ›`,
                            `View All (${claimed.length}/${milestones.length}) ›`
                          ),
                        }),
                      ],
                    }),
                    U('div', {
                      class: 'cp-ms-list compact',
                      children: milestones.map((m, idx) => {
                        const isClaimed = claimed.includes(m.id);
                        const canClaim = !isClaimed && totalPoints >= m.targetPoints;
                        const pct = Math.min(100, Math.round((totalPoints / m.targetPoints) * 100));
                        const stepIcons = ['🌸', '💞', '💖', '💎', '👑'];
                        return U(
                          'div',
                          {
                            class: `cp-ms-row ${isClaimed ? 'claimed' : canClaim ? 'claimable' : ''}`,
                            children: [
                              U('div', {
                                class: 'cp-ms-step-badge',
                                children: [
                                  U('span', { class: 'cp-ms-step-emo', children: stepIcons[idx] || '💝' }),
                                  U('small', { children: `#${m.id}` }),
                                ],
                              }),
                              U('div', {
                                class: 'cp-ms-info',
                                children: [
                                  U('div', {
                                    class: 'cp-ms-title-row',
                                    children: [
                                      U('b', { class: 'cp-ms-title', children: trC(rt, m.title, m.titleEn) }),
                                      U('span', { class: 'cp-ms-reward-tag', children: `+${P(m.reward)}` }),
                                    ],
                                  }),
                                  U('div', {
                                    class: 'cp-ms-prog-wrap',
                                    children: [
                                      U('div', {
                                        class: 'cp-ms-prog-bar',
                                        children: U('div', {
                                          class: 'cp-ms-prog-fill',
                                          style: { width: `${pct}%` },
                                        }),
                                      }),
                                      U('span', {
                                        class: 'cp-ms-prog-txt',
                                        children: `${Math.min(totalPoints, m.targetPoints)}/${m.targetPoints} 💕`,
                                      }),
                                    ],
                                  }),
                                ],
                              }),
                              U('button', {
                                type: 'button',
                                disabled: !canClaim || busy,
                                onClick: () => onClaimMilestone(m),
                                class: `cp-ms-btn ${isClaimed ? 'done' : canClaim ? 'ready' : 'locked'}`,
                                children: isClaimed
                                  ? trC(rt, 'Đã nhận ✓', 'Claimed ✓', 'Diklaim ✓')
                                  : canClaim
                                  ? trC(rt, 'Nhận thưởng', 'Claim', 'Klaim')
                                  : trC(rt, 'Chưa đủ', 'Locked', 'Terkunci'),
                              }),
                            ],
                          },
                          m.id
                        );
                      }),
                    }),
                  ],
                }),

                // 4. HỦY KẾT HÔN / CHIA TAY
                U('div', {
                  class: 'cp-divorce-zone',
                  children: !divorceStep
                    ? U('button', {
                        type: 'button',
                        onClick: () => setDivorceStep(true),
                        class: 'cp-divorce-trigger',
                        children: trC(rt, 'Hủy kết hôn / Chia tay', 'Unmarry / Break up', 'Batalkan Pernikahan / Pisah'),
                      })
                    : U('div', {
                        class: 'cp-divorce-confirm',
                        children: [
                          U('div', {
                            class: 'cp-divorce-warn',
                            children: trC(
                              rt,
                              '⚠️ Chắc chắn muốn chia tay/ly hôn? Hai tiệm sẽ mất liên kết và cần đợi 24 giờ mới có thể kết hôn lại.',
                              '⚠️ Confirm divorce? Both shops will unlink and must wait 24 hours before remarrying.',
                              '⚠️ Yakin ingin berpisah? Perlu menunggu 24 jam sebelum menikah lagi.'
                            ),
                          }),
                          U('div', {
                            class: 'cp-divorce-btns',
                            children: [
                              U('button', {
                                type: 'button',
                                onClick: () => setDivorceStep(false),
                                class: 'cp-action-btn paper',
                                children: trC(rt, 'Giữ lại hôn nhân', 'Keep Marriage', 'Batal'),
                              }),
                              U('button', {
                                type: 'button',
                                disabled: busy,
                                onClick: onConfirmDivorce,
                                class: 'cp-action-btn danger',
                                children: trC(rt, 'Xác nhận Chia tay', 'Confirm Unmarry', 'Ya, Berpisah'),
                              }),
                            ],
                          }),
                        ],
                      }),
                }),
              ],
            }),
      ],
    });
  };

  // ============================================================
  // RENDER: GIAO DIỆN ĐỘC THÂN (KẾT HÔN & CỬA HÀNG)
  // ============================================================
  const renderSingleScreen = () => {
    return U(C, {
      children: [
        // 2 Tabs chuyển đổi mượt mà
        U('div', {
          class: 'cp-tabs cp-tabs-2',
          children: [
            U('button', {
              type: 'button',
              class: `cp-tab-btn ${tab === 'marry' ? 'active' : ''}`,
              onClick: () => {
                H.play('tap');
                setTab('marry');
              },
              children: [
                U(EB, { id: 'ui.couple', px: 17 }),
                U('span', { children: trC(rt, 'Sảnh Kết Hôn', 'Marriage Hall', 'Aula Nikah') }),
                inProps.length > 0 &&
                  U('span', {
                    class: 'cp-tab-badge',
                    children: String(inProps.length),
                  }),
              ],
            }),
            U('button', {
              type: 'button',
              class: `cp-tab-btn ${tab === 'shop' ? 'active' : ''}`,
              onClick: () => {
                H.play('tap');
                setTab('shop');
              },
              children: [
                U(EB, { id: 'ui.ring_gold', px: 17 }),
                U('span', { children: trC(rt, 'Cửa Hàng Nhẫn', 'Couple Shop', 'Toko Cincin') }),
                ownedRings.length > 0 &&
                  U('span', {
                    class: 'cp-tab-badge gold',
                    children: String(ownedRings.length),
                  }),
              ],
            }),
          ],
        }),

        tab === 'shop'
          ? renderShopSection(false)
          : U('div', {
              class: 'cp-section-stack',
              children: [
                // Cảnh báo Cooldown 24h sau chia tay (nếu có)
                inCooldown &&
                  U('div', {
                    class: 'cp-cooldown-banner',
                    children: [
                      U(EB, { id: 'ui.clock', px: 24, fallback: '⏳' }),
                      U('div', {
                        class: 'cp-cooldown-txt',
                        children: [
                          U('b', {
                            children: trC(
                              rt,
                              'Đang trong thời gian chờ sau chia tay (24h)',
                              '24h Post-Divorce Cooldown Active',
                              'Masa tunggu 24 jam setelah berpisah'
                            ),
                          }),
                          U('span', {
                            children: trC(
                              rt,
                              `Bạn cần đợi thêm ${cooldownStr} nữa mới có thể gửi lời cầu hôn hoặc đồng ý kết hôn mới.`,
                              `Please wait ${cooldownStr} before proposing or accepting a new marriage.`,
                              `Tunggu ${cooldownStr} lagi sebelum menikah kembali.`
                            ),
                          }),
                        ],
                      }),
                    ],
                  }),

                // LỜI CẦU HÔN GỬI ĐẾN BẠN (Nổi bật như Thiệp Hồng)
                inProps.length > 0 &&
                  U('div', {
                    class: 'cp-incoming-card',
                    children: [
                      U('div', {
                        class: 'cp-incoming-head',
                        children: [
                          U(EB, { id: 'ui.couple', px: 18 }),
                          U('span', {
                            children: trC(
                              rt,
                              `💌 Thiệp Cầu Hôn Gửi Đến Bạn (${inProps.length})`,
                              `💌 Incoming Marriage Proposals (${inProps.length})`,
                              `💌 Lamaran Masuk (${inProps.length})`
                            ),
                          }),
                        ],
                      }),
                      U('div', {
                        class: 'cp-incoming-list',
                        children: inProps.map((p) => {
                          const rDef = t?.getRingDef?.(p.ringId) || rings[0];
                          return U(
                            'div',
                            {
                              class: 'cp-proposal-item',
                              children: [
                                U('div', {
                                  class: 'cp-proposal-top',
                                  children: [
                                    U('div', {
                                      class: 'cp-proposal-ring-box',
                                      children: U(EB, { id: rDef?.sprite || 'ui.ring_gold', px: 32 }),
                                    }),
                                    U('div', {
                                      class: 'cp-proposal-meta',
                                      children: [
                                        U('div', {
                                          class: 'cp-proposal-sender',
                                          children: trC(
                                            rt,
                                            `Chủ tiệm "${p.fromShop}" cầu hôn bạn!`,
                                            `"${p.fromShop}" proposed to you!`,
                                            `Pemilik "${p.fromShop}" melamarmu!`
                                          ),
                                        }),
                                        U('div', {
                                          class: 'cp-proposal-ring-tag',
                                          children: trC(
                                            rt,
                                            `Tặng ${rDef?.name || 'Nhẫn cưới'} · Khởi đầu +${rDef?.bonusPoints || 30} Điểm 💕`,
                                            `Ring: ${rDef?.nameEn || 'Wedding Ring'} (+${rDef?.bonusPoints || 30} Love Pts 💕)`
                                          ),
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                U('div', {
                                  class: 'cp-proposal-btns',
                                  children: [
                                    U('button', {
                                      type: 'button',
                                      disabled: busy || !unlocked || inCooldown,
                                      onClick: () => onAcceptProp(p),
                                      class: `cp-action-btn flex-1 ${unlocked && !inCooldown ? 'green' : 'disabled'}`,
                                      children: !unlocked
                                        ? trC(rt, 'Cần đạt Cấp 2', 'Need Lv.2', 'Perlu Lv.2')
                                        : inCooldown
                                        ? trC(rt, `Chờ ${cooldownStr}`, `Wait ${cooldownStr}`, `Tunggu ${cooldownStr}`)
                                        : trC(rt, '💍 Đồng Ý Kết Hôn!', '💍 Accept Proposal!', '💍 Terima Lamaran!'),
                                    }),
                                    U('button', {
                                      type: 'button',
                                      disabled: busy,
                                      onClick: () => onDeclineProp(p),
                                      class: 'cp-action-btn paper',
                                      children: trC(rt, 'Từ chối', 'Decline', 'Tolak'),
                                    }),
                                  ],
                                }),
                              ],
                            },
                            p.fromUid
                          );
                        }),
                      }),
                    ],
                  }),

                // THẺ MÃ KẾT HÔN CỦA BẠN (THIỆP HỒNG ĐỊNH DANH)
                U('div', {
                  class: 'cp-card cp-mycode-card',
                  children: [
                    U('div', {
                      class: 'cp-card-head',
                      children: [
                        U('span', {
                          class: 'cp-card-title',
                          children: [
                            U(EB, { id: 'ui.couple', px: 16 }),
                            U('span', { children: trC(rt, 'Mã Kết Hôn Của Tiệm Bạn', 'Your Shop Marriage Code', 'Kode Nikah Tokomu') }),
                          ],
                        }),
                        U('span', {
                          class: `cp-status-pill ${unlocked ? 'ok' : 'lock'}`,
                          children: unlocked
                            ? trC(rt, `✓ Đã mở khóa (Cấp ${curLevel})`, `✓ Unlocked (Lv.${curLevel})`)
                            : trC(rt, '🔒 Mở ở Cấp 2', '🔒 Unlocks at Lv.2'),
                        }),
                      ],
                    }),

                    U('div', {
                      class: 'cp-code-ticket',
                      children: [
                        U('div', {
                          class: 'cp-code-display',
                          onClick: copyCodeOnly,
                          title: trC(rt, 'Chạm để sao chép mã', 'Tap to copy code'),
                          children: [
                            U('small', { children: trC(rt, 'MÃ DUYÊN PHẬN', 'MARRIAGE ID', 'KODE JODOH') }),
                            U('strong', { children: myCode || '---' }),
                          ],
                        }),
                        U('button', {
                          type: 'button',
                          onClick: copyCode,
                          class: `cp-action-btn ${copied ? 'green' : 'gold'}`,
                          children: copied
                            ? [U(cB, { id: 'check', size: 14 }), U('span', { children: trC(rt, 'Đã chép!', 'Copied!', 'Disalin!') })]
                            : [U('span', { children: '📋' }), U('span', { children: trC(rt, 'Sao chép lời mời', 'Copy Invite', 'Salin Undangan') })],
                        }),
                      ],
                    }),

                    U('div', {
                      class: 'cp-card-foot-note',
                      children: trC(
                        rt,
                        'Gửi mã này cho người thương để người ấy cầu hôn bạn, hoặc tự mua nhẫn và nhập mã của người ấy ở bên dưới!',
                        'Share this code with your partner so they can propose, or buy a ring and enter their code below!',
                        'Bagikan kode ini ke pasanganmu, atau beli cincin dan masukkan kode mereka di bawah!'
                      ),
                    }),
                  ],
                }),

                // BÀN CẦU HÔN & TRAO NHẪN
                U('div', {
                  class: 'cp-card cp-propose-card',
                  children: [
                    U('div', {
                      class: 'cp-card-head',
                      children: [
                        U('span', {
                          class: 'cp-card-title',
                          children: [
                            U(EB, { id: 'ui.ring_gold', px: 16 }),
                            U('span', { children: trC(rt, 'Gửi Lời Cầu Hôn & Trao Nhẫn', 'Propose & Present Ring', 'Kirim Lamaran & Cincin') }),
                          ],
                        }),
                        U('button', {
                          type: 'button',
                          onClick: () => {
                            H.play('tap');
                            setTab('shop');
                          },
                          class: 'cp-link-pill gold',
                          children: trC(
                            rt,
                            `+ Tiệm Nhẫn (${ownedRings.length}) ›`,
                            `+ Ring Shop (${ownedRings.length}) ›`,
                            `+ Toko Cincin (${ownedRings.length}) ›`
                          ),
                        }),
                      ],
                    }),

                    // Hướng dẫn 3 bước rõ ràng
                    U('div', {
                      class: 'cp-steps-strip',
                      children: [
                        U('div', {
                          class: `cp-step-pill ${ownedRings.length > 0 ? 'done' : 'active'}`,
                          children: `1. ${trC(rt, 'Sắm Nhẫn', 'Buy Ring', 'Beli Cincin')}`,
                        }),
                        U('span', { class: 'cp-step-arrow', children: '▸' }),
                        U('div', {
                          class: `cp-step-pill ${ownedRings.length > 0 && !outProp ? 'active' : outProp ? 'done' : ''}`,
                          children: `2. ${trC(rt, 'Nhập Mã TIM', 'Enter Code', 'Masukkan Kode')}`,
                        }),
                        U('span', { class: 'cp-step-arrow', children: '▸' }),
                        U('div', {
                          class: `cp-step-pill ${outProp ? 'active' : ''}`,
                          children: `3. ${trC(rt, 'Nên Duyên', 'Get Married', 'Menikah')}`,
                        }),
                      ],
                    }),

                    ownedRings.length === 0
                      ? U('div', {
                          class: 'cp-no-ring-box',
                          children: [
                            U('div', {
                              class: 'cp-no-ring-art',
                              children: U(EB, { id: 'ui.ring_diamond', px: 34 }),
                            }),
                            U('div', {
                              class: 'cp-no-ring-txt',
                              children: [
                                U('b', {
                                  children: trC(
                                    rt,
                                    'Túi nhẫn của bạn đang trống!',
                                    'Your ring bag is currently empty!',
                                    'Tas cincinmu masih kosong!'
                                  ),
                                }),
                                U('span', {
                                  children: trC(
                                    rt,
                                    'Hãy ghé Cửa Hàng Nhẫn chọn 1 chiếc Nhẫn Hoa Bưởi, Nhẫn Xoài Vàng hoặc Kim Cương Dâu Đỏ để làm tín vật cầu hôn nha.',
                                    'Visit the Ring Shop to pick a Silver, 24K Gold, or Ruby Diamond ring before proposing.',
                                    'Kunjungi Toko Cincin untuk membeli cincin lamaran terlebih dahulu.'
                                  ),
                                }),
                              ],
                            }),
                            U('button', {
                              type: 'button',
                              onClick: () => {
                                H.play('tap');
                                setTab('shop');
                              },
                              class: 'cp-action-btn gold block',
                              children: [
                                U(EB, { id: 'ui.ring_gold', px: 18 }),
                                U('span', { children: trC(rt, 'Mở Cửa Hàng Nhẫn Cầu Hôn ›', 'Open Wedding Ring Shop ›', 'Buka Toko Cincin ›') }),
                              ],
                            }),
                          ],
                        })
                      : U('div', {
                          class: 'cp-propose-active-wrap',
                          children: [
                            // Chọn nhẫn trong túi
                            U('div', {
                              class: 'cp-bag-label',
                              children: trC(rt, 'Chọn nhẫn tín vật trong túi của bạn:', 'Select a ring from your bag:', 'Pilih cincin dari tasmu:'),
                            }),
                            U('div', {
                              class: 'cp-owned-rings-row',
                              children: ownedRings.map((rId) => {
                                const rDef = t?.getRingDef?.(rId) || rings[0];
                                const sel = selectedRingId === rId;
                                return U(
                                  'button',
                                  {
                                    type: 'button',
                                    onClick: () => onSelectRing(rId),
                                    class: `cp-owned-ring-chip ${sel ? 'selected' : ''}`,
                                    children: [
                                      U(EB, { id: rDef?.sprite || 'ui.ring_gold', px: 20 }),
                                      U('div', {
                                        class: 'cp-owned-ring-chip-txt',
                                        children: [
                                          U('b', { children: trC(rt, rDef?.name || 'Nhẫn', rDef?.nameEn || 'Ring') }),
                                          U('small', { children: `+${rDef?.bonusPoints || 30} 💕` }),
                                        ],
                                      }),
                                      sel && U('span', { class: 'cp-chip-check', children: '✓' }),
                                    ],
                                  },
                                  rId
                                );
                              }),
                            }),

                            outProp
                              ? U('div', {
                                  class: 'cp-outgoing-box',
                                  children: [
                                    U('div', {
                                      class: 'cp-outgoing-head',
                                      children: [
                                        U(EB, { id: selectedRingDef?.sprite || 'ui.ring_gold', px: 26 }),
                                        U('div', {
                                          children: [
                                            U('b', {
                                              children: trC(
                                                rt,
                                                `⏳ Đang chờ chủ tiệm (${outProp.toCode || 'Đối phương'}) đồng ý...`,
                                                `⏳ Waiting for partner (${outProp.toCode || 'Partner'}) to accept...`,
                                                `⏳ Menunggu pasangan (${outProp.toCode || 'Partner'}) menerima...`
                                              ),
                                            }),
                                            U('small', {
                                              children: trC(
                                                rt,
                                                'Ngay khi người ấy bấm Đồng Ý, sổ hồng Đã Kết Hôn sẽ tự động mở ra!',
                                                'As soon as they accept, your Royal Marriage Certificate will open!',
                                                'Begitu diterima, Sertifikat Pernikahan akan langsung terbuka!'
                                              ),
                                            }),
                                          ],
                                        }),
                                      ],
                                    }),
                                    U('button', {
                                      type: 'button',
                                      disabled: busy,
                                      onClick: onCancelProp,
                                      class: 'cp-action-btn paper block',
                                      children: trC(
                                        rt,
                                        'Thu hồi lời cầu hôn (Giữ nguyên nhẫn)',
                                        'Cancel Proposal (Keep Ring)',
                                        'Batalkan Lamaran (Simpan Cincin)'
                                      ),
                                    }),
                                  ],
                                })
                              : U('div', {
                                  class: 'cp-propose-input-row',
                                  children: [
                                    U('input', {
                                      type: 'text',
                                      maxLength: 12,
                                      placeholder: trC(rt, 'Nhập mã (VD: TIM-XXXXXX)', 'Enter code (TIM-XXXXXX)', 'Kode (TIM-XXXXXX)'),
                                      value: codeInput,
                                      onInput: (ev: any) => setCodeInput(ev.currentTarget.value.toUpperCase()),
                                      class: 'cp-code-input',
                                    }),
                                    U('button', {
                                      type: 'button',
                                      disabled: busy || !unlocked || inCooldown || ownedRings.length === 0 || !codeInput.trim(),
                                      onClick: onPropose,
                                      class: `cp-action-btn ${
                                        unlocked && !inCooldown && ownedRings.length > 0 && codeInput.trim() ? 'pink' : 'disabled'
                                      }`,
                                      children: inCooldown
                                        ? trC(rt, `Chờ ${cooldownStr}`, `Wait ${cooldownStr}`)
                                        : busy
                                        ? trC(rt, 'Đang gửi…', 'Sending…', 'Mengirim…')
                                        : trC(rt, '💍 Cầu Hôn Ngay', '💍 Propose Now', '💍 Lamar Sekarang'),
                                    }),
                                  ],
                                }),
                          ],
                        }),
                  ],
                }),
              ],
            }),
      ],
    });
  };

  // ============================================================
  // NỘI DUNG TỔNG HỢP
  // ============================================================
  const contentBody = !user
    ? [
        U(CoupleSceneCanvas, {
          rt,
          isMarried: false,
          myShop: shop.shopName || 'Tiệm Trái Cây',
          partnerShop: 'Tiệm Người Thương',
          ringKey: 'gold',
          heartBurstRef,
        }),
        U('div', {
          class: 'cp-card cp-signin-card',
          children: [
            U('div', {
              class: 'cp-signin-head',
              children: [
                U(EB, { id: 'ui.couple', px: 28 }),
                U('div', {
                  children: [
                    U('h4', {
                      children: trC(rt, 'Đăng nhập để mở Kết Hôn Chủ Tiệm!', 'Sign in to unlock Shop Marriage!', 'Masuk untuk membuka Pernikahan Toko!'),
                    }),
                    U('p', {
                      children: trC(
                        rt,
                        'Sắm nhẫn cầu hôn tại Tiệm Kim Hoàn, trao Mã Kết Hôn cho người thương và cùng vun đắp Điểm Thân Mật nhận tới 12.900.000đ tiền thưởng!',
                        'Buy wedding rings in the Couple Boutique, share your Marriage Code, and send daily hearts for up to 12,900,000đ in rewards!',
                        'Beli cincin lamaran, bagikan Kode Nikah, dan kirim hati harian untuk hadiah hingga 12.900.000đ!'
                      ),
                    }),
                  ],
                }),
              ],
            }),
            U(CloudAccountSection, { compact: true }),
          ],
        }),
      ]
    : [
        // Cảnh Pixel-Art động ở đầu modal
        U(CoupleSceneCanvas, {
          rt,
          isMarried,
          myShop: shop.shopName || 'Tiệm Trái Cây',
          partnerShop: cs.partnerShop || 'Tiệm Người Thương',
          ringKey: isMarried ? marriedRing?.key || 'gold' : selectedRingDef?.key || 'gold',
          heartBurstRef,
        }),

        // Thông báo nếu chưa đủ Cấp 2
        !unlocked &&
          U('div', {
            class: 'cp-lock-banner',
            children: [
              U('div', {
                class: 'cp-lock-ico',
                children: U(cB, { id: 'lock', size: 20 }),
              }),
              U('div', {
                class: 'cp-lock-txt',
                children: [
                  U('b', {
                    children: trC(
                      rt,
                      `Cần đạt Cấp 2 để mở khóa Kết Hôn (Hiện tại: Cấp ${curLevel})`,
                      `Requires Level 2 to unlock Marriage (Current: Lv.${curLevel})`,
                      `Perlu Level 2 untuk membuka Pernikahan (Saat ini: Lv.${curLevel})`
                    ),
                  }),
                  U('span', {
                    children: trC(
                      rt,
                      'Hãy bán hàng và nâng cấp tiệm lên Cấp 2 trong mục "Tiệm" để mở khóa Cửa hàng Cặp Đôi & Kết hôn nha!',
                      'Upgrade your shop to Level 2 in the Shop menu to unlock the Couple Shop & Marriage!',
                      'Tingkatkan tokomu ke Level 2 di menu Toko untuk membuka fitur ini!'
                    ),
                  }),
                ],
              }),
            ],
          }),

        isMarried ? renderMarriedScreen() : renderSingleScreen(),
      ];

  if (props.inline) {
    return U('div', {
      class: 'cp-inline-wrap',
      children: contentBody,
    });
  }

  return U('div', {
    class: 'cp-modal-backdrop',
    role: 'dialog',
    'aria-modal': 'true',
    onClick: (ev: any) => {
      if (ev.target === ev.currentTarget) {
        H.play('tap');
        props.onClose?.();
      }
    },
    children: U('div', {
      class: `cp-modal-shell ${!user ? 'is-guest' : isMarried ? 'is-married' : 'is-single'}`,
      onClick: (ev: any) => ev.stopPropagation(),
      children: [
        // HEADER SANG TRỌNG
        U('div', {
          class: 'cp-modal-header',
          children: [
            U('div', {
              class: 'cp-modal-emblem',
              children: U(EB, { id: isMarried ? marriedRing?.sprite || 'ui.couple' : 'ui.couple', px: 28 }),
            }),
            U('div', {
              class: 'cp-modal-title-col',
              children: [
                U('div', {
                  class: 'cp-modal-kicker',
                  children: isMarried
                    ? `囍 ${trC(rt, 'TỔ ẤM CẶP ĐÔI CHỦ TIỆM', 'MARRIED SHOP COUPLE', 'PASANGAN PEMILIK TOKO')} 囍`
                    : `💞 ${trC(rt, 'DUYÊN PHẬN CHỦ TIỆM', 'SHOP OWNERS ROMANCE', 'JODOH PEMILIK TOKO')}`,
                }),
                U('div', {
                  class: 'cp-modal-title',
                  children: isMarried
                    ? trC(rt, 'CẶP ĐÔI ĐÃ KẾT HÔN', 'MARRIED COUPLE', 'PASANGAN MENIKAH')
                    : trC(rt, 'KẾT HÔN & TIỆM NHẪN', 'MARRIAGE & RING SHOP', 'NIKAH & TOKO CINCIN'),
                }),
              ],
            }),
            U('button', {
              type: 'button',
              disabled: busy,
              'aria-label': trC(rt, 'Làm mới', 'Refresh', 'Muat ulang'),
              onClick: () => {
                H.play('tap');
                t?.refreshCoupleState?.();
              },
              class: 'cp-head-btn refresh',
              children: busy
                ? U(EB, { id: 'ui.clock', px: 18 })
                : U('svg', {
                    width: 18,
                    height: 18,
                    viewBox: '0 0 16 16',
                    children: [
                      U('path', {
                        d: 'M13.5 8a5.5 5.5 0 1 1-1.6-3.9L14 2v4.5H9.5l1.6-1.6A3.7 3.7 0 1 0 11.7 8h1.8z',
                        fill: '#ffffff',
                      }),
                    ],
                  }),
            }),
            U('button', {
              type: 'button',
              'aria-label': trC(rt, 'Đóng', 'Close', 'Tutup'),
              onClick: () => {
                H.play('tap');
                props.onClose?.();
              },
              class: 'cp-head-btn close',
              children: U(EB, { id: 'ui.cross', px: 18 }),
            }),
          ],
        }),

        // BODY CUỘN MƯỢT
        U('div', {
          class: 'cp-modal-body',
          children: contentBody,
        }),
      ],
    }),
  });
}

if (typeof window !== 'undefined') {
  (window as any).__TTC_COUPLE = { renderCoupleModal };
}

