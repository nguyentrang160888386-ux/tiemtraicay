import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import {defineConfig, Plugin, transformWithEsbuild} from 'vite';

function maskBinaryPayload(rawCode: string): Buffer {
  const buf = Buffer.from(rawCode, 'utf8');
  const out = Buffer.allocUnsafe(buf.length);
  for (let i = 0; i < buf.length; i++) {
    out[i] = buf[i] ^ 90;
  }
  return out;
}

function makeBinaryLoaderScript(assetUrl: string): string {
  return `(function(){var u0=${JSON.stringify(assetUrl)},tr=0;function rm(){try{var bl=document.getElementById("ttc-boot-loader");if(bl)bl.remove()}catch(e){}}function ld(bst){var url=bst?u0+(u0.indexOf("?")>-1?"&":"?")+"t="+Date.now():u0;fetch(url,bst?{cache:"reload"}:void 0).then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);var ct=(r.headers&&r.headers.get("content-type"))||"";if(ct.indexOf("text/html")>-1)throw new Error("HTML_FALLBACK");return r.arrayBuffer()}).then(function(b){var u=new Uint8Array(b);for(var i=0;i<u.length;i++)u[i]^=90;var hd=new TextDecoder().decode(u.subarray(0,Math.min(64,u.length))).trim().toLowerCase();if(!u.length||hd.indexOf("<!doctype")===0||hd.indexOf("<html")===0)throw new Error("INVALID_PAYLOAD");var code=new TextDecoder().decode(u);u=null;b=null;var s=document.createElement("script");s.textContent=code;code=null;document.head.appendChild(s);s.remove();rm();try{sessionStorage.removeItem("_ttc_sw_rec")}catch(e){}try{document.querySelectorAll('script[type="module"]').forEach(function(e){e.remove()})}catch(e){}}).catch(function(){if(tr<2){tr++;setTimeout(function(){ld(true)},350*tr);return}try{if(!sessionStorage.getItem("_ttc_sw_rec")){sessionStorage.setItem("_ttc_sw_rec","1");var p=[];if("serviceWorker"in navigator)p.push(navigator.serviceWorker.getRegistrations().then(function(rs){return Promise.all(rs.map(function(r){return r.unregister()}))}));if("caches"in window)p.push(caches.keys().then(function(ks){return Promise.all(ks.map(function(k){return caches.delete(k)}))}));Promise.all(p).finally(function(){location.reload()});return}}catch(e){}try{var st=document.getElementById("ttc-boot-status"),bt=document.getElementById("ttc-boot-retry");if(st)st.textContent="Mạng hơi yếu hoặc tiệm vừa cập nhật bản mới. Bấm nút bên dưới để vào lại nha!";if(bt)bt.style.display="inline-flex"}catch(e){}})}ld(false)})();`;
}

let cachedMaskedGameDev: {mtimeMs: number; buf: Buffer} | null = null;
async function getMaskedGameForDev(gamePath: string): Promise<Buffer> {
  const stat = fs.statSync(gamePath);
  if (cachedMaskedGameDev && cachedMaskedGameDev.mtimeMs === stat.mtimeMs) {
    return cachedMaskedGameDev.buf;
  }
  const raw = fs.readFileSync(gamePath, 'utf8');
  const min = await transformWithEsbuild(raw, gamePath, {
    loader: 'js',
    minify: true,
    minifyIdentifiers: true,
    minifySyntax: true,
    minifyWhitespace: true,
    sourcemap: false,
    legalComments: 'none',
  });
  const buf = maskBinaryPayload(min.code);
  cachedMaskedGameDev = {mtimeMs: stat.mtimeMs, buf};
  return buf;
}

// Plugin tự động nén chặt, ngụy trang gói mã nguồn thành file .woff2 nhị phân & xóa Source Map
function hideSourceCodePlugin(): Plugin {
  let isBuild = false;
  let rootDir = process.cwd();
  return {
    name: 'hide-source-code',
    enforce: 'post' as const,
    configResolved(config) {
      isBuild = config.command === 'build';
      rootDir = config.root;
    },
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (req.url && req.url.startsWith('/assets/ttc-glyphs-dev.woff2')) {
          try {
            const gamePath = path.resolve(rootDir, 'src/game.js');
            const buf = await getMaskedGameForDev(gamePath);
            res.statusCode = 200;
            res.setHeader('Content-Type', 'font/woff2');
            res.setHeader('Cache-Control', 'no-cache');
            res.end(buf);
            return;
          } catch {}
        }
        next();
      });
    },
    async transform(code: string, id: string) {
      const cleanId = id.split('?')[0];
      if (!isBuild && cleanId.endsWith('/src/main.tsx')) {
        const withoutGameImport = code.replace(/import\s+['"]\.\/game\.js['"];?/g, '');
        return {
          code: `${withoutGameImport}\n${makeBinaryLoaderScript('/assets/ttc-glyphs-dev.woff2')}`,
          map: null,
        };
      }
      if (id.includes('/src/') && /\.(tsx?|jsx?)$/.test(cleanId)) {
        const loader = cleanId.endsWith('.tsx')
          ? 'tsx'
          : cleanId.endsWith('.ts')
            ? 'ts'
            : cleanId.endsWith('.jsx')
              ? 'jsx'
              : 'js';
        const result = await transformWithEsbuild(code, cleanId, {
          loader,
          minify: true,
          minifyIdentifiers: true,
          minifySyntax: true,
          minifyWhitespace: true,
          sourcemap: false,
          legalComments: 'none',
        });
        return {
          code: result.code,
          map: null,
        };
      }
      return null;
    },
  };
}

function ttcSwManifest(): Plugin {
  let outDir = 'dist';
  return {
    name: 'ttc-sw-manifest',
    apply: 'build',
    configResolved(config) {
      outDir = path.resolve(config.root, config.build.outDir);
    },
    async closeBundle() {
      const swPath = path.join(outDir, 'sw.js');
      const indexPath = path.join(outDir, 'index.html');
      if (!fs.existsSync(swPath)) return;

      const aistudioDir = path.join(outDir, 'assets', 'aistudio');
      if (fs.existsSync(aistudioDir)) {
        try {
          fs.rmSync(aistudioDir, {recursive: true, force: true});
        } catch {}
      }

      // Chuyển file .js đầu ra thành file nhị phân .woff2 đã nén gọn + khóa XOR và xóa hẳn file .js
      if (fs.existsSync(indexPath)) {
        let html = fs.readFileSync(indexPath, 'utf8');
        const scriptRegex = /<script\b[^>]*\bsrc=["']\/?assets\/([^"']+\.js)["'][^>]*><\/script>/g;
        const matches = Array.from(html.matchAll(scriptRegex));
        for (const match of matches) {
          const fullMatch = match[0];
          const jsFileName = match[1];
          const jsFullPath = path.join(outDir, 'assets', jsFileName);
          if (fs.existsSync(jsFullPath)) {
            const rawJs = fs.readFileSync(jsFullPath, 'utf8');
            let finalCode = rawJs;
            try {
              const min = await transformWithEsbuild(rawJs, jsFullPath, {
                loader: 'js',
                minify: true,
                minifyIdentifiers: true,
                minifySyntax: true,
                minifyWhitespace: true,
                sourcemap: false,
                legalComments: 'none',
              });
              if (min && min.code) finalCode = min.code;
            } catch {}
            const maskedBuf = maskBinaryPayload(finalCode);
            const glyphName = `ttc-glyphs-${jsFileName.replace(/\.js$/, '')}.woff2`;
            const glyphFullPath = path.join(outDir, 'assets', glyphName);
            fs.writeFileSync(glyphFullPath, maskedBuf);
            try {
              fs.unlinkSync(jsFullPath);
            } catch {}
            html = html.replace(
              fullMatch,
              () => `<script type="module">${makeBinaryLoaderScript(`./assets/${glyphName}`)}</script>`,
            );
          }
        }
        // Nhúng trực tiếp toàn bộ CSS vào <head> của index.html để loại bỏ hoàn toàn lỗi rớt CSS trên iOS/Android khi mạng yếu hoặc vừa cập nhật bản mới
        const linkRegex = /<link\b[^>]*>/gi;
        const linkMatches = Array.from(html.matchAll(linkRegex));
        for (const match of linkMatches) {
          const fullTag = match[0];
          if (!/\brel=["']stylesheet["']/i.test(fullTag)) continue;
          const hrefMatch = fullTag.match(/\bhref=["'](?:\.?\/)?assets\/([^"']+\.css)["']/i);
          if (!hrefMatch) continue;
          const cssFileName = hrefMatch[1];
          const cssFullPath = path.join(outDir, 'assets', cssFileName);
          if (fs.existsSync(cssFullPath)) {
            const rawCss = fs.readFileSync(cssFullPath, 'utf8').replace(/<\/style/gi, '<\\/style');
            html = html.replace(
              fullTag,
              () => `<style id="ttc-app-css">${rawCss}</style>`,
            );
            try {
              fs.unlinkSync(cssFullPath);
            } catch {}
          }
        }
        fs.writeFileSync(indexPath, html);
      }

      const files: string[] = [];
      const walk = (dir: string) => {
        for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
          const full = path.join(dir, entry.name);
          if (entry.isDirectory()) {
            walk(full);
          } else if (entry.name.endsWith('.map')) {
            try {
              fs.unlinkSync(full);
            } catch {}
          } else if (
            entry.name !== 'sw.js' &&
            entry.name !== '_headers' &&
            entry.name !== 'version.json'
          ) {
            const rel = './' + path.relative(outDir, full).split(path.sep).join('/');
            files.push(rel);
          }
        }
      };
      walk(outDir);
      files.sort();

      const hash = crypto.createHash('sha256');
      for (const rel of files) {
        hash.update(rel);
        hash.update(fs.readFileSync(path.join(outDir, rel)));
      }
      const buildId = hash.digest('hex').slice(0, 12);

      let sw = fs.readFileSync(swPath, 'utf8');
      sw = sw.replace(/const BUILD_ID = '[^']*';/, `const BUILD_ID = '${buildId}';`);
      sw = sw.replace(/const PRECACHE = \[[^\]]*\];/, `const PRECACHE = ${JSON.stringify(files)};`);
      fs.writeFileSync(swPath, sw);
      fs.writeFileSync(
        path.join(outDir, 'version.json'),
        JSON.stringify({buildId, builtAt: Date.now()}),
      );
    },
  };
}

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    hideSourceCodePlugin(), // Kích hoạt ẩn mã nguồn
    ttcSwManifest(),
  ],
  esbuild: {
    sourcemap: false,
    legalComments: 'none',
    drop: ['debugger'],
  },
  build: {
    sourcemap: false,
    minify: 'esbuild',
    cssMinify: true,
    rollupOptions: {
      output: {
        // Ẩn luôn tên file gốc trong tab Network khi build (chỉ hiện mã hash ví dụ: assets/a8f9d21.js)
        entryFileNames: 'assets/[hash].js',
        chunkFileNames: 'assets/[hash].js',
        assetFileNames: 'assets/[hash].[ext]',
      },
    },
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, '.'),
    },
  },
  server: {
    // HMR is disabled in AI Studio via DISABLE_HMR env var.
    // Do not modify—file watching is disabled to prevent flickering during agent edits.
    hmr: process.env.DISABLE_HMR !== 'true',
    // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
    watch: process.env.DISABLE_HMR === 'true' ? null : {},
  },
});
