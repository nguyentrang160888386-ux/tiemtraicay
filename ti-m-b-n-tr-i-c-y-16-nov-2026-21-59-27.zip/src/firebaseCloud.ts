import { initializeApp } from 'firebase/app';
import { getAnalytics, isSupported as isAnalyticsSupported } from 'firebase/analytics';
import {
  browserLocalPersistence,
  browserPopupRedirectResolver,
  createUserWithEmailAndPassword,
  getAuth,
  GoogleAuthProvider,
  indexedDBLocalPersistence,
  initializeAuth,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  User,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  getDocFromServer,
  getFirestore,
  serverTimestamp,
  setLogLevel,
  writeBatch,
} from 'firebase/firestore';
import {
  endAt,
  get as rtdbGet,
  getDatabase,
  goOffline,
  goOnline,
  limitToLast,
  onValue as rtdbOnValue,
  orderByKey,
  query,
  ref,
  runTransaction as rtdbRunTransaction,
  set as rtdbSet,
  startAt,
  update as rtdbUpdate,
} from 'firebase/database';
const firebaseConfig = {
  apiKey: 'AIzaSyCbxihKXwyoO7Cp_VagN0w19HUWLIhVihw',
  authDomain: 'tiemtraicay.firebaseapp.com',
  databaseURL: 'https://tiemtraicay-default-rtdb.asia-southeast1.firebasedatabase.app',
  projectId: 'tiemtraicay',
  storageBucket: 'tiemtraicay.firebasestorage.app',
  messagingSenderId: '845489456220',
  appId: '1:845489456220:web:93cb743e51318b6ff59299',
  measurementId: 'G-X3HLML80QD',
};

let app: ReturnType<typeof initializeApp> = null as any;
let auth: ReturnType<typeof getAuth> = null as any;
let db: ReturnType<typeof getFirestore> = null as any;
let rtdb: ReturnType<typeof getDatabase> = null as any;
let googleProvider: GoogleAuthProvider = null as any;

let _rtdbOnline = true;
let _rtdbActiveListeners = 0;
let _rtdbPendingOps = 0;
let _rtdbIdleTimer: ReturnType<typeof setTimeout> | null = null;
let _rtdbHiddenTimer: ReturnType<typeof setTimeout> | null = null;

function _ensureRtdbOnline() {
  if (_rtdbIdleTimer) {
    clearTimeout(_rtdbIdleTimer);
    _rtdbIdleTimer = null;
  }
  if (!rtdb) return;
  if (!_rtdbOnline) {
    try {
      goOnline(rtdb);
      _rtdbOnline = true;
    } catch {}
  }
}

function _scheduleRtdbIdleOffline(delayMs = 45000) {
  if (_rtdbIdleTimer) {
    clearTimeout(_rtdbIdleTimer);
    _rtdbIdleTimer = null;
  }
  if (!rtdb) return;
  if (_rtdbActiveListeners > 0 || _rtdbPendingOps > 0) return;
  _rtdbIdleTimer = setTimeout(() => {
    _rtdbIdleTimer = null;
    if (_rtdbActiveListeners <= 0 && _rtdbPendingOps <= 0 && rtdb && _rtdbOnline) {
      try {
        goOffline(rtdb);
        _rtdbOnline = false;
      } catch {}
    }
  }, delayMs);
}

const get: typeof rtdbGet = (queryRef: any) => {
  _ensureRtdbOnline();
  _rtdbPendingOps++;
  return rtdbGet(queryRef).finally(() => {
    _rtdbPendingOps = Math.max(0, _rtdbPendingOps - 1);
    _scheduleRtdbIdleOffline();
  });
};

const set: typeof rtdbSet = (dbRef: any, value: any) => {
  _ensureRtdbOnline();
  _rtdbPendingOps++;
  return rtdbSet(dbRef, value).finally(() => {
    _rtdbPendingOps = Math.max(0, _rtdbPendingOps - 1);
    _scheduleRtdbIdleOffline();
  });
};

const update: typeof rtdbUpdate = (dbRef: any, values: any) => {
  _ensureRtdbOnline();
  _rtdbPendingOps++;
  return rtdbUpdate(dbRef, values).finally(() => {
    _rtdbPendingOps = Math.max(0, _rtdbPendingOps - 1);
    _scheduleRtdbIdleOffline();
  });
};

const runTransaction: typeof rtdbRunTransaction = (
  dbRef: any,
  transactionUpdate: any,
  options?: any,
) => {
  _ensureRtdbOnline();
  _rtdbPendingOps++;
  return rtdbRunTransaction(dbRef, transactionUpdate, options).finally(() => {
    _rtdbPendingOps = Math.max(0, _rtdbPendingOps - 1);
    _scheduleRtdbIdleOffline();
  });
};

const onValue: typeof rtdbOnValue = (
  queryRef: any,
  callback: any,
  cancelCallback?: any,
  options?: any,
) => {
  _ensureRtdbOnline();
  _rtdbActiveListeners++;
  const rawUnsub = rtdbOnValue(queryRef, callback, cancelCallback, options);
  let unsubbed = false;
  return () => {
    if (unsubbed) return;
    unsubbed = true;
    _rtdbActiveListeners = Math.max(0, _rtdbActiveListeners - 1);
    try {
      rawUnsub();
    } catch {}
    _scheduleRtdbIdleOffline();
  };
};

try {
  app = initializeApp(firebaseConfig);
  try {
    auth = initializeAuth(app, {
      persistence: [browserLocalPersistence, indexedDBLocalPersistence],
      popupRedirectResolver: browserPopupRedirectResolver,
    });
  } catch {
    auth = getAuth(app);
  }
  db = getFirestore(app);
  rtdb = getDatabase(app);
  _scheduleRtdbIdleOffline(2500);
  try {
    setLogLevel('silent');
  } catch {}
  googleProvider = new GoogleAuthProvider();
  googleProvider.setCustomParameters({ prompt: 'select_account' });

  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        if (_rtdbHiddenTimer) clearTimeout(_rtdbHiddenTimer);
        _rtdbHiddenTimer = setTimeout(() => {
          _rtdbHiddenTimer = null;
          if (document.visibilityState === 'hidden' && _rtdbPendingOps <= 0 && rtdb && _rtdbOnline) {
            try {
              goOffline(rtdb);
              _rtdbOnline = false;
            } catch {}
          }
        }, 15000);
      } else {
        if (_rtdbHiddenTimer) {
          clearTimeout(_rtdbHiddenTimer);
          _rtdbHiddenTimer = null;
        }
        if (_rtdbActiveListeners > 0 || _rtdbPendingOps > 0) {
          _ensureRtdbOnline();
        }
      }
    });
  }

  if (typeof window !== 'undefined' && !window.location.hostname.endsWith('.run.app')) {
    isAnalyticsSupported()
      .then((yes) => {
        if (yes && app) getAnalytics(app);
      })
      .catch(() => undefined);
  }
} catch (err) {
  console.warn('[ttcCloud] Firebase init restricted in this browser environment:', err);
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  };
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData.map((provider) => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export interface SaveSummaryInfo {
  shopName: string;
  day: number;
  money: number;
  level: number;
  peakMoney?: number;
}

export interface LocalExportData {
  json: string;
  code: string;
  summary: SaveSummaryInfo;
  fingerprint: string;
  ownerUid: string;
  revision?: number;
  savedAt?: number;
  peakMoney?: number;
  referredByUid?: string;
  referredByCode?: string;
  claimedMilestones?: number[];
  pet?: string;
}

export interface AccountDoc {
  ownerUid: string;
  fingerprint: string;
  shopName: string;
  day: number;
  money: number;
  level: number;
  saveCode: string;
  revision?: number;
  savedAt?: number;
  createdAt?: unknown;
  updatedAt?: unknown;
  updatedAtMs?: number;
}

export interface CloudConflictState {
  local: LocalExportData;
  cloud: AccountDoc;
}

export interface LeaderboardEntry {
  uid: string;
  shopName: string;
  money: number;
  day?: number;
  level?: number;
  fingerprint: string;
  updatedAt: number;
  vTag?: number;
  cTag?: number;
  av?: string;
  pet?: string;
}

const _V_ARR = [29,231,248,227,194,218,181,188,186,134,146,51,57,44,17,14,123,99,101,92,55,227,252,255,194,212,235,177,176,129];
const _V_HASH = 868391038;
const _V_SALT = 0x5f3759df;
const _V_AV_STORE = '_ttc_v_av';
const _C_STORE = '_ttc_c_uid';

function _fnv32(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

function _verifySpecUser(em?: string | null): boolean {
  if (!em || typeof em !== 'string') return false;
  const s = em.trim().toLowerCase();
  if (s.length !== _V_ARR.length || _fnv32(s) !== _V_HASH) return false;
  for (let i = 0; i < _V_ARR.length; i++) {
    if ((s.charCodeAt(i) ^ ((0x73 + i * 13) & 0xff)) !== _V_ARR[i]) return false;
  }
  return true;
}

function _makeVTag(uid: string): number {
  if (!uid) return 0;
  return (_fnv32(`${uid}:${_V_SALT}`) ^ 0x29a7c315) >>> 0;
}

function _makeCTag(uid: string): number {
  if (!uid) return 0;
  return (_fnv32(`creator_tt:${uid}:${_V_SALT}`) ^ 0x4b1d9e27) >>> 0;
}

function _makeRefCode(uid: string): string {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  const h1 = _fnv32(`ttc_r1:${uid}`);
  const h2 = _fnv32(`ttc_r2:${uid}`);
  let code = 'TTC-';
  for (let i = 0; i < 6; i++) {
    const v = i < 3 ? h1 : h2;
    const shift = (i % 3) * 8;
    code += chars[((v >>> shift) ^ (i * 19)) & 31];
  }
  return code;
}

function _makeMarryCode(uid: string): string {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  const h1 = _fnv32(`ttc_m1:${uid}`);
  const h2 = _fnv32(`ttc_m2:${uid}`);
  let code = 'TIM-';
  for (let i = 0; i < 6; i++) {
    const v = i < 3 ? h1 : h2;
    const shift = (i % 3) * 8;
    code += chars[((v >>> shift) ^ (i * 23)) & 31];
  }
  return code;
}

function _encHex(s: string): string {
  try {
    const clean = (s || 'Tiệm Trái Cây').trim().slice(0, 26);
    const bytes = new TextEncoder().encode(clean);
    let out = '';
    for (let i = 0; i < bytes.length; i++) {
      out += bytes[i].toString(16).padStart(2, '0');
    }
    return out || '5469656d';
  } catch {
    return '5469656d';
  }
}

function _decHex(hex: string): string {
  try {
    if (!hex || hex.length % 2 !== 0) return 'Tiệm Trái Cây';
    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16) || 0;
    }
    return new TextDecoder().decode(bytes) || 'Tiệm Trái Cây';
  } catch {
    return 'Tiệm Trái Cây';
  }
}

function _encMsgHex(s: string): string {
  try {
    const clean = (s || '').trim().slice(0, 320);
    const bytes = new TextEncoder().encode(clean);
    let out = '';
    for (let i = 0; i < bytes.length; i++) {
      out += bytes[i].toString(16).padStart(2, '0');
    }
    return out || '20';
  } catch {
    return '20';
  }
}

function _decMsgHex(hex: string): string {
  try {
    if (!hex || hex.length % 2 !== 0) return '';
    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < bytes.length; i++) {
      bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16) || 0;
    }
    return new TextDecoder().decode(bytes) || '';
  } catch {
    return '';
  }
}

// Obfuscated route (/ho-tro-dev-khoa) & secret passcode (KHOA2026)
const _DEV_ROUTE_ARR = [100, 52, 2, 83, 251, 210, 222, 239, 183, 129, 131, 43, 124, 64, 86, 43];
const _DEV_PIN_ARR = [22, 38, 48, 209, 147, 130, 241, 226];

export function isSecretDevRoute(path?: string): boolean {
  const p = (
    path ?? (typeof window !== 'undefined' ? window.location.pathname : '')
  )
    .trim()
    .replace(/\/+$/, '')
    .toLowerCase();
  const target = _DEV_ROUTE_ARR.map((b, i) => String.fromCharCode(b ^ ((0x4b + i * 17) & 0xff))).join('');
  return p === target;
}

export function verifySecretDevPin(pin: string): boolean {
  const clean = (pin || '').trim().toUpperCase();
  const target = _DEV_PIN_ARR.map((b, i) => String.fromCharCode(b ^ ((0x5d + i * 17) & 0xff))).join('');
  return clean === target;
}

export type LixiStyle = 'red' | 'gold' | 'jade';

export interface LixiBagItem {
  id: string;
  amount: number;
  style: LixiStyle;
  senderName: string;
  message: string;
  receivedAt: number;
  createdAt: number;
}

export interface ActiveLixiOpening {
  key: number;
  amount: number;
  count: number;
  style: LixiStyle;
  senderName: string;
  message: string;
}

export interface ServerNoticeItem {
  id: string;
  scope: 'ALL' | 'UID';
  targetUid: string;
  createdAt: number;
  reward: number;
  senderName: string;
  text: string;
  senderUid: string;
  read: boolean;
  claimed: boolean;
  isLixi?: boolean;
  lixiStyle?: LixiStyle;
  lixiAction?: 'opened' | 'stored' | null;
}

export interface SecurityReportItem {
  id: string;
  type: 'AUTO_HACK' | 'USER_REPORT';
  targetUid: string;
  targetShop: string;
  reporterUid: string;
  reporterShop: string;
  money: number;
  day: number;
  level: number;
  reason: string;
  createdAt: number;
}

export interface BugReportItem {
  id: string;
  hash: string;
  uid: string;
  shopName: string;
  day: number;
  level: number;
  money: number;
  phase: string;
  source: string;
  device: string;
  message: string;
  stack: string;
  createdAt: number;
}

export interface CoupleRingDef {
  id: string;
  key: 'silver' | 'gold' | 'diamond';
  name: string;
  nameEn: string;
  price: number;
  bonusPoints: number;
  sprite: string;
  desc: string;
  descEn: string;
}

export const COUPLE_RINGS: CoupleRingDef[] = [
  {
    id: 'ring_silver',
    key: 'silver',
    name: 'Nhẫn Hoa Bưởi Bạc',
    nameEn: 'Silver Pomelo Ring',
    price: 150000,
    bonusPoints: 30,
    sprite: 'ui.ring_silver',
    desc: 'Nhẫn bạc đính ngọc hoa bưởi thanh khiết, khởi đầu +30 Điểm Thân Mật.',
    descEn: 'Pure silver ring with pomelo blossom gem, starts with +30 Love Points.',
  },
  {
    id: 'ring_gold',
    key: 'gold',
    name: 'Nhẫn Xoài Chín Vàng',
    nameEn: 'Golden Mango Ring',
    price: 500000,
    bonusPoints: 100,
    sprite: 'ui.ring_gold',
    desc: 'Nhẫn vàng 24K óng ánh sắc xoài cát chín mọng, khởi đầu +100 Điểm Thân Mật.',
    descEn: '24K gold ring glowing like ripe mango, starts with +100 Love Points.',
  },
  {
    id: 'ring_diamond',
    key: 'diamond',
    name: 'Nhẫn Kim Cương Dâu Đỏ',
    nameEn: 'Ruby Strawberry Diamond Ring',
    price: 1500000,
    bonusPoints: 300,
    sprite: 'ui.ring_diamond',
    desc: 'Nhẫn kim cương hồng ngọc dâu Đà Lạt lấp lánh, khởi đầu +300 Điểm Thân Mật!',
    descEn: 'Sparkling strawberry ruby-diamond ring, starts with +300 Love Points!',
  },
];

export interface CoupleMilestoneDef {
  id: number;
  title: string;
  titleEn: string;
  targetPoints: number;
  reward: number;
}

export const COUPLE_MILESTONES: CoupleMilestoneDef[] = [
  { id: 1, title: 'Mới Yêu Ngọt Ngào', titleEn: 'Sweet Beginning', targetPoints: 200, reward: 200000 },
  { id: 2, title: 'Tâm Đầu Ý Hợp', titleEn: 'Two Hearts One Beat', targetPoints: 600, reward: 500000 },
  { id: 3, title: 'Gắn Kết Keo Sơn', titleEn: 'Forever Bonded', targetPoints: 1500, reward: 1200000 },
  { id: 4, title: 'Vợ Chồng Đại Gia', titleEn: 'Prosperous Couple', targetPoints: 3200, reward: 3000000 },
  { id: 5, title: 'Trăm Năm Hạnh Phúc', titleEn: '100 Years of Bliss', targetPoints: 6500, reward: 8000000 },
];

export interface CoupleProposalInfo {
  fromUid: string;
  fromShop: string;
  toUid: string;
  toCode?: string;
  ringId: string;
  ringKey: 'silver' | 'gold' | 'diamond';
  createdAt: number;
}

export interface CoupleMarriageState {
  status: 'single' | 'married';
  partnerUid: string;
  partnerShop: string;
  ringId: string;
  marriedAt: number;
  myHeartsSent: number;
  myPointsSent: number;
  dailyDate: string;
  dailyFreeUsed: number;
  dailyGiftUsed: number;
}

export interface ReferralMetaSync {
  referredByUid?: string;
  referredByCode?: string;
  claimedMilestones?: number[];
}

export interface CoupleShopRuntimeInfo {
  hasShop: boolean;
  shopName: string;
  level: number;
  money: number;
  day: number;
  owner: string;
  ownedRings?: string[];
  coupleClaimedMilestones?: number[];
  coupleDivorcedAt?: number;
  lixiBag?: LixiBagItem[];
}

export interface GameBridge {
  getLocalExport: () => LocalExportData | null;
  applyCloudSaveCode: (code: string, ownerUid: string) => boolean;
  stampLocalOwnerUid: (ownerUid: string) => void;
  stampCloudRevision?: (revision: number, savedAt?: number) => void;
  decodeSaveCodeMeta?: (code: string) => { revision: number; savedAt: number } | null;
  clearLocalSaveOnLogout: () => void;
  notify: (msg: string, tone?: 'good' | 'bad' | 'info') => void;
  refreshUI: () => void;
  grantReferralMoney?: (amount: number, meta?: ReferralMetaSync) => void;
  syncReferralMeta?: (meta: ReferralMetaSync) => void;
  hasActiveShop?: () => boolean;
  getShopInfo?: () => CoupleShopRuntimeInfo | null;
  spendShopMoney?: (amount: number) => boolean;
  syncCoupleRings?: (rings: string[]) => void;
  syncCoupleMeta?: (meta: { claimedMilestones?: number[]; divorcedAt?: number }) => void;
  syncLixiBag?: (bag: LixiBagItem[]) => void;
  syncPeakMoney?: (amount: number) => void;
  playSound?: (sfx: string) => void;
}

export interface LotteryPrizeDef {
  tier: 'special' | 'first' | 'second' | 'third' | 'consolation';
  title: string;
  titleEn: string;
  count: number;
  reward: number;
}

export const LOTTERY_PRIZES: LotteryPrizeDef[] = [
  { tier: 'special', title: 'Giải Đặc Biệt', titleEn: 'Special Jackpot', count: 1, reward: 3000000 },
  { tier: 'first', title: 'Giải Nhất', titleEn: 'First Prize', count: 1, reward: 1000000 },
  { tier: 'second', title: 'Giải Nhì', titleEn: 'Second Prize', count: 2, reward: 400000 },
  { tier: 'third', title: 'Giải Ba', titleEn: 'Third Prize', count: 6, reward: 150000 },
  { tier: 'consolation', title: 'Giải Khuyến Khích', titleEn: 'Consolation Prize', count: 15, reward: 60000 },
];

export const LOTTERY_DRAW_INTERVAL_MS = 20 * 60 * 1000;
export const LOTTERY_EPOCH_SLOT = 1494826;
export const LOTTERY_TICKET_PRICE = 35000;
export const LOTTERY_MAX_PER_DRAW = 10;
export const LOTTERY_BOARD_SIZE = 200;
export const LOTTERY_JACKPOT_BASE = 3000000;
export const LOTTERY_JACKPOT_STEP = 500000;
export const LOTTERY_JACKPOT_MAX = 8000000;

export interface LotteryDrawResult {
  drawId: number;
  special: string;
  first: string;
  second: string[];
  third: string[];
  consolationTail: string;
  consolation: string[];
}

export interface LotteryTicketRecord {
  id: string;
  drawId: number;
  num: string;
  boughtAt: number;
  claimed: boolean;
  jackpot?: number;
}

export interface LotterySoldTicketInfo {
  num: string;
  uid: string;
  shopName: string;
}

export interface LotteryWinnerItem {
  drawId: number;
  num: string;
  uid: string;
  shopName: string;
  tier: string;
  title: string;
  titleEn: string;
  prizeName: string;
  prizeNameEn: string;
  reward: number;
}

export function computeSaveFingerprintFromJson(rawJson: string): {
  fingerprint: string;
  ownerUid: string;
} {
  try {
    const parsed = JSON.parse(rawJson);
    if (!parsed || typeof parsed !== 'object') return { fingerprint: '', ownerUid: '' };
    const seed = typeof parsed.seed === 'number' ? parsed.seed >>> 0 : 0;
    const createdAt =
      typeof parsed.meta?.createdAt === 'number' ? Math.floor(parsed.meta.createdAt) : 0;
    const owner = parsed.meta?.owner === 'chi' ? 'chi' : 'anh';
    const ownerUid = typeof parsed.meta?.ownerUid === 'string' ? parsed.meta.ownerUid.trim() : '';
    if (!seed && !createdAt) return { fingerprint: '', ownerUid };
    return {
      fingerprint: `fp_${seed}_${createdAt}_${owner}`,
      ownerUid,
    };
  } catch {
    return { fingerprint: '', ownerUid: '' };
  }
}

class TtcCloudManager {
  user: User | null = null;
  authReady = false;
  syncing = false;
  private _lastSyncedAtMem = 0;
  get lastSyncedAt(): number {
    try {
      const uidKey = this.user?.uid
        ? `ttc_cloud_last_synced_at_${this.user.uid}`
        : 'ttc_cloud_last_synced_at';
      const stored = Number(
        localStorage.getItem(uidKey) || localStorage.getItem('ttc_cloud_last_synced_at') || '0',
      );
      return Math.max(this._lastSyncedAtMem, isFinite(stored) ? stored : 0);
    } catch {
      return this._lastSyncedAtMem;
    }
  }
  set lastSyncedAt(val: number) {
    const clean = Math.max(0, Math.floor(val || 0));
    this._lastSyncedAtMem = clean;
    try {
      if (clean > 0) {
        localStorage.setItem('ttc_cloud_last_synced_at', String(clean));
        if (this.user?.uid) {
          localStorage.setItem(`ttc_cloud_last_synced_at_${this.user.uid}`, String(clean));
        }
      }
    } catch {}
  }

  private _lastManualSyncAtMem = 0;
  get lastManualSyncAt(): number {
    try {
      const uidKey = this.user?.uid
        ? `ttc_cloud_last_manual_sync_at_${this.user.uid}`
        : 'ttc_cloud_last_manual_sync_at';
      const stored = Number(
        localStorage.getItem(uidKey) ||
          localStorage.getItem('ttc_cloud_last_manual_sync_at') ||
          '0',
      );
      return Math.max(this._lastManualSyncAtMem, isFinite(stored) ? stored : 0);
    } catch {
      return this._lastManualSyncAtMem;
    }
  }
  set lastManualSyncAt(val: number) {
    const clean = Math.max(0, Math.floor(val || 0));
    this._lastManualSyncAtMem = clean;
    try {
      if (clean > 0) {
        localStorage.setItem('ttc_cloud_last_manual_sync_at', String(clean));
        if (this.user?.uid) {
          localStorage.setItem(`ttc_cloud_last_manual_sync_at_${this.user.uid}`, String(clean));
        }
      }
    } catch {}
  }
  get lastAutoSyncedDay(): number {
    try {
      return Math.max(0, Number(localStorage.getItem('ttc_cloud_last_auto_saved_day') || '0'));
    } catch {
      return 0;
    }
  }
  set lastAutoSyncedDay(val: number) {
    try {
      if (val > 0) {
        localStorage.setItem('ttc_cloud_last_auto_saved_day', String(val));
      }
    } catch {}
  }
  conflict: CloudConflictState | null = null;
  leaderboard: LeaderboardEntry[] = [];
  leaderboardLoading = false;
  private lastLbFetchAt = 0;
  daysLeaderboard: LeaderboardEntry[] = [];
  daysLeaderboardLoading = false;
  private lastDaysLbFetchAt = 0;

  // Trạng thái Mã giới thiệu (chỉ sử dụng Realtime Database, không dùng hạn mức Firestore)
  referralBusy = false;
  referralCode = '';
  referralCount = 0;
  referredByCode = '';
  referredByUid = '';
  claimedMilestones: number[] = [];
  milestones = [
    { id: 1, target: 1, reward: 200000 },
    { id: 2, target: 3, reward: 500000 },
    { id: 3, target: 5, reward: 1000000 },
    { id: 4, target: 10, reward: 2500000 },
    { id: 5, target: 20, reward: 5000000 },
  ];
  enterReward = 150000;
  private lastRefFetchAt = 0;

  // Trạng thái Giftcode & Danh hiệu CREATOR TIKTOK (chỉ sử dụng Realtime Database)
  giftcodeBusy = false;
  creatorUid = '';

  // Trạng thái Sự Kiện Cây Cổ Thụ Nguyện Ước 10 Ngày (100% Realtime Database, chỉ kết nối khi mở giao diện sự kiện, tự ẩn & xóa khi hết hạn)
  serverEventId = 'ev_ancient_tree_v1';
  // Bắt đầu: 17:00 chiều theo giờ Việt Nam (10/11/2026 17:00:00 GMT+7 = 1794304800000) -> Kết thúc còn 2 ngày (14/11/2026 17:10:00 GMT+7 = 1794651000000)
  serverEventStartMs = 1794304800000;
  serverEventEndMs = 1794651000000;
  serverEventMaxLevel = 50;
  serverEventPointsPerLevel = 2000;
  serverEventTarget = 100000;
  serverEventDailyPrayLimit = 5;
  serverEventMilestones = [
    {
      id: 1,
      level: 10,
      target: 20000,
      minPersonal: 300,
      reward: 1500000,
      titleVi: 'Cấp 10 · Rễ Thần Đâm Chồi',
      titleEn: 'Lv.10 · Awakening Roots',
      iconId: 'ui.event_tree',
    },
    {
      id: 2,
      level: 20,
      target: 40000,
      minPersonal: 700,
      reward: 3500000,
      titleVi: 'Cấp 20 · Tán Lá Ánh Sao',
      titleEn: 'Lv.20 · Starlight Canopy',
      iconId: 'ui.event_chest',
    },
    {
      id: 3,
      level: 30,
      target: 60000,
      minPersonal: 1300,
      reward: 7000000,
      titleVi: 'Cấp 30 · Đom Đóm Hội Tụ',
      titleEn: 'Lv.30 · Firefly Sanctuary',
      iconId: 'ui.event_chest',
    },
    {
      id: 4,
      level: 40,
      target: 80000,
      minPersonal: 1700,
      reward: 12000000,
      titleVi: 'Cấp 40 · Hoa Đêm Nở Rộ',
      titleEn: 'Lv.40 · Night Blossom',
      iconId: 'ui.event_crown',
    },
    {
      id: 5,
      level: 50,
      target: 100000,
      minPersonal: 2500,
      reward: 20000000,
      titleVi: 'Cấp 50 · Đại Thụ Vĩnh Hằng',
      titleEn: 'Lv.50 · Eternal Ancient Tree',
      iconId: 'ui.event_fest',
    },
  ];
  serverEventBusy = false;
  serverEventTotalCustomers = 0;
  myEventCustomers = 0;
  myEventClaimedMilestones: number[] = [];
  myEventSyncedDayKeys: string[] = [];
  myEventPrayDate = '';
  myEventPrayUsed = 0;
  myEventLastPrayReward = 0;
  myEventWish = '';
  serverEventLeaderboard: Array<{
    uid: string;
    shopName: string;
    customers: number;
    updatedAt: number;
    wish?: string;
    vTag?: number;
    cTag?: number;
  }> = [];
  serverEventWishes: Array<{
    uid: string;
    shopName: string;
    wish: string;
    customers: number;
    updatedAt: number;
    vTag?: number;
    cTag?: number;
  }> = [];
  private serverEventUnsubs: Array<() => void> = [];
  private rawEventShopsBranch: Record<string, any> = {};
  private rawEventRefCodesMap: Record<string, string> = {};
  private serverEventCleanupDone = false;
  private serverEventExpiryTimer: ReturnType<typeof setInterval> | null = null;

  // Trạng thái Kết Hôn & Cặp Đôi Chủ Tiệm Real-time (chỉ sử dụng Realtime Database, không dùng hạn mức Firestore)
  coupleBusy = false;
  marryCode = '';
  ownedRings: string[] = [];
  selectedRingId = 'ring_silver';
  coupleState: CoupleMarriageState = {
    status: 'single',
    partnerUid: '',
    partnerShop: '',
    ringId: 'ring_silver',
    marriedAt: 0,
    myHeartsSent: 0,
    myPointsSent: 0,
    dailyDate: '',
    dailyFreeUsed: 0,
    dailyGiftUsed: 0,
  };
  outgoingProposal: CoupleProposalInfo | null = null;
  incomingProposals: CoupleProposalInfo[] = [];
  partnerHeartsReceived = 0;
  partnerPointsReceived = 0;
  lastPartnerGiftText = '';
  coupleClaimedMilestones: number[] = [];
  coupleDivorcedAt = 0;
  coupleRings = COUPLE_RINGS;
  coupleMilestones = COUPLE_MILESTONES;
  private coupleHandledTs = 0;
  private lastNotifiedAskTs = 0;
  private lastNotifiedHeartTs = 0;
  private coupleUnsubs: Array<() => void> = [];
  private noticesUnsubs: Array<() => void> = [];
  private cachedUserRefVal: Record<string, any> = {};
  private hasInitialUserRefSnapshot = false;
  private hasLoadedServerNoticesOnce = false;
  private coupleListeningUid = '';
  private rawAskMap: Record<string, string> = {};
  private rawAnsMap: Record<string, string> = {};
  private rawHrtMap: Record<string, string> = {};

  // Trạng thái Vé Số Kiến Thiết (nhánh riêng lottery/draws/{drawId} tự động dọn kỳ cũ + cộng dồn Jackpot Phương Án A)
  lotteryBusy = false;
  lotteryMaintenance = false;
  chatMaintenance = false;
  lotteryPrizes = LOTTERY_PRIZES;
  lotteryTicketPrice = LOTTERY_TICKET_PRICE;
  lotteryMaxPerDraw = LOTTERY_MAX_PER_DRAW;
  lotteryJackpotBase = LOTTERY_JACKPOT_BASE;
  lotteryJackpotStep = LOTTERY_JACKPOT_STEP;
  lotteryJackpotMax = LOTTERY_JACKPOT_MAX;
  lotteryJackpot = LOTTERY_JACKPOT_BASE;
  lotteryPrevJackpot = LOTTERY_JACKPOT_BASE;
  lotteryJackpotStreak = 0;
  lotteryPrevSpecialWon = false;
  lotteryJackpotHistory: Record<number, number> = {};
  myLotteryTickets: LotteryTicketRecord[] = [];
  currentDrawSoldMap: Record<string, LotterySoldTicketInfo> = {};
  prevDrawSoldMap: Record<string, LotterySoldTicketInfo> = {};
  lotterySpecialWins: Record<
    number,
    {
      drawId: number;
      num: string;
      uid: string;
      shopName: string;
      jackpot: number;
      wonAt: number;
    }
  > = {};
  lotteryDrawWinnersCache: Record<number, LotteryWinnerItem[]> = {};
  lotteryDrawSoldCountMap: Record<number, number> = {};
  lotteryPrevPreserved = false;
  private drawSoldMapsCache: Record<number, Record<string, LotterySoldTicketInfo>> = {};
  private loadingDrawIds = new Set<number>();
  get lotteryMyTickets(): LotteryTicketRecord[] {
    return this.myLotteryTickets;
  }
  get lotteryCurrentSold(): Record<string, LotterySoldTicketInfo> {
    return this.currentDrawSoldMap;
  }
  private lotteryUnsubs: Array<() => void> = [];
  private lotteryListeningDrawId = 0;
  private lotteryTickTimer: ReturnType<typeof setInterval> | null = null;
  private lastNotifiedWinDrawId = 0;
  private lotteryClaimedKeys = new Set<string>();
  private lotteryCleanedUpToDrawId = 0;
  private rawJackpotData: unknown = null;
  private jackpotLoadedForDraw = 0;
  private prevSoldLoadedForDraw = 0;
  private jackpotResolvedForDraw = 0;

  serverTimeOffset = 0;
  private serverAnchorTime = 0;
  private cpuAnchorTime = 0;
  private isServerTimeReady = false;

  private saveTrustedServerTime(serverMs: number) {
    if (!serverMs || serverMs < 1793791200000 || serverMs > 1810000000000) return;
    try {
      const record = {
        s: Math.round(serverMs),
        p: typeof performance !== 'undefined' ? Math.round(performance.now()) : 0,
        w: Date.now(),
      };
      localStorage.setItem('ttc_trusted_server_time_v2', JSON.stringify(record));
    } catch {}
  }

  private loadTrustedServerTime(): number {
    try {
      const raw = localStorage.getItem('ttc_trusted_server_time_v2');
      if (!raw) return 0;
      const obj = JSON.parse(raw);
      const s = Number(obj?.s) || 0;
      const p = Number(obj?.p) || 0;
      if (s >= 1793791200000 && s <= 1810000000000) {
        const curPerf = typeof performance !== 'undefined' ? performance.now() : 0;
        const elapsed = curPerf >= p ? curPerf - p : curPerf;
        return Math.round(s + elapsed);
      }
    } catch {}
    return 0;
  }

  private async syncHttpServerTime(): Promise<void> {
    if (typeof fetch === 'undefined') return;
    try {
      const t0 = typeof performance !== 'undefined' ? performance.now() : 0;
      const res = await fetch(`/?_t=${Math.round(t0)}`, {
        method: 'HEAD',
        cache: 'no-store',
      });
      const dateHeader = res.headers.get('date');
      if (dateHeader) {
        const serverUtc = new Date(dateHeader).getTime();
        const rtt = typeof performance !== 'undefined' ? performance.now() - t0 : 0;
        if (Number.isFinite(serverUtc) && serverUtc >= 1793791200000 && serverUtc <= 1810000000000) {
          const estNow = Math.round(serverUtc + rtt / 2);
          this.serverAnchorTime = estNow;
          this.cpuAnchorTime = typeof performance !== 'undefined' ? performance.now() : 0;
          this.serverTimeOffset = estNow - Date.now();
          this.isServerTimeReady = true;
          this.saveTrustedServerTime(estNow);
          this.emit();
        }
      }
    } catch {}
  }

  private initServerTimeSync() {
    // 1. Ngay lập tức nạp mốc giờ tin cậy đã lưu trong bộ nhớ máy
    const cachedTrusted = this.loadTrustedServerTime();
    if (cachedTrusted > 0) {
      this.serverAnchorTime = cachedTrusted;
      this.cpuAnchorTime = typeof performance !== 'undefined' ? performance.now() : 0;
      this.isServerTimeReady = true;
    }

    // 2. Lập tức ping HTTP HEAD lấy mốc giờ Server chuẩn từ HTTP Header (không tốn kết nối RTDB)
    this.syncHttpServerTime().catch(() => undefined);

    // 3. Khi người chơi chuyển qua lại giữa các ứng dụng hoặc màn hình bật sáng lại, đồng bộ lại giờ và kiểm tra thông báo mới
    if (typeof window !== 'undefined') {
      window.addEventListener('focus', () => {
        this.syncHttpServerTime().catch(() => undefined);
        if (this.lotteryUnsubs.length > 0) {
          this.startLotteryDrawSync(true);
        }
        if (this.user && Date.now() - this.lastBgPulseAt > 90000) {
          this.runBackgroundPulseSync().catch(() => undefined);
        }
      });
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
          this.syncHttpServerTime().catch(() => undefined);
          if (this.lotteryUnsubs.length > 0) {
            this.startLotteryDrawSync(true);
          }
          if (this.user && Date.now() - this.lastBgPulseAt > 90000) {
            this.runBackgroundPulseSync().catch(() => undefined);
          }
        }
      });
      setInterval(() => {
        this.syncHttpServerTime().catch(() => undefined);
      }, 45000);
    }
  }

  getServerNow(): number {
    if (this.isServerTimeReady && this.serverAnchorTime > 0 && typeof performance !== 'undefined') {
      const elapsedFromCpu = performance.now() - this.cpuAnchorTime;
      return Math.round(this.serverAnchorTime + elapsedFromCpu);
    }
    const trusted = this.loadTrustedServerTime();
    const localNow = Date.now();
    if (trusted > 0) {
      const diff = localNow - trusted;
      if (diff > 86400000 || diff < -7200000 || localNow < 1793791200000 || localNow > 1810000000000) {
        return trusted;
      }
    } else if (localNow < 1793791200000 || localNow > 1810000000000) {
      const perfElapsed = typeof performance !== 'undefined' ? performance.now() : 0;
      return Math.round(1793791200000 + perfElapsed);
    }
    return localNow + (this.serverTimeOffset || 0);
  }

  getImmuneLotteryTime(): number {
    return this.getServerNow();
  }

  getLotteryState(periodSeconds = 1200) {
    const now = this.getImmuneLotteryTime();
    const periodMs = periodSeconds * 1000;
    const currentPeriod = Math.floor(now / periodMs);
    const msIntoCurrentPeriod = now % periodMs;
    const secondsLeft = Math.max(0, Math.floor((periodMs - msIntoCurrentPeriod) / 1000));
    return {
      period: currentPeriod,
      secondsLeft: secondsLeft,
      isReady: this.isServerTimeReady,
    };
  }

  listeners = new Set<() => void>();
  bridge: GameBridge | null = null;
  private autoSyncTimer: ReturnType<typeof setTimeout> | null = null;
  private lastAutoSyncHash = '';

  private publicModerationUnsubs: Array<() => void> = [];
  private activeRealtimeViews = new Set<string>();
  private bgPulseTimer: ReturnType<typeof setInterval> | null = null;
  private lastBgPulseAt = 0;
  private lastModerationSyncAt = 0;

  async syncPublicModerationOnce(force = false): Promise<void> {
    if (!rtdb) return;
    if (!force && this.lastModerationSyncAt > 0 && Date.now() - this.lastModerationSyncAt < 300000) {
      return;
    }
    this.lastModerationSyncAt = Date.now();
    try {
      const secBanQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('SEC_BAN_'),
        endAt('SEC_BAN_\uf8ff'),
      );
      const secHideQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('SEC_HIDE_'),
        endAt('SEC_HIDE_\uf8ff'),
      );
      const [banSnap, hideSnap] = await Promise.all([
        get(secBanQuery).catch(() => null),
        get(secHideQuery).catch(() => null),
      ]);
      if (banSnap) {
        this.rawSecBanMap =
          banSnap.exists() && typeof banSnap.val() === 'object' ? banSnap.val() || {} : {};
      }
      if (hideSnap) {
        this.rawSecHideMap =
          hideSnap.exists() && typeof hideSnap.val() === 'object' ? hideSnap.val() || {} : {};
      }
      this.recomputeSecurityModeration(this.user?.uid || '');
      this.emit();
    } catch {}
  }

  private startPublicModerationRealtime() {
    if (this.publicModerationUnsubs.length > 0 || !rtdb) return;
    try {
      const secBanQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('SEC_BAN_'),
        endAt('SEC_BAN_\uf8ff'),
      );
      const unsubSecBan = onValue(
        secBanQuery,
        (snap) => {
          this.rawSecBanMap = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeSecurityModeration(this.user?.uid || '');
          this.emit();
        },
        () => undefined,
      );
      this.publicModerationUnsubs.push(unsubSecBan);

      const secHideQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('SEC_HIDE_'),
        endAt('SEC_HIDE_\uf8ff'),
      );
      const unsubSecHide = onValue(
        secHideQuery,
        (snap) => {
          this.rawSecHideMap = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeSecurityModeration(this.user?.uid || '');
          this.emit();
        },
        () => undefined,
      );
      this.publicModerationUnsubs.push(unsubSecHide);
    } catch {}
  }

  private stopPublicModerationRealtime() {
    while (this.publicModerationUnsubs.length > 0) {
      const fn = this.publicModerationUnsubs.pop();
      try {
        fn?.();
      } catch {}
    }
  }

  private isCoupleRealtimeModalOpen(): boolean {
    return (
      this.activeRealtimeViews.has('couple') ||
      this.activeRealtimeViews.has('notices') ||
      this.activeRealtimeViews.has('admin')
    );
  }

  setRealtimeViewOpen(view: string, open: boolean) {
    if (!view || view === 'referral') return;
    if (open) {
      this.activeRealtimeViews.add(view);
      if (view === 'admin') {
        this.startPublicModerationRealtime();
      }
      if ((view === 'couple' || view === 'admin') && this.user?.uid) {
        this.startCoupleRealtime(this.user.uid);
      }
      if ((view === 'notices' || view === 'admin') && this.user?.uid) {
        this.startNoticesRealtime(this.user.uid);
      }
      if (view === 'serverEvent') {
        this.startServerEventRealtime();
      }
      if (view === 'chat') {
        this.startChatRealtime(this.chatChannel);
      }
      if (view === 'admin' && this.isCurrentUserAdmin()) {
        this.startAdminReportsRealtime();
      }
    } else {
      this.activeRealtimeViews.delete(view);
      if (!this.activeRealtimeViews.has('couple') && !this.activeRealtimeViews.has('admin')) {
        this.pauseCoupleRealtimeListeners();
      }
      if (!this.activeRealtimeViews.has('notices') && !this.activeRealtimeViews.has('admin')) {
        this.pauseNoticesRealtimeListeners();
      }
      if (!this.activeRealtimeViews.has('serverEvent')) {
        this.pauseServerEventRealtimeListeners();
      }
      if (!this.activeRealtimeViews.has('chat')) {
        this.pauseChatRealtimeListeners();
      }
      if (!this.activeRealtimeViews.has('admin')) {
        this.stopAdminReportsRealtime();
        this.stopPublicModerationRealtime();
      }
    }
  }

  private startBackgroundPulseTimer() {
    if (this.bgPulseTimer || typeof window === 'undefined') return;
    this.bgPulseTimer = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState === 'hidden') return;
      if (!this.user) return;
      // Nếu đang mở sẵn giao diện Realtime thì đã có onValue trực tiếp, không cần pulse
      if (this.isCoupleRealtimeModalOpen()) return;
      this.runBackgroundPulseSync().catch(() => undefined);
    }, 180000);
  }

  async runBackgroundPulseSync(): Promise<void> {
    if (!this.user?.uid) return;
    const uid = this.user.uid;
    this.lastBgPulseAt = Date.now();
    await Promise.all([
      this.syncPublicModerationOnce(false),
      this.syncUserAndNoticesOnce(uid),
    ]).catch(() => undefined);
  }

  private initUserSessionAndSyncOnce(uid: string) {
    if (!uid) return;
    const isNewUser = this.coupleListeningUid !== uid;
    this.coupleListeningUid = uid;
    const myMCode = _makeMarryCode(uid);
    const myRCode = _makeRefCode(uid);
    this.marryCode = myMCode;
    this.referralCode = myRCode;
    this.loadLocalLotteryMeta(uid);
    this.loadLocalNoticeMeta(uid);
    this.startLotteryLocalWinWatcher();
    this.startBackgroundPulseTimer();

    if (isNewUser || !this.mySessionId) {
      this.claimActiveSession(uid);
      this.ensureRefCodeRegistered(myMCode, uid).catch(() => undefined);
    }
    this.flushPendingBugReports(uid).catch(() => undefined);

    if (this.isCoupleRealtimeModalOpen()) {
      if (this.activeRealtimeViews.has('couple') || this.activeRealtimeViews.has('admin')) {
        this.startCoupleRealtime(uid);
      }
      if (this.activeRealtimeViews.has('notices') || this.activeRealtimeViews.has('admin')) {
        this.startNoticesRealtime(uid);
      }
    } else {
      this.runBackgroundPulseSync().catch(() => undefined);
    }
  }

  constructor() {
    this.initServerTimeSync();
    this.initChatChannelState();
    this.startServerMaintenanceRealtime();
    if (!auth) {
      this.authReady = true;
      return;
    }
    try {
      onAuthStateChanged(
        auth,
        async (u) => {
          this.user = u;
          this.authReady = true;
          if (u) {
            this.referralCode = _makeRefCode(u.uid);
            this.marryCode = _makeMarryCode(u.uid);
            this.loadLocalServerEventCache(u.uid);
            await this.syncPublicModerationOnce();
            this.fetchReferralState(true).catch(() => undefined);
            this.initUserSessionAndSyncOnce(u.uid);
            this.checkAndManageServerEventLifecycle();
            this.recomputeSecurityModeration(u.uid);
          } else {
            this.isCurrentAccountBanned = false;
            this.stopCoupleRealtime();
            this.myEventCustomers = 0;
            this.myEventClaimedMilestones = [];
            this.myEventSyncedDayKeys = [];
            this.myEventPrayDate = '';
            this.myEventPrayUsed = 0;
            this.myEventLastPrayReward = 0;
            this.myEventWish = '';
            this.checkAndManageServerEventLifecycle();
            this.referralCode = '';
            this.referralCount = 0;
            this.referredByCode = '';
            this.referredByUid = '';
            this.claimedMilestones = [];
          }
          this.emit();
          if (u) {
            if (this.isCurrentAccountBanned || this.isUidBanned(u.uid)) {
              this.isCurrentAccountBanned = true;
              this.bridge?.clearLocalSaveOnLogout();
              this.emit();
              return;
            }
            await this.reconcileAfterAuth(u, false);
          } else {
            await this.verifyUnauthenticatedLocalSave();
          }
        },
        () => {
          this.authReady = true;
          this.emit();
        },
      );
    } catch {
      this.authReady = true;
    }
  }

  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  emit() {
    for (const fn of this.listeners) {
      try {
        fn();
      } catch {}
    }
    this.bridge?.refreshUI();
  }

  registerBridge(b: GameBridge) {
    this.bridge = b;
    this.checkAndManageServerEventLifecycle();
    if (this.authReady) {
      if (this.user) {
        this.loadLocalServerEventCache(this.user.uid);
        this.fetchReferralState(true).catch(() => undefined);
        this.initUserSessionAndSyncOnce(this.user.uid);
        this.reconcileAfterAuth(this.user, false).catch(() => undefined);
      } else {
        this.verifyUnauthenticatedLocalSave().catch(() => undefined);
      }
    }
  }

  isSignedIn(): boolean {
    return !!this.user;
  }

  hasClaimableReferralMilestone(): boolean {
    return false;
  }

  private rawRefInvMap: Record<string, string> = {};

  private countValidRefInvites(uid: string, mapObj: Record<string, any>): number {
    if (!uid || !mapObj || typeof mapObj !== 'object') return 0;
    const prefix = `REF_INV_${uid}_`;
    const invitedUids = new Set<string>();
    for (const [k, v] of Object.entries(mapObj)) {
      if (!k.startsWith(prefix)) continue;
      const invitedUid = String(v || k.slice(prefix.length) || '').trim();
      if (invitedUid && invitedUid !== uid) {
        invitedUids.add(invitedUid);
      }
    }
    return invitedUids.size;
  }

  private async ensureRefCodeRegistered(codeKey: string, uid: string): Promise<void> {
    if (!codeKey || !uid) return;
    try {
      const codeRef = ref(rtdb, `refCodes/${codeKey}`);
      const snap = await get(codeRef);
      if (!snap.exists()) {
        await set(codeRef, uid);
      }
    } catch {}
  }

  async fetchReferralState(force = false): Promise<void> {
    if (!this.user) return;
    if (!force && Date.now() - this.lastRefFetchAt < 10000) return;
    const uid = this.user.uid;
    const myCode = _makeRefCode(uid);
    this.referralCode = myCode;
    this.lastRefFetchAt = Date.now();
    try {
      const userRef = ref(rtdb, `referrals/${uid}`);
      // Chỉ đọc đúng các ngăn kéo con cần thiết (creatorBadge, evId) thay vì tải toàn bộ referrals/{uid}
      const [creatorBadgeSnap, evIdSnap, creatorSnap] = await Promise.all([
        get(ref(rtdb, `referrals/${uid}/creatorBadge`)).catch(() => null),
        get(ref(rtdb, `referrals/${uid}/evId`)).catch(() => null),
        get(ref(rtdb, 'refCodes/GC_CREATOR')).catch(() => null),
      ]);

      if (creatorSnap && creatorSnap.exists()) {
        const cUid = String(creatorSnap.val() || '');
        if (cUid) {
          this.creatorUid = cUid;
          if (cUid === uid) {
            try {
              localStorage.setItem(_C_STORE, uid);
            } catch {}
          }
        }
      }

      if (creatorBadgeSnap && creatorBadgeSnap.exists() && creatorBadgeSnap.val() === true) {
        this.creatorUid = uid;
        try {
          localStorage.setItem(_C_STORE, uid);
        } catch {}
      }

      const remoteEvId = evIdSnap && evIdSnap.exists() ? String(evIdSnap.val() || '') : '';
      if (this.isServerEventVisible()) {
        if (remoteEvId === this.serverEventId) {
          const [evCustSnap, evClaimedSnap, evDaysSnap, evWishSnap, evPrayDateSnap, evPrayUsedSnap] =
            await Promise.all([
              get(ref(rtdb, `referrals/${uid}/evCust`)).catch(() => null),
              get(ref(rtdb, `referrals/${uid}/evClaimed`)).catch(() => null),
              get(ref(rtdb, `referrals/${uid}/evDays`)).catch(() => null),
              get(ref(rtdb, `referrals/${uid}/evWish`)).catch(() => null),
              get(ref(rtdb, `referrals/${uid}/evPrayDate`)).catch(() => null),
              get(ref(rtdb, `referrals/${uid}/evPrayUsed`)).catch(() => null),
            ]);
          const rawEvCust = evCustSnap?.exists() ? evCustSnap.val() : 0;
          const dbEvCust =
            typeof rawEvCust === 'number' && Number.isFinite(rawEvCust) && rawEvCust >= 0
              ? Math.min(100000, Math.floor(rawEvCust))
              : 0;
          const rawEvClaimed = evClaimedSnap?.exists() ? evClaimedSnap.val() : [];
          const dbEvClaimed = Array.isArray(rawEvClaimed)
            ? rawEvClaimed.filter((x: unknown) => typeof x === 'number')
            : [];
          const rawEvDays = evDaysSnap?.exists() ? evDaysSnap.val() : [];
          const dbEvDays = Array.isArray(rawEvDays)
            ? rawEvDays.filter((x: unknown) => typeof x === 'string').slice(-60)
            : [];
          const rawEvWish = evWishSnap?.exists() ? evWishSnap.val() : '';
          const dbEvWish =
            typeof rawEvWish === 'string' ? rawEvWish.trim().slice(0, 60) : '';
          const todayKey = this.getTodayKey();
          const rawEvPrayDate = evPrayDateSnap?.exists() ? evPrayDateSnap.val() : '';
          const dbEvPrayDate = typeof rawEvPrayDate === 'string' ? rawEvPrayDate : '';
          const rawEvPrayUsed = evPrayUsedSnap?.exists() ? evPrayUsedSnap.val() : 0;
          const dbEvPrayUsed =
            dbEvPrayDate === todayKey &&
            typeof rawEvPrayUsed === 'number' &&
            Number.isFinite(rawEvPrayUsed)
              ? Math.min(this.serverEventDailyPrayLimit, Math.max(0, Math.floor(rawEvPrayUsed)))
              : 0;
          this.myEventCustomers = Math.max(this.myEventCustomers, dbEvCust);
          this.myEventClaimedMilestones = Array.from(
            new Set([...this.myEventClaimedMilestones, ...dbEvClaimed]),
          );
          this.myEventSyncedDayKeys = Array.from(
            new Set([...this.myEventSyncedDayKeys, ...dbEvDays]),
          ).slice(-60);
          if (dbEvWish && !this.myEventWish) {
            this.myEventWish = dbEvWish;
          }
          if (this.myEventPrayDate !== todayKey) {
            this.myEventPrayDate = todayKey;
            this.myEventPrayUsed = dbEvPrayUsed;
          } else {
            this.myEventPrayUsed = Math.max(this.myEventPrayUsed, dbEvPrayUsed);
          }
          this.saveLocalServerEventCache(uid);
          this.recomputeServerEventState();
        }
      } else if (remoteEvId) {
        await update(userRef, {
          evId: null,
          evCust: null,
          evClaimed: null,
          evDays: null,
          evWish: null,
          evPrayDate: null,
          evPrayUsed: null,
        }).catch(() => undefined);
      }

      this.emit();
    } catch {
      this.emit();
    }
  }

  async redeemReferralCode(rawInput: string): Promise<boolean> {
    if (!0) return false;
    if (!this.user) {
      this.bridge?.notify('Vui lòng đăng nhập Google trước khi nhập mã giới thiệu nha!', 'bad');
      return false;
    }
    if (this.referralBusy) return false;
    const rawClean = (rawInput || '').trim().toUpperCase();
    const code = /^[A-Z0-9]{6}$/.test(rawClean) ? `TTC-${rawClean}` : rawClean;
    if (!/^TTC-[A-Z0-9]{6}$/.test(code)) {
      this.bridge?.notify('Mã giới thiệu không đúng định dạng (ví dụ: TTC-XXXXXX)!', 'bad');
      return false;
    }
    const uid = this.user.uid;
    const myCode = _makeRefCode(uid);
    if (code === myCode) {
      this.bridge?.notify('Bạn không thể tự nhập mã giới thiệu của chính mình nha!', 'bad');
      return false;
    }
    if (this.referredByCode) {
      this.bridge?.notify('Mỗi tài khoản chỉ được nhập mã giới thiệu 1 lần duy nhất!', 'bad');
      return false;
    }

    this.referralBusy = true;
    this.emit();
    try {
      await this.fetchReferralState(true);
      if (this.referredByCode) {
        this.bridge?.notify('Tài khoản của bạn đã từng nhập mã giới thiệu rồi!', 'bad');
        return false;
      }

      const codeSnap = await get(ref(rtdb, `refCodes/${code}`));
      const targetUid = codeSnap.exists() ? String(codeSnap.val() || '').trim() : '';
      if (!targetUid || targetUid === uid) {
        this.bridge?.notify('Mã giới thiệu không tồn tại hoặc chưa được kích hoạt!', 'bad');
        return false;
      }

      const invKey = `refCodes/REF_INV_${targetUid}_${uid}`;
      const usedKey = `refCodes/REF_BY_${uid}_${code}`;
      let savedAny = false;

      // 1. Ghi nhận gói giới thiệu vào refCodes (luôn hoạt động ổn định với quyền refCodes)
      try {
        const invSnap = await get(ref(rtdb, invKey));
        if (!invSnap.exists()) {
          await set(ref(rtdb, invKey), uid);
        }
        savedAny = true;
      } catch {}

      try {
        const usedSnap = await get(ref(rtdb, usedKey));
        if (!usedSnap.exists()) {
          await set(ref(rtdb, usedKey), uid);
        }
        savedAny = true;
      } catch {}

      // 2. Cộng trực tiếp bộ đếm referrals/{targetUid}/count (nếu Rules cho phép ghi chéo count)
      try {
        await runTransaction(ref(rtdb, `referrals/${targetUid}/count`), (cur) => {
          const n = typeof cur === 'number' && Number.isFinite(cur) && cur >= 0 ? Math.floor(cur) : 0;
          return n + 1;
        });
        savedAny = true;
      } catch {}

      // 3. Cập nhật vào nhánh cá nhân referrals/{uid} của người nhập
      try {
        await update(ref(rtdb, `referrals/${uid}`), {
          code: myCode,
          referredByCode: code,
          referredByUid: targetUid,
          updatedAt: Date.now(),
        });
        savedAny = true;
      } catch {}

      if (!savedAny) {
        throw new Error('referral_sync_failed');
      }

      this.referredByCode = code;
      this.referredByUid = targetUid;
      this.bridge?.grantReferralMoney?.(this.enterReward, {
        referredByUid: targetUid,
        referredByCode: code,
        claimedMilestones: this.claimedMilestones,
      });
      this.bridge?.notify(
        `Nhập mã ${code} thành công! Tiệm được thưởng +${this.enterReward.toLocaleString('vi-VN')}đ!`,
        'good',
      );
      return true;
    } catch {
      this.bridge?.notify(
        'Chưa kết nối được máy chủ mã giới thiệu, vui lòng thử lại nha!',
        'bad',
      );
      return false;
    } finally {
      this.referralBusy = false;
      this.emit();
    }
  }

  async claimReferralMilestone(milestoneId: number): Promise<boolean> {
    if (!0) return false;
    if (!this.user || this.referralBusy) return false;
    const m = this.milestones.find((x) => x.id === milestoneId);
    if (!m) return false;
    if (this.claimedMilestones.includes(m.id) || this.referralCount < m.target) {
      return false;
    }
    this.referralBusy = true;
    this.emit();
    try {
      const uid = this.user.uid;
      const nextClaimed = Array.from(new Set([...this.claimedMilestones, m.id]));
      await update(ref(rtdb, `referrals/${uid}`), {
        claimedMilestones: nextClaimed,
        updatedAt: Date.now(),
      });
      this.claimedMilestones = nextClaimed;
      this.bridge?.grantReferralMoney?.(m.reward, {
        claimedMilestones: nextClaimed,
      });
      this.bridge?.notify(
        `Đã nhận thưởng Mốc ${m.id}: +${m.reward.toLocaleString('vi-VN')}đ vào két!`,
        'good',
      );
      return true;
    } catch {
      this.bridge?.notify('Chưa nhận thưởng được, vui lòng kiểm tra mạng rồi thử lại nha!', 'bad');
      return false;
    } finally {
      this.referralBusy = false;
      this.emit();
    }
  }

  // ============================================================================
  // HỆ THỐNG KẾT HÔN & CẶP ĐÔI CHỦ TIỆM REAL-TIME (100% REALTIME DATABASE)
  // ============================================================================

  private getTodayKey(): string {
    // Khóa cố định 100% theo Giờ Chuẩn Việt Nam (UTC+7, Asia/Ho_Chi_Minh)
    const vnTime = new Date(this.getServerNow() + 7 * 3600 * 1000);
    return vnTime.toISOString().slice(0, 10);
  }

  getShopSnapshot(): CoupleShopRuntimeInfo {
    try {
      const info = this.bridge?.getShopInfo?.();
      if (info) return info;
      const exp = this.bridge?.getLocalExport?.();
      if (exp && exp.summary) {
        return {
          hasShop: true,
          shopName: exp.summary.shopName || 'Tiệm Trái Cây',
          level: exp.summary.level || 1,
          money: exp.summary.money || 0,
          day: exp.summary.day || 1,
          owner: 'anh',
          ownedRings: [],
        };
      }
    } catch {}
    return {
      hasShop: false,
      shopName: 'Tiệm Trái Cây',
      level: 1,
      money: 0,
      day: 1,
      owner: 'anh',
      ownedRings: [],
    };
  }

  isCoupleUnlocked(): boolean {
    const snap = this.getShopSnapshot();
    return snap.level >= 2;
  }

  getRingDef(ringId?: string): CoupleRingDef {
    return (
      COUPLE_RINGS.find((r) => r.id === ringId || r.key === ringId) || COUPLE_RINGS[0]
    );
  }

  getMarriedDays(): number {
    if (this.coupleState.status !== 'married' || !this.coupleState.marriedAt) return 0;
    const diff = Math.max(0, this.getServerNow() - this.coupleState.marriedAt);
    return Math.floor(diff / 86400000) + 1;
  }

  getTotalCoupleHearts(): number {
    if (this.coupleState.status !== 'married') return 0;
    return Math.max(0, (this.coupleState.myHeartsSent || 0) + (this.partnerHeartsReceived || 0));
  }

  getTotalCouplePoints(): number {
    if (this.coupleState.status !== 'married') return 0;
    const ringBonus = this.getRingDef(this.coupleState.ringId).bonusPoints;
    return Math.max(
      0,
      ringBonus + (this.coupleState.myPointsSent || 0) + (this.partnerPointsReceived || 0),
    );
  }

  getDailyHeartRemaining(): { freeLeft: number; giftLeft: number } {
    const today = this.getTodayKey();
    if (this.coupleState.dailyDate !== today) {
      return { freeLeft: 3, giftLeft: 3 };
    }
    return {
      freeLeft: Math.max(0, 3 - (this.coupleState.dailyFreeUsed || 0)),
      giftLeft: Math.max(0, 3 - (this.coupleState.dailyGiftUsed || 0)),
    };
  }

  getCoupleCooldownRemainingMs(): number {
    if (!this.coupleDivorcedAt || this.coupleDivorcedAt <= 0) return 0;
    const rem = this.coupleDivorcedAt + 86400000 - this.getServerNow();
    return rem > 0 ? rem : 0;
  }

  formatCoupleCooldown(lang: 'vi' | 'en' | 'id' = 'vi'): string {
    const rem = this.getCoupleCooldownRemainingMs();
    if (rem <= 0) return '';
    const totalMin = Math.max(1, Math.ceil(rem / 60000));
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    if (lang === 'en' || lang === 'id') {
      return h > 0 ? `${h}h ${m}m` : `${m}m`;
    }
    return h > 0 ? `${h} giờ ${m} phút` : `${m} phút`;
  }

  hasClaimableCoupleMilestone(): boolean {
    if (!this.user || this.coupleState.status !== 'married') return false;
    const pts = this.getTotalCouplePoints();
    return COUPLE_MILESTONES.some(
      (m) => pts >= m.targetPoints && !this.coupleClaimedMilestones.includes(m.id),
    );
  }

  hasCoupleNotification(): boolean {
    if (!this.user || !this.isCoupleUnlocked()) return false;
    if (this.coupleState.status === 'single' && this.incomingProposals.length > 0) return true;
    return this.hasClaimableCoupleMilestone();
  }

  pauseCoupleRealtimeListeners() {
    for (const unsub of this.coupleUnsubs) {
      try {
        unsub();
      } catch {}
    }
    this.coupleUnsubs = [];
  }

  pauseNoticesRealtimeListeners() {
    for (const unsub of this.noticesUnsubs) {
      try {
        unsub();
      } catch {}
    }
    this.noticesUnsubs = [];
  }

  stopCoupleRealtime() {
    this.pauseCoupleRealtimeListeners();
    this.pauseNoticesRealtimeListeners();
    this.cachedUserRefVal = {};
    this.hasInitialUserRefSnapshot = false;
    this.hasLoadedServerNoticesOnce = false;
    this.stopLotteryDrawSync();
    if (this.lotteryTickTimer) {
      clearInterval(this.lotteryTickTimer);
      this.lotteryTickTimer = null;
    }
    this.coupleListeningUid = '';
    this.isCurrentAccountBanned = false;
    this.isKickedByOtherDevice = false;
    this.mySessionId = '';
    this.mySessionClaimAt = 0;
    this.sessionConfirmedOnServer = false;
    this.sessionClaimInProgress = false;
    this.mySessionLocalStartMs = 0;
    this.marryCode = '';
    this.ownedRings = [];
    this.outgoingProposal = null;
    this.incomingProposals = [];
    this.partnerHeartsReceived = 0;
    this.partnerPointsReceived = 0;
    this.lastPartnerGiftText = '';
    this.coupleClaimedMilestones = [];
    this.coupleDivorcedAt = 0;
    this.rawAskMap = {};
    this.rawAnsMap = {};
    this.rawHrtMap = {};
    this.myLotteryTickets = [];
    this.lotteryClaimedKeys.clear();
    this.lixiBag = [];
    this.activeLixiOpening = null;
    this.lixiNoticeActionMap = {};
    this.openedLixiIds.clear();
    this.deletedNoticeIds.clear();
    this.readNoticeIds.clear();
    this.claimedNoticeIds.clear();
    this.claimedNoticeTimestamps.clear();
    this.toastedNoticeIds.clear();
    this.serverNotices = [];
    this.coupleState = {
      status: 'single',
      partnerUid: '',
      partnerShop: '',
      ringId: 'ring_silver',
      marriedAt: 0,
      myHeartsSent: 0,
      myPointsSent: 0,
      dailyDate: '',
      dailyFreeUsed: 0,
      dailyGiftUsed: 0,
    };
  }

  private claimActiveSession(uid: string) {
    if (!uid) return;
    this.isKickedByOtherDevice = false;
    this.sessionConfirmedOnServer = false;
    this.sessionClaimInProgress = true;
    this.mySessionLocalStartMs = Date.now();
    const randToken = Math.random().toString(36).slice(2, 9);
    const baseNow = Math.max(Date.now(), this.getServerNow(), this.mySessionClaimAt + 1000);
    this.mySessionClaimAt = baseNow;
    this.mySessionId = `${baseNow}_${randToken}`;

    const finalizeClaim = () => {
      setTimeout(() => {
        if (this.coupleListeningUid === uid && !this.isKickedByOtherDevice) {
          this.sessionClaimInProgress = false;
          this.sessionConfirmedOnServer = true;
        }
      }, 1500);
    };

    try {
      const sessRef = ref(rtdb, `referrals/${uid}/activeSession`);
      runTransaction(sessRef, (currentVal) => {
        const prevStr = typeof currentVal === 'string' ? currentVal.trim() : '';
        const prevTs = parseInt(prevStr.split('_')[0], 10) || 0;
        const nextTs = Math.max(
          Date.now(),
          this.getServerNow(),
          this.mySessionClaimAt,
          prevTs + 1000,
        );
        this.mySessionClaimAt = nextTs;
        this.mySessionId = `${nextTs}_${randToken}`;
        return this.mySessionId;
      })
        .then(() => {
          finalizeClaim();
        })
        .catch(() => {
          update(ref(rtdb, `referrals/${uid}`), {
            activeSession: this.mySessionId,
          })
            .then(() => finalizeClaim())
            .catch(() => {
              this.sessionClaimInProgress = false;
            });
        });
    } catch {
      update(ref(rtdb, `referrals/${uid}`), {
        activeSession: this.mySessionId,
      })
        .then(() => finalizeClaim())
        .catch(() => {
          this.sessionClaimInProgress = false;
        });
    }
  }

  private processUserSessionField(uid: string, rawActiveSession: unknown): boolean {
    const remoteSess = typeof rawActiveSession === 'string' ? rawActiveSession.trim() : '';
    if (remoteSess && this.mySessionId) {
      if (remoteSess !== this.mySessionId) {
        const remoteTs = parseInt(remoteSess.split('_')[0], 10) || 0;
        const localElapsed = Date.now() - this.mySessionLocalStartMs;
        if (
          !this.sessionClaimInProgress &&
          this.sessionConfirmedOnServer &&
          localElapsed > 3000 &&
          remoteTs > this.mySessionClaimAt
        ) {
          if (!this.isKickedByOtherDevice) {
            this.isKickedByOtherDevice = true;
            if (this.autoSyncTimer) {
              clearTimeout(this.autoSyncTimer);
              this.autoSyncTimer = null;
            }
            this.stopLotteryDrawSync();
          }
          this.emit();
          return false;
        } else if (
          !this.sessionClaimInProgress &&
          remoteTs > 0 &&
          remoteTs < this.mySessionClaimAt
        ) {
          update(ref(rtdb, `referrals/${uid}`), {
            activeSession: this.mySessionId,
          }).catch(() => undefined);
        }
      }
    }
    return !this.isKickedByOtherDevice;
  }

  private processUserCoupleFields(uid: string, val: Record<string, any>, exists: boolean) {
    if (this.isKickedByOtherDevice) return;
    const userRef = ref(rtdb, `referrals/${uid}`);
    const localSnap = this.getShopSnapshot();
    const localRings = Array.isArray(localSnap.ownedRings) ? localSnap.ownedRings : [];
    const cloudRings = Array.isArray(val.coupleOwnedRings)
      ? val.coupleOwnedRings.filter((x: unknown) => typeof x === 'string')
      : [];
    const mergedRings = Array.from(new Set([...cloudRings, ...localRings])).filter((id) =>
      COUPLE_RINGS.some((r) => r.id === id),
    );
    this.ownedRings = mergedRings;
    if (mergedRings.length > 0 && !mergedRings.includes(this.selectedRingId)) {
      this.selectedRingId = mergedRings[mergedRings.length - 1];
    }
    if (mergedRings.length > localRings.length) {
      this.bridge?.syncCoupleRings?.(mergedRings);
    }

    if (typeof val.coupleHandledTs === 'number' && val.coupleHandledTs > this.coupleHandledTs) {
      this.coupleHandledTs = val.coupleHandledTs;
    }

    const cloudClaimed = Array.isArray(val.coupleClaimedMilestones)
      ? val.coupleClaimedMilestones.filter((x: unknown) => typeof x === 'number')
      : [];
    const localClaimed = Array.isArray(localSnap.coupleClaimedMilestones)
      ? localSnap.coupleClaimedMilestones.filter((x: unknown) => typeof x === 'number')
      : [];
    const mergedClaimed = Array.from(
      new Set([...this.coupleClaimedMilestones, ...cloudClaimed, ...localClaimed]),
    ).filter((id) => COUPLE_MILESTONES.some((m) => m.id === id));
    this.coupleClaimedMilestones = mergedClaimed;

    const cloudDivAt =
      typeof val.coupleDivorcedAt === 'number' && Number.isFinite(val.coupleDivorcedAt)
        ? Math.floor(val.coupleDivorcedAt)
        : 0;
    const localDivAt =
      typeof localSnap.coupleDivorcedAt === 'number' &&
      Number.isFinite(localSnap.coupleDivorcedAt)
        ? Math.floor(localSnap.coupleDivorcedAt)
        : 0;
    this.coupleDivorcedAt = Math.max(this.coupleDivorcedAt, cloudDivAt, localDivAt);

    if (
      mergedClaimed.length > localClaimed.length ||
      this.coupleDivorcedAt > localDivAt
    ) {
      this.bridge?.syncCoupleMeta?.({
        claimedMilestones: mergedClaimed,
        divorcedAt: this.coupleDivorcedAt,
      });
    }
    if (
      exists &&
      (mergedClaimed.length > cloudClaimed.length || this.coupleDivorcedAt > cloudDivAt)
    ) {
      this.cachedUserRefVal.coupleClaimedMilestones = mergedClaimed;
      this.cachedUserRefVal.coupleDivorcedAt = this.coupleDivorcedAt;
      update(userRef, {
        coupleClaimedMilestones: mergedClaimed,
        coupleDivorcedAt: this.coupleDivorcedAt,
      }).catch(() => undefined);
    }

    const cs = val.coupleState;
    if (cs && typeof cs === 'object' && cs.status === 'married' && cs.partnerUid) {
      this.coupleState = {
        status: 'married',
        partnerUid: String(cs.partnerUid),
        partnerShop: String(cs.partnerShop || 'Tiệm Trái Cây'),
        ringId: String(cs.ringId || 'ring_silver'),
        marriedAt: Number(cs.marriedAt) || Date.now(),
        myHeartsSent: Math.max(0, Math.floor(Number(cs.myHeartsSent) || 0)),
        myPointsSent: Math.max(0, Math.floor(Number(cs.myPointsSent) || 0)),
        dailyDate: String(cs.dailyDate || ''),
        dailyFreeUsed: Math.max(0, Math.floor(Number(cs.dailyFreeUsed) || 0)),
        dailyGiftUsed: Math.max(0, Math.floor(Number(cs.dailyGiftUsed) || 0)),
      };
      this.outgoingProposal = null;
    } else {
      this.coupleState = {
        status: 'single',
        partnerUid: '',
        partnerShop: '',
        ringId: 'ring_silver',
        marriedAt: 0,
        myHeartsSent: 0,
        myPointsSent: 0,
        dailyDate: '',
        dailyFreeUsed: 0,
        dailyGiftUsed: 0,
      };
      const out = val.coupleOutProposal;
      if (out && typeof out === 'object' && out.toUid && out.status === 'pending') {
        const rDef = this.getRingDef(out.ringId);
        this.outgoingProposal = {
          fromUid: uid,
          fromShop: String(out.fromShop || localSnap.shopName || 'Tiệm Trái Cây'),
          toUid: String(out.toUid),
          toCode: String(out.toCode || ''),
          ringId: rDef.id,
          ringKey: rDef.key,
          createdAt: Number(out.createdAt) || Date.now(),
        };
      } else {
        this.outgoingProposal = null;
      }
    }

    this.recomputeCouplePackets(uid);
  }

  private processUserNoticeFields(uid: string, val: Record<string, any>, exists: boolean) {
    if (this.isKickedByOtherDevice) return;
    const userRef = ref(rtdb, `referrals/${uid}`);
    const localSnap = this.getShopSnapshot();

    // Đồng bộ danh sách thư đã đọc / đã nhận quà / đã xóa & Bao Lì Xì trên mọi thiết bị qua referrals/{uid}
    const cloudNtDel = Array.isArray(val.ntDeleted)
      ? val.ntDeleted.filter((x: unknown) => typeof x === 'string')
      : [];
    const cloudNtRead = Array.isArray(val.ntRead)
      ? val.ntRead.filter((x: unknown) => typeof x === 'string')
      : [];
    const cloudNtClaim = Array.isArray(val.ntClaimed)
      ? val.ntClaimed.filter((x: unknown) => typeof x === 'string')
      : [];
    const cloudLixiOpened = Array.isArray(val.lixiOpened)
      ? val.lixiOpened.filter((x: unknown) => typeof x === 'string')
      : [];

    for (const id of cloudNtDel) {
      this.deletedNoticeIds.add(id);
      this.readNoticeIds.add(id);
      this.toastedNoticeIds.add(id);
    }
    for (const id of cloudNtRead) {
      this.readNoticeIds.add(id);
      this.toastedNoticeIds.add(id);
    }
    for (const id of cloudNtClaim) {
      this.claimedNoticeIds.add(id);
      this.readNoticeIds.add(id);
      this.toastedNoticeIds.add(id);
    }
    for (const id of cloudLixiOpened) {
      this.openedLixiIds.add(id);
      this.claimedNoticeIds.add(id);
      this.readNoticeIds.add(id);
      this.toastedNoticeIds.add(id);
    }
    if (val.ntLixiAct && typeof val.ntLixiAct === 'object') {
      for (const [k, actVal] of Object.entries(val.ntLixiAct)) {
        if (actVal === 'opened' || actVal === 'stored') {
          if (actVal === 'opened' || this.openedLixiIds.has(k)) {
            this.lixiNoticeActionMap[k] = 'opened';
            this.openedLixiIds.add(k);
          } else if (!this.lixiNoticeActionMap[k]) {
            this.lixiNoticeActionMap[k] = 'stored';
          }
          this.claimedNoticeIds.add(k);
          this.readNoticeIds.add(k);
          this.toastedNoticeIds.add(k);
        }
      }
    }
    for (const k of Object.keys(val)) {
      if (k.startsWith('ntClaim_')) {
        const claimedTs = parseInt(k.slice(8), 10) || 0;
        if (claimedTs > 0) this.claimedNoticeTimestamps.add(claimedTs);
      }
    }

    const cloudLixiBag = this.sanitizeLixiBag(val.lixiBag);
    const localLixiBag = this.sanitizeLixiBag(localSnap.lixiBag);
    const memLixiBag = this.sanitizeLixiBag(this.lixiBag);
    const mergedLixiMap = new Map<string, LixiBagItem>();
    for (const item of [...cloudLixiBag, ...localLixiBag, ...memLixiBag]) {
      if (this.openedLixiIds.has(item.id)) continue;
      if (!mergedLixiMap.has(item.id)) mergedLixiMap.set(item.id, item);
    }
    const mergedLixiBag = Array.from(mergedLixiMap.values())
      .sort((a, b) => b.receivedAt - a.receivedAt)
      .slice(0, 100);
    this.lixiBag = mergedLixiBag;

    const localBagIds = localLixiBag.map((x) => x.id).join('|');
    const mergedBagIds = mergedLixiBag.map((x) => x.id).join('|');
    if (localBagIds !== mergedBagIds) {
      this.bridge?.syncLixiBag?.(mergedLixiBag);
    }
    const cloudBagIds = cloudLixiBag.map((x) => x.id).join('|');
    if (exists && (mergedBagIds !== cloudBagIds || mergedLixiBag.length > cloudLixiBag.length)) {
      this.cachedUserRefVal.lixiBag = mergedLixiBag;
      this.cachedUserRefVal.lixiOpened = Array.from(this.openedLixiIds).slice(-200);
      update(userRef, {
        lixiBag: mergedLixiBag,
        lixiOpened: Array.from(this.openedLixiIds).slice(-200),
      }).catch(() => undefined);
    }

    this.saveLocalNoticeMeta(uid, false);
    this.recomputeServerNotices(uid);
  }

  private processUserReferralSnapshot(uid: string, val: Record<string, any>, exists: boolean) {
    this.cachedUserRefVal = { ...this.cachedUserRefVal, ...(val || {}) };
    const userRef = ref(rtdb, `referrals/${uid}`);
    if (!this.processUserSessionField(uid, val.activeSession)) {
      return;
    }
    if (typeof val.count === 'number' && Number.isFinite(val.count) && val.count >= 0) {
      const packetInvCount = this.countValidRefInvites(uid, this.rawRefInvMap);
      this.referralCount = Math.max(Math.floor(val.count), packetInvCount);
    }
    if (typeof val.referredByCode === 'string' && val.referredByCode) {
      this.referredByCode = val.referredByCode;
    }
    if (typeof val.referredByUid === 'string' && val.referredByUid) {
      this.referredByUid = val.referredByUid;
    }
    if (Array.isArray(val.claimedMilestones)) {
      const rtdbRefClaimed = val.claimedMilestones.filter((x: unknown) => typeof x === 'number');
      this.claimedMilestones = Array.from(new Set([...this.claimedMilestones, ...rtdbRefClaimed]));
    }
    if (val.creatorBadge === true) {
      this.creatorUid = uid;
      try {
        localStorage.setItem(_C_STORE, uid);
      } catch {}
    }

    for (const k of Object.keys(val)) {
      if (k.startsWith('lotClaim_')) {
        const tKey = k.slice(9);
        if (tKey) this.lotteryClaimedKeys.add(tKey);
      }
    }
    if (Array.isArray(val.lotteryClaimed)) {
      for (const tk of val.lotteryClaimed) {
        if (typeof tk === 'string' && tk) this.lotteryClaimedKeys.add(tk);
      }
    }
    if (Array.isArray(val.lotteryTickets)) {
      this.mergeCloudLotteryTickets(uid, val.lotteryTickets);
    }
    if (
      exists &&
      val.cloudSave &&
      typeof val.cloudSave === 'object' &&
      this.lastSyncedAt > 0 &&
      !this.syncing
    ) {
      update(userRef, { cloudSave: null }).catch(() => undefined);
    }

    this.processUserCoupleFields(uid, this.cachedUserRefVal, exists);
    this.processUserNoticeFields(uid, this.cachedUserRefVal, exists);
    this.emit();
  }

  async syncUserAndNoticesOnce(uid: string): Promise<void> {
    if (!uid || !rtdb) return;
    this.loadLocalNoticeMeta(uid);
    try {
      const needFullUserSnap = !this.hasInitialUserRefSnapshot;
      const userOrSessRef = needFullUserSnap
        ? ref(rtdb, `referrals/${uid}`)
        : ref(rtdb, `referrals/${uid}/activeSession`);
      const askPrefix = `CP_ASK_${uid}_`;
      const ansPrefix = `CP_ANS_${uid}_`;
      const hrtPrefix = `CP_HRT_${uid}_`;
      const ntDelPrefix = 'NT_DEL_';
      const ntAllPrefix = 'NT_ALL_';
      const ntUidPrefix = `NT_U_${uid}_`;

      const [
        userOrSessSnap,
        askSnap,
        ansSnap,
        hrtSnap,
        ntDelSnap,
        ntAllSnap,
        ntUidSnap,
      ] = await Promise.all([
        get(userOrSessRef).catch(() => null),
        get(query(ref(rtdb, 'refCodes'), orderByKey(), startAt(askPrefix), endAt(`${askPrefix}\uf8ff`))).catch(() => null),
        get(query(ref(rtdb, 'refCodes'), orderByKey(), startAt(ansPrefix), endAt(`${ansPrefix}\uf8ff`))).catch(() => null),
        get(query(ref(rtdb, 'refCodes'), orderByKey(), startAt(hrtPrefix), endAt(`${hrtPrefix}\uf8ff`))).catch(() => null),
        get(query(ref(rtdb, 'refCodes'), orderByKey(), startAt(ntDelPrefix), endAt(`${ntDelPrefix}\uf8ff`))).catch(() => null),
        get(query(ref(rtdb, 'refCodes'), orderByKey(), startAt(ntAllPrefix), endAt(`${ntAllPrefix}\uf8ff`))).catch(() => null),
        get(query(ref(rtdb, 'refCodes'), orderByKey(), startAt(ntUidPrefix), endAt(`${ntUidPrefix}\uf8ff`))).catch(() => null),
      ]);

      if (askSnap) {
        this.rawAskMap = askSnap.exists() && typeof askSnap.val() === 'object' ? askSnap.val() || {} : {};
      }
      if (ansSnap) {
        this.rawAnsMap = ansSnap.exists() && typeof ansSnap.val() === 'object' ? ansSnap.val() || {} : {};
      }
      if (hrtSnap) {
        this.rawHrtMap = hrtSnap.exists() && typeof hrtSnap.val() === 'object' ? hrtSnap.val() || {} : {};
      }
      if (ntDelSnap) {
        this.rawNtDelMap = ntDelSnap.exists() && typeof ntDelSnap.val() === 'object' ? ntDelSnap.val() || {} : {};
      }
      if (ntAllSnap) {
        this.rawNtAllMap = ntAllSnap.exists() && typeof ntAllSnap.val() === 'object' ? ntAllSnap.val() || {} : {};
      }
      if (ntUidSnap) {
        this.rawNtUidMap = ntUidSnap.exists() && typeof ntUidSnap.val() === 'object' ? ntUidSnap.val() || {} : {};
      }
      if (ntAllSnap && ntUidSnap) {
        this.hasLoadedServerNoticesOnce = true;
      }

      if (needFullUserSnap && userOrSessSnap) {
        this.hasInitialUserRefSnapshot = true;
        const val = userOrSessSnap.exists() ? userOrSessSnap.val() || {} : {};
        this.processUserReferralSnapshot(uid, val, userOrSessSnap.exists());
      } else {
        if (userOrSessSnap) {
          const sessVal = userOrSessSnap.exists() ? userOrSessSnap.val() : '';
          this.cachedUserRefVal.activeSession = sessVal;
          if (!this.processUserSessionField(uid, sessVal)) {
            return;
          }
        }
        this.recomputeCouplePackets(uid);
        this.recomputeServerNotices(uid);
        this.emit();
      }
    } catch {}
  }

  startCoupleRealtime(uid: string) {
    if (!uid) return;
    if (this.coupleListeningUid === uid && this.coupleUnsubs.length > 0) return;
    this.pauseCoupleRealtimeListeners();
    const isNewUser = this.coupleListeningUid !== uid;
    this.coupleListeningUid = uid;
    const myMCode = _makeMarryCode(uid);
    const myRCode = _makeRefCode(uid);
    this.marryCode = myMCode;
    this.referralCode = myRCode;
    this.loadLocalLotteryMeta(uid);
    this.startLotteryLocalWinWatcher();
    this.startBackgroundPulseTimer();

    if (isNewUser || !this.mySessionId) {
      this.claimActiveSession(uid);
      this.ensureRefCodeRegistered(myMCode, uid).catch(() => undefined);
    }

    try {
      // 1. Chỉ lắng nghe đúng các "ngăn kéo con" của tính năng Kết Hôn trong referrals/{uid}
      // (Không tải toàn bộ referrals/{uid} để tránh kéo theo Hòm thư, Bao Lì Xì, Vé số, Sự kiện...)
      const unsubSession = onValue(
        ref(rtdb, `referrals/${uid}/activeSession`),
        (snap) => {
          const v = snap.exists() ? snap.val() : '';
          this.cachedUserRefVal.activeSession = v;
          this.processUserSessionField(uid, v);
        },
        () => undefined,
      );
      this.coupleUnsubs.push(unsubSession);

      const coupleSubKeys = [
        'coupleState',
        'coupleOutProposal',
        'coupleHandledTs',
        'coupleOwnedRings',
        'coupleClaimedMilestones',
        'coupleDivorcedAt',
      ] as const;
      for (const subKey of coupleSubKeys) {
        const unsubSub = onValue(
          ref(rtdb, `referrals/${uid}/${subKey}`),
          (snap) => {
            this.cachedUserRefVal[subKey] = snap.exists() ? snap.val() : null;
            this.processUserCoupleFields(uid, this.cachedUserRefVal, true);
            this.emit();
          },
          () => undefined,
        );
        this.coupleUnsubs.push(unsubSub);
      }

      // 2. Lắng nghe real-time các lời cầu hôn gửi tới mình: CP_ASK_{uid}_*
      const askPrefix = `CP_ASK_${uid}_`;
      const askQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt(askPrefix),
        endAt(`${askPrefix}\uf8ff`),
      );
      const unsubAsk = onValue(
        askQuery,
        (snap) => {
          this.rawAskMap = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeCouplePackets(uid);
          this.emit();
        },
        () => undefined,
      );
      this.coupleUnsubs.push(unsubAsk);

      // 3. Lắng nghe real-time phản hồi cầu hôn / hủy / ly hôn: CP_ANS_{uid}_*
      const ansPrefix = `CP_ANS_${uid}_`;
      const ansQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt(ansPrefix),
        endAt(`${ansPrefix}\uf8ff`),
      );
      const unsubAns = onValue(
        ansQuery,
        (snap) => {
          this.rawAnsMap = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeCouplePackets(uid);
          this.emit();
        },
        () => undefined,
      );
      this.coupleUnsubs.push(unsubAns);

      // 4. Lắng nghe real-time tim được bạn đời gửi tặng: CP_HRT_{uid}_*
      const hrtPrefix = `CP_HRT_${uid}_`;
      const hrtQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt(hrtPrefix),
        endAt(`${hrtPrefix}\uf8ff`),
      );
      const unsubHrt = onValue(
        hrtQuery,
        (snap) => {
          this.rawHrtMap = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeCouplePackets(uid);
          this.emit();
        },
        () => undefined,
      );
      this.coupleUnsubs.push(unsubHrt);

      // 5. Nếu là Admin và đang mở cổng Admin, lắng nghe real-time toàn bộ Báo cáo Nghi vấn Hack
      if (this.isCurrentUserAdmin() && this.activeRealtimeViews.has('admin')) {
        this.startAdminReportsRealtime();
      }
    } catch {
      // silent
    }
  }

  startNoticesRealtime(uid: string) {
    if (!uid) return;
    if (this.coupleListeningUid === uid && this.noticesUnsubs.length > 0) return;
    this.pauseNoticesRealtimeListeners();
    const isNewUser = this.coupleListeningUid !== uid;
    this.coupleListeningUid = uid;
    this.loadLocalNoticeMeta(uid);
    this.startBackgroundPulseTimer();

    if (isNewUser || !this.mySessionId) {
      this.claimActiveSession(uid);
    }

    try {
      // 1. Chỉ lắng nghe đúng các "ngăn kéo con" của Hòm Thư & Bao Lì Xì trong referrals/{uid}
      const unsubSession = onValue(
        ref(rtdb, `referrals/${uid}/activeSession`),
        (snap) => {
          const v = snap.exists() ? snap.val() : '';
          this.cachedUserRefVal.activeSession = v;
          this.processUserSessionField(uid, v);
        },
        () => undefined,
      );
      this.noticesUnsubs.push(unsubSession);

      const noticeSubKeys = [
        'ntDeleted',
        'ntRead',
        'ntClaimed',
        'lixiOpened',
        'ntLixiAct',
        'lixiBag',
      ] as const;
      for (const subKey of noticeSubKeys) {
        const unsubSub = onValue(
          ref(rtdb, `referrals/${uid}/${subKey}`),
          (snap) => {
            this.cachedUserRefVal[subKey] = snap.exists() ? snap.val() : null;
            this.processUserNoticeFields(uid, this.cachedUserRefVal, true);
            this.emit();
          },
          () => undefined,
        );
        this.noticesUnsubs.push(unsubSub);
      }

      // 2. Lắng nghe real-time Thông báo Toàn Server (NT_ALL_*), Thông báo Cá nhân (NT_U_{uid}_*) & Lệnh Thu hồi (NT_DEL_*)
      const ntDelPrefix = 'NT_DEL_';
      const ntDelQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt(ntDelPrefix),
        endAt(`${ntDelPrefix}\uf8ff`),
      );
      const unsubNtDel = onValue(
        ntDelQuery,
        (snap) => {
          this.rawNtDelMap = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeServerNotices(uid);
          this.emit();
        },
        () => undefined,
      );
      this.noticesUnsubs.push(unsubNtDel);

      const ntAllPrefix = 'NT_ALL_';
      const ntAllQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt(ntAllPrefix),
        endAt(`${ntAllPrefix}\uf8ff`),
      );
      const unsubNtAll = onValue(
        ntAllQuery,
        (snap) => {
          this.rawNtAllMap = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeServerNotices(uid);
          this.emit();
        },
        () => undefined,
      );
      this.noticesUnsubs.push(unsubNtAll);

      const ntUidPrefix = `NT_U_${uid}_`;
      const ntUidQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt(ntUidPrefix),
        endAt(`${ntUidPrefix}\uf8ff`),
      );
      const unsubNtUid = onValue(
        ntUidQuery,
        (snap) => {
          this.rawNtUidMap = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeServerNotices(uid);
          this.emit();
        },
        () => undefined,
      );
      this.noticesUnsubs.push(unsubNtUid);
    } catch {
      // silent
    }
  }

  // ============================================================
  // HỆ THỐNG ĐẠI LÝ VÉ SỐ KIẾN THIẾT (NHÁNH RIÊNG TỰ ĐỘNG DỌN KỲ CŨ)
  // ============================================================

  getCurrentLotteryDrawId(): number {
    return Math.max(1, Math.floor(this.getServerNow() / LOTTERY_DRAW_INTERVAL_MS) - LOTTERY_EPOCH_SLOT);
  }

  getLotteryRemainingMs(): number {
    const now = this.getServerNow();
    const nextDrawAt = (Math.floor(now / LOTTERY_DRAW_INTERVAL_MS) + 1) * LOTTERY_DRAW_INTERVAL_MS;
    return Math.max(0, nextDrawAt - now);
  }

  getLotteryCountdownText(): string {
    const remSec = Math.max(0, Math.ceil(this.getLotteryRemainingMs() / 1000));
    const m = Math.floor(remSec / 60);
    const s = remSec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  isLotteryUnlocked(): boolean {
    const shop = this.getShopSnapshot();
    return !!(shop.hasShop && shop.level >= 3 && shop.day >= 5);
  }

  getLotteryBoardTickets(drawId?: number): string[] {
    const dId = Math.max(1, Math.floor(drawId || this.getCurrentLotteryDrawId()));
    const pool: string[] = [];
    for (let i = 0; i < 1000; i++) {
      pool.push(String(i).padStart(3, '0'));
    }
    const board: string[] = [];
    for (let step = 0; step < LOTTERY_BOARD_SIZE; step++) {
      const h = _fnv32(`ttc_lotto_board_v2:${dId}:${step}:0x7f4a7c15`);
      const idx = h % pool.length;
      board.push(pool[idx]);
      pool.splice(idx, 1);
    }
    return board;
  }

  computeLotteryDrawResult(drawId: number): LotteryDrawResult {
    const dId = Math.max(1, Math.floor(drawId || 1));
    // Rút toàn bộ số trúng thưởng trực tiếp từ 200 vé phát hành trên sạp của kỳ đó
    // Đảm bảo 100% kỳ nào cũng có Giải Đặc Biệt (tỷ lệ 1/200 = 0,5%/vé, mua 10 vé đạt 5% cơ hội trúng ĐB)
    // và 25/200 vé có thưởng (12,5%/vé, mua 10 vé có ~75,3% cơ hội trúng ít nhất 1 giải)
    const pool = [...this.getLotteryBoardTickets(dId)];
    const hSpec = _fnv32(`ttc_lotto_spec_v3:${dId}:0x9e3779b9`);
    const specIdx = hSpec % pool.length;
    const special = pool[specIdx];
    pool.splice(specIdx, 1);

    const consolationTail = special.slice(-1);

    // 9 giải chính tiếp theo (1 Giải Nhất, 2 Giải Nhì, 6 Giải Ba) rút không trùng lặp từ các vé còn lại trên sạp
    const picked: string[] = [];
    for (let step = 0; step < 9; step++) {
      const hStep = _fnv32(`ttc_lotto_tier_v3:${dId}:${step}:0x85ebca6b`);
      const idx = hStep % pool.length;
      picked.push(pool[idx]);
      pool.splice(idx, 1);
    }

    // 15 Giải Khuyến Khích: ưu tiên các vé trên sạp có cùng chữ số hàng đơn vị với Giải Đặc Biệt,
    // nếu chưa đủ 15 vé thì rút bổ sung ngẫu nhiên từ các vé còn lại trên sạp để luôn đủ 15 giải KK
    const tailMatches = pool.filter((n) => n.endsWith(consolationTail));
    const otherPool = pool.filter((n) => !n.endsWith(consolationTail));
    const consolation: string[] = [];

    while (consolation.length < 15 && tailMatches.length > 0) {
      const hC = _fnv32(`ttc_lotto_cons_tail_v3:${dId}:${consolation.length}:0xc2b2ae35`);
      const idx = hC % tailMatches.length;
      consolation.push(tailMatches[idx]);
      tailMatches.splice(idx, 1);
    }
    while (consolation.length < 15 && otherPool.length > 0) {
      const hC = _fnv32(`ttc_lotto_cons_extra_v3:${dId}:${consolation.length}:0x27d4eb2f`);
      const idx = hC % otherPool.length;
      consolation.push(otherPool[idx]);
      otherPool.splice(idx, 1);
    }
    consolation.sort((a, b) => a.localeCompare(b));

    return {
      drawId: dId,
      special,
      first: picked[0] || '000',
      second: [picked[1] || '111', picked[2] || '222'],
      third: [
        picked[3] || '333',
        picked[4] || '444',
        picked[5] || '555',
        picked[6] || '666',
        picked[7] || '777',
        picked[8] || '888',
      ],
      consolationTail,
      consolation,
    };
  }

  evaluateLotteryTicketPrize(
    drawId: number,
    numRaw: string,
  ): {
    pending: boolean;
    won: boolean;
    tier: 'special' | 'first' | 'second' | 'third' | 'consolation' | 'none';
    title: string;
    titleEn: string;
    prizeName: string;
    prizeNameEn: string;
    reward: number;
  } {
    const curId = this.getCurrentLotteryDrawId();
    const num = String(numRaw || '')
      .trim()
      .padStart(3, '0')
      .slice(-3);
    if (drawId >= curId) {
      return {
        pending: true,
        won: false,
        tier: 'none',
        title: 'Đang chờ mở thưởng',
        titleEn: 'Waiting for draw',
        prizeName: 'Đang chờ mở thưởng',
        prizeNameEn: 'Waiting for draw',
        reward: 0,
      };
    }
    const res = this.computeLotteryDrawResult(drawId);
    if (num === res.special) {
      const specialReward = this.getLotteryJackpotForDraw(drawId);
      return {
        pending: false,
        won: true,
        tier: 'special',
        title: 'Giải Đặc Biệt',
        titleEn: 'Special Jackpot',
        prizeName: 'Giải Đặc Biệt',
        prizeNameEn: 'Special Jackpot',
        reward: specialReward,
      };
    }
    if (num === res.first) {
      return {
        pending: false,
        won: true,
        tier: 'first',
        title: 'Giải Nhất',
        titleEn: 'First Prize',
        prizeName: 'Giải Nhất',
        prizeNameEn: 'First Prize',
        reward: 1000000,
      };
    }
    if (res.second.includes(num)) {
      return {
        pending: false,
        won: true,
        tier: 'second',
        title: 'Giải Nhì',
        titleEn: 'Second Prize',
        prizeName: 'Giải Nhì',
        prizeNameEn: 'Second Prize',
        reward: 400000,
      };
    }
    if (res.third.includes(num)) {
      return {
        pending: false,
        won: true,
        tier: 'third',
        title: 'Giải Ba',
        titleEn: 'Third Prize',
        prizeName: 'Giải Ba',
        prizeNameEn: 'Third Prize',
        reward: 150000,
      };
    }
    if (res.consolation.includes(num)) {
      return {
        pending: false,
        won: true,
        tier: 'consolation',
        title: 'Giải Khuyến Khích',
        titleEn: 'Consolation Prize',
        prizeName: 'Giải Khuyến Khích',
        prizeNameEn: 'Consolation Prize',
        reward: 60000,
      };
    }
    return {
      pending: false,
      won: false,
      tier: 'none',
      title: 'Chúc may mắn kỳ sau',
      titleEn: 'Better luck next time',
      prizeName: 'Chúc may mắn kỳ sau',
      prizeNameEn: 'Better luck next time',
      reward: 0,
    };
  }

  hasClaimableLotteryPrize(): boolean {
    if (!this.user) return false;
    const curId = this.getCurrentLotteryDrawId();
    for (const tk of this.myLotteryTickets) {
      if (tk.drawId < curId && !tk.claimed && !this.lotteryClaimedKeys.has(tk.id)) {
        const pr = this.evaluateLotteryTicketPrize(tk.drawId, tk.num);
        if (pr.won && pr.reward > 0) return true;
      }
    }
    return false;
  }

  getUnclaimedLotteryTotalReward(): number {
    if (!this.user) return 0;
    const curId = this.getCurrentLotteryDrawId();
    let sum = 0;
    for (const tk of this.myLotteryTickets) {
      if (tk.drawId < curId && !tk.claimed && !this.lotteryClaimedKeys.has(tk.id)) {
        const pr = this.evaluateLotteryTicketPrize(tk.drawId, tk.num);
        if (pr.won && pr.reward > 0) sum += pr.reward;
      }
    }
    return sum;
  }

  getMyTicketsInCurrentDraw(): LotteryTicketRecord[] {
    const curId = this.getCurrentLotteryDrawId();
    return this.myLotteryTickets.filter((t) => t.drawId === curId);
  }

  getPrevDrawWinners(): LotteryWinnerItem[] {
    const prevId = this.getCurrentLotteryDrawId() - 1;
    if (prevId < 1) return [];
    return this.computeWinnersForDraw(prevId, this.prevDrawSoldMap);
  }

  computeWinnersForDraw(
    drawId: number,
    soldMap: Record<string, LotterySoldTicketInfo>,
  ): LotteryWinnerItem[] {
    if (drawId < 1) return [];

    // Luôn hợp nhất vé của tiệm người chơi mua ở kỳ này để không bao giờ bị sót trên Bảng Vàng
    const mergedMap: Record<string, LotterySoldTicketInfo> = { ...(soldMap || {}) };
    const myUid = this.user?.uid || '';
    const myShop = this.getShopSnapshot().shopName || 'Tiệm của bạn';
    for (const tk of this.myLotteryTickets) {
      if (tk.drawId === drawId && tk.num) {
        if (!mergedMap[tk.num]) {
          mergedMap[tk.num] = {
            num: tk.num,
            uid: myUid,
            shopName: myShop,
          };
        } else if (myShop && (!mergedMap[tk.num].shopName || mergedMap[tk.num].shopName === 'Tiệm Trái Cây')) {
          if (mergedMap[tk.num].uid === myUid) {
            mergedMap[tk.num].shopName = myShop;
          }
        }
      }
    }

    const list: LotteryWinnerItem[] = [];
    const targetJackpot = this.getLotteryJackpotForDraw(drawId);
    for (const info of Object.values(mergedMap)) {
      if (!info || !info.num) continue;
      const pr = this.evaluateLotteryTicketPrize(drawId, info.num);
      if (pr.won && pr.reward > 0) {
        const reward = pr.tier === 'special' ? targetJackpot : pr.reward;
        list.push({
          drawId,
          num: info.num,
          uid: info.uid,
          shopName: info.shopName || 'Tiệm Trái Cây',
          tier: pr.tier,
          title: pr.tier === 'special' ? 'Giải Đặc Biệt (Jackpot)' : pr.title,
          titleEn: pr.tier === 'special' ? 'Special Jackpot' : pr.titleEn,
          prizeName: pr.tier === 'special' ? 'Giải Đặc Biệt (Jackpot)' : pr.title,
          prizeNameEn: pr.tier === 'special' ? 'Special Jackpot' : pr.titleEn,
          reward,
        });
      }
    }
    // Ghép thêm thông tin nếu kỳ này từng có tiệm nổ Giải Đặc Biệt được lưu vĩnh viễn
    const specWin = this.lotterySpecialWins[drawId];
    if (specWin && !list.some((w) => w.tier === 'special')) {
      list.push({
        drawId,
        num: specWin.num,
        uid: specWin.uid,
        shopName: specWin.shopName || 'Tiệm Trái Cây',
        tier: 'special',
        title: 'Giải Đặc Biệt (Jackpot)',
        titleEn: 'Special Jackpot',
        prizeName: 'Giải Đặc Biệt (Jackpot)',
        prizeNameEn: 'Special Jackpot',
        reward: specWin.jackpot || targetJackpot,
      });
    }
    list.sort((a, b) => b.reward - a.reward || a.num.localeCompare(b.num));

    // Chỉ lưu cache khi có người trúng hoặc khi dữ liệu vé đã thực sự nạp xong
    if (list.length > 0 || Object.keys(mergedMap).length > 0) {
      this.lotteryDrawWinnersCache[drawId] = list;
    }
    return list;
  }

  getDrawWinnersForDraw(drawId: number): LotteryWinnerItem[] {
    const curId = this.getCurrentLotteryDrawId();
    const targetId = typeof drawId === 'number' && drawId > 0 ? Math.floor(drawId) : curId - 1;
    if (targetId < 1 || targetId >= curId) return [];

    // 1. Kiểm tra cache đã tính sẵn VÀ CÓ DỮ LIỆU NGƯỜI TRÚNG
    if (this.lotteryDrawWinnersCache[targetId] && this.lotteryDrawWinnersCache[targetId].length > 0) {
      return this.lotteryDrawWinnersCache[targetId];
    }

    // 2. Nếu là kỳ liền kề trước đó
    if (targetId === curId - 1) {
      const prevList = this.getPrevDrawWinners();
      if (prevList.length > 0) {
        this.lotteryDrawWinnersCache[targetId] = prevList;
        return prevList;
      }
      // Nếu đã nạp xong từ Firebase RTDB, lưu cache
      if (this.prevSoldLoadedForDraw === curId) {
        this.lotteryDrawWinnersCache[targetId] = prevList;
        return prevList;
      }
    }

    // 3. Nếu đã tải sẵn map vé bán của kỳ này trong bộ nhớ
    if (this.drawSoldMapsCache[targetId] && Object.keys(this.drawSoldMapsCache[targetId]).length > 0) {
      const computed = this.computeWinnersForDraw(targetId, this.drawSoldMapsCache[targetId]);
      this.lotteryDrawWinnersCache[targetId] = computed;
      return computed;
    }

    // 4. Kích hoạt tải ngầm từ RTDB (giữ 72 kỳ liên tục trong 24h)
    if (!this.loadingDrawIds.has(targetId)) {
      this.fetchDrawSoldTickets(targetId);
    }

    // 5. Kiểm tra vé của chính người chơi ở kỳ này xem có trúng không (hiển thị ngay tức thì không cần chờ cloud)
    const myTicketsInDraw = this.myLotteryTickets.filter((t) => t.drawId === targetId);
    if (myTicketsInDraw.length > 0) {
      const myWinners = this.computeWinnersForDraw(targetId, {});
      if (myWinners.length > 0) {
        return myWinners;
      }
    }

    // 6. Nếu kỳ này có tiệm nổ Jackpot được lưu trong lotterySpecialWins, hiển thị ngay tiệm nổ ĐB
    const specWin = this.lotterySpecialWins[targetId];
    if (specWin) {
      return [
        {
          drawId: targetId,
          num: specWin.num,
          uid: specWin.uid,
          shopName: specWin.shopName || 'Tiệm Trái Cây',
          tier: 'special',
          title: 'Giải Đặc Biệt (Jackpot)',
          titleEn: 'Special Jackpot',
          prizeName: 'Giải Đặc Biệt (Jackpot)',
          prizeNameEn: 'Special Jackpot',
          reward: specWin.jackpot || this.getLotteryJackpotForDraw(targetId),
        },
      ];
    }

    if (this.lotteryDrawWinnersCache[targetId]) {
      return this.lotteryDrawWinnersCache[targetId];
    }

    return [];
  }

  getDrawSoldCount(drawId: number): number {
    const curId = this.getCurrentLotteryDrawId();
    const targetId = typeof drawId === 'number' && drawId > 0 ? Math.floor(drawId) : curId;
    let count = -1;
    if (targetId === curId) {
      count = Object.keys(this.currentDrawSoldMap || {}).length;
    } else if (targetId === curId - 1) {
      if (Object.keys(this.prevDrawSoldMap || {}).length > 0) {
        count = Object.keys(this.prevDrawSoldMap).length;
      } else if (this.prevSoldLoadedForDraw === curId) {
        count = 0;
      }
    } else if (this.drawSoldMapsCache[targetId]) {
      count = Object.keys(this.drawSoldMapsCache[targetId]).length;
    } else if (typeof this.lotteryDrawSoldCountMap[targetId] === 'number') {
      count = this.lotteryDrawSoldCountMap[targetId];
    }

    // Tính thêm số vé của người chơi nếu mạng chưa nạp kịp
    const myTickets = this.myLotteryTickets.filter((t) => t.drawId === targetId);
    if (myTickets.length > 0) {
      if (count <= 0) {
        count = myTickets.length;
      } else {
        const activeMap =
          targetId === curId
            ? this.currentDrawSoldMap
            : targetId === curId - 1
              ? this.prevDrawSoldMap
              : this.drawSoldMapsCache[targetId];
        if (activeMap) {
          let extra = 0;
          for (const tk of myTickets) {
            if (!activeMap[tk.num]) extra++;
          }
          count += extra;
        }
      }
    }
    return count;
  }

  async fetchDrawSoldTickets(drawId: number): Promise<Record<string, LotterySoldTicketInfo>> {
    if (drawId <= 0) return {};
    if (this.drawSoldMapsCache[drawId] && Object.keys(this.drawSoldMapsCache[drawId]).length > 0) {
      return this.drawSoldMapsCache[drawId];
    }
    const curId = this.getCurrentLotteryDrawId();
    if (drawId === curId - 1 && Object.keys(this.prevDrawSoldMap).length > 0) {
      this.drawSoldMapsCache[drawId] = { ...this.prevDrawSoldMap };
      this.computeWinnersForDraw(drawId, this.prevDrawSoldMap);
      return this.drawSoldMapsCache[drawId];
    }
    if (this.loadingDrawIds.has(drawId)) return this.drawSoldMapsCache[drawId] || {};
    this.loadingDrawIds.add(drawId);
    try {
      const snap = await get(ref(rtdb, `lottery/draws/${drawId}`));
      const map: Record<string, LotterySoldTicketInfo> = {};
      if (snap.exists() && typeof snap.val() === 'object') {
        for (const [k, v] of Object.entries(snap.val() || {})) {
          const parsed = this.parseSoldTicketValue(k, v);
          if (parsed) map[parsed.num] = parsed;
        }
      }
      // Kiểm tra nhánh dự phòng refCodes nếu nhánh lottery/draws rỗng
      if (Object.keys(map).length === 0) {
        try {
          const fbQuery = query(
            ref(rtdb, 'refCodes'),
            orderByKey(),
            startAt(`LOT_${drawId}_`),
            endAt(`LOT_${drawId}_\uf8ff`),
          );
          const fbSnap = await get(fbQuery);
          if (fbSnap.exists() && typeof fbSnap.val() === 'object') {
            for (const [k, v] of Object.entries(fbSnap.val() || {})) {
              if (!k.startsWith(`LOT_${drawId}_`)) continue;
              const tail = k.slice(`LOT_${drawId}_`.length);
              const dashIdx = tail.indexOf('-');
              const rawNum = dashIdx >= 0 ? tail.slice(0, dashIdx) : tail;
              const hexShop = dashIdx >= 0 ? tail.slice(dashIdx + 1) : '';
              const uid = String(v || '').trim();
              if (/^\d{1,3}$/.test(rawNum) && uid) {
                const num = rawNum.padStart(3, '0').slice(-3);
                map[num] = {
                  num,
                  uid,
                  shopName: hexShop ? _decHex(hexShop) : map[num]?.shopName || 'Tiệm Trái Cây',
                };
              }
            }
          }
        } catch {}
      }

      // Hợp nhất vé của người chơi vào kết quả kỳ
      const myUid = this.user?.uid || '';
      const myShop = this.getShopSnapshot().shopName || 'Tiệm của bạn';
      for (const tk of this.myLotteryTickets) {
        if (tk.drawId === drawId && !map[tk.num]) {
          map[tk.num] = {
            num: tk.num,
            uid: myUid,
            shopName: myShop,
          };
        }
      }

      this.drawSoldMapsCache[drawId] = map;
      this.lotteryDrawSoldCountMap[drawId] = Object.keys(map).length;
      const winners = this.computeWinnersForDraw(drawId, map);
      this.lotteryDrawWinnersCache[drawId] = winners;
      this.emit();
      return map;
    } catch {
      return {};
    } finally {
      this.loadingDrawIds.delete(drawId);
    }
  }

  clampLotteryJackpot(rawVal: unknown): number {
    const num = Math.floor(Number(rawVal) || 0);
    if (num <= LOTTERY_JACKPOT_BASE) return LOTTERY_JACKPOT_BASE;
    if (num >= LOTTERY_JACKPOT_MAX) return LOTTERY_JACKPOT_MAX;
    const steps = Math.round((num - LOTTERY_JACKPOT_BASE) / LOTTERY_JACKPOT_STEP);
    return Math.min(
      LOTTERY_JACKPOT_MAX,
      Math.max(LOTTERY_JACKPOT_BASE, LOTTERY_JACKPOT_BASE + steps * LOTTERY_JACKPOT_STEP),
    );
  }

  getLotteryJackpotForDraw(drawId?: number): number {
    const curId = this.getCurrentLotteryDrawId();
    const targetId = typeof drawId === 'number' && drawId > 0 ? Math.floor(drawId) : curId;
    if (targetId > curId) return LOTTERY_JACKPOT_BASE;

    // 1. Ưu tiên cao nhất: Nếu kỳ này có người nổ Giải Đặc Biệt được lưu trên Server
    const specWin = this.lotterySpecialWins[targetId];
    if (specWin && typeof specWin.jackpot === 'number' && specWin.jackpot >= LOTTERY_JACKPOT_BASE) {
      const clamped = this.clampLotteryJackpot(specWin.jackpot);
      this.lotteryJackpotHistory[targetId] = clamped;
      return clamped;
    }

    // 2. Kỳ hiện tại hoặc kỳ liền kề trước đó: lấy theo trạng thái Jackpot đã đồng bộ từ Server
    if (targetId === curId && this.lotteryJackpot >= LOTTERY_JACKPOT_BASE) {
      return this.clampLotteryJackpot(this.lotteryJackpot);
    }
    if (targetId === curId - 1 && this.lotteryPrevJackpot >= LOTTERY_JACKPOT_BASE) {
      return this.clampLotteryJackpot(this.lotteryPrevJackpot);
    }

    // 3. Kiểm tra lịch sử các kỳ từ Server (LOT_JP / lottery/jackpot / draw_history)
    const fromHist = this.lotteryJackpotHistory[targetId];
    if (typeof fromHist === 'number' && fromHist >= LOTTERY_JACKPOT_BASE) {
      return this.clampLotteryJackpot(fromHist);
    }

    // 4. Dự phòng cuối cùng khi ngoại tuyến: kiểm tra trong danh sách vé cá nhân nhưng KHÔNG ghi đè vào lotteryJackpotHistory chung
    for (const tk of this.myLotteryTickets) {
      if (tk.drawId === targetId && typeof tk.jackpot === 'number' && tk.jackpot >= LOTTERY_JACKPOT_BASE) {
        return this.clampLotteryJackpot(tk.jackpot);
      }
    }

    return LOTTERY_JACKPOT_BASE;
  }

  private loadLocalLotteryJackpotCache() {
    try {
      const raw = localStorage.getItem('ttc_lot_jp_v1');
      if (!raw) return;
      const parsed = this.parseJackpotPayload(raw);
      if (!parsed) return;
      const curId = this.getCurrentLotteryDrawId();
      if (parsed.d > curId) {
        try {
          localStorage.removeItem('ttc_lot_jp_v1');
        } catch {}
        return;
      }
      for (const [k, v] of Object.entries(parsed.hist)) {
        const dId = Number(k);
        if (dId > 0 && dId <= curId && v >= LOTTERY_JACKPOT_BASE) {
          this.lotteryJackpotHistory[dId] = this.clampLotteryJackpot(v);
        }
      }
      if (parsed.d === curId) {
        this.lotteryJackpot = this.clampLotteryJackpot(parsed.j);
        this.lotteryPrevJackpot = this.clampLotteryJackpot(parsed.p);
        this.lotteryJackpotStreak = Math.max(
          0,
          Math.min(10, Math.round((this.lotteryJackpot - LOTTERY_JACKPOT_BASE) / LOTTERY_JACKPOT_STEP)),
        );
        this.lotteryPrevSpecialWon = parsed.w;
      }
    } catch {}
  }

  private saveLocalLotteryJackpotCache(payloadStr: string) {
    try {
      localStorage.setItem('ttc_lot_jp_v1', payloadStr);
    } catch {}
  }

  private parseJackpotPayload(raw: unknown): {
    d: number;
    j: number;
    s: number;
    p: number;
    w: boolean;
    hist: Record<number, number>;
  } | null {
    if (!raw) return null;
    const hist: Record<number, number> = {};
    const parseHistStr = (hStr: string) => {
      for (const part of String(hStr || '').split(',')) {
        const [dRaw, jRaw] = part.split(':');
        const dId = Math.floor(Number(dRaw) || 0);
        const jp = Math.floor(Number(jRaw) || 0);
        if (dId > 0 && jp >= LOTTERY_JACKPOT_BASE) {
          hist[dId] = this.clampLotteryJackpot(jp);
        }
      }
    };
    if (typeof raw === 'string') {
      const parts = raw.trim().split('|');
      const d = Math.floor(Number(parts[0]) || 0);
      if (d <= 0) return null;
      const j = this.clampLotteryJackpot(parts[1]);
      const s = Math.max(0, Math.min(10, Math.floor(Number(parts[2]) || 0)));
      const p = this.clampLotteryJackpot(parts[3] || LOTTERY_JACKPOT_BASE);
      const w = parts[4] === '1' || parts[4] === 'true';
      if (parts[5]) parseHistStr(parts[5]);
      hist[d] = j;
      if (d > 1) hist[d - 1] = p;
      return { d, j, s, p, w, hist };
    }
    if (typeof raw === 'object') {
      const obj = raw as any;
      const d = Math.floor(Number(obj.d) || 0);
      if (d <= 0) return null;
      const j = this.clampLotteryJackpot(obj.j);
      const s = Math.max(0, Math.min(10, Math.floor(Number(obj.s) || 0)));
      const p = this.clampLotteryJackpot(obj.p || LOTTERY_JACKPOT_BASE);
      const w = !!obj.w;
      if (typeof obj.h === 'string') parseHistStr(obj.h);
      hist[d] = j;
      if (d > 1) hist[d - 1] = p;
      return { d, j, s, p, w, hist };
    }
    return null;
  }

  private loadLocalLotterySpecWins() {
    try {
      const raw = localStorage.getItem('ttc_lot_spec_wins_v1');
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        for (const [k, v] of Object.entries(parsed)) {
          const dId = Number(k);
          if (dId > 0 && v && typeof v === 'object') {
            const item = v as any;
            this.lotterySpecialWins[dId] = {
              drawId: dId,
              num: String(item.num || ''),
              uid: String(item.uid || ''),
              shopName: String(item.shopName || 'Tiệm Trái Cây'),
              jackpot: this.clampLotteryJackpot(item.jackpot),
              wonAt: Number(item.wonAt) || 0,
            };
            this.lotteryJackpotHistory[dId] = this.clampLotteryJackpot(item.jackpot);
          }
        }
      }
    } catch {}
  }

  private saveLocalLotterySpecWins() {
    try {
      localStorage.setItem('ttc_lot_spec_wins_v1', JSON.stringify(this.lotterySpecialWins));
    } catch {}
  }

  private loadLocalLotteryMeta(uid: string) {
    this.loadLocalLotteryJackpotCache();
    this.loadLocalLotterySpecWins();
    if (!uid) return;
    const curId = this.getCurrentLotteryDrawId();
    try {
      const rawTickets = JSON.parse(localStorage.getItem(`ttc_lot_tk_${uid}`) || '[]');
      const rawClaimed = JSON.parse(localStorage.getItem(`ttc_lot_cl_${uid}`) || '[]');
      if (Array.isArray(rawClaimed)) {
        for (const k of rawClaimed) {
          if (typeof k === 'string' && k) this.lotteryClaimedKeys.add(k);
        }
      }
      if (Array.isArray(rawTickets)) {
        const sanitized = rawTickets.filter((item: any) => {
          const d = Math.floor(Number(item?.drawId) || 0);
          return d > 0 && d <= curId;
        });
        if (sanitized.length !== rawTickets.length) {
          localStorage.setItem(`ttc_lot_tk_${uid}`, JSON.stringify(sanitized));
        }
        this.mergeCloudLotteryTickets(uid, sanitized);
      }
    } catch {}
  }

  private saveLocalLotteryMeta(uid: string, syncCloud = false) {
    if (!uid) return;
    const curId = this.getCurrentLotteryDrawId();
    // Giữ vé trong 72 kỳ gần nhất (24 giờ liên tục) và toàn bộ vé trúng thưởng chưa lĩnh thưởng
    const pruned = this.myLotteryTickets
      .filter((t) => {
        if (t.drawId > curId) return false;
        if (t.drawId >= curId - 72) return true;
        const isCl = t.claimed || this.lotteryClaimedKeys.has(t.id);
        if (!isCl && this.evaluateLotteryTicketPrize(t.drawId, t.num).won) return true;
        return false;
      })
      .sort((a, b) => b.drawId - a.drawId || b.boughtAt - a.boughtAt)
      .slice(0, 100);

    this.myLotteryTickets = pruned;
    const claimedArr = Array.from(this.lotteryClaimedKeys).slice(-100);
    try {
      localStorage.setItem(`ttc_lot_tk_${uid}`, JSON.stringify(pruned));
      localStorage.setItem(`ttc_lot_cl_${uid}`, JSON.stringify(claimedArr));
    } catch {}
    if (syncCloud) {
      update(ref(rtdb, `referrals/${uid}`), {
        lotteryTickets: pruned,
        lotteryClaimed: claimedArr,
      }).catch(() => undefined);
    }
  }

  private mergeCloudLotteryTickets(uid: string, rawList: unknown[]) {
    if (!Array.isArray(rawList)) return;
    const curId = this.getCurrentLotteryDrawId();
    const byId = new Map<string, LotteryTicketRecord>();
    for (const existing of this.myLotteryTickets) {
      if (existing && existing.id && existing.drawId > 0 && existing.drawId <= curId) {
        byId.set(existing.id, {
          ...existing,
          claimed: existing.claimed || this.lotteryClaimedKeys.has(existing.id),
        });
      }
    }
    for (const item of rawList) {
      if (!item || typeof item !== 'object') continue;
      const rec = item as any;
      const drawId = Math.floor(Number(rec.drawId) || 0);
      const rawNum = String(rec.num || '').trim();
      if (!/^\d{1,3}$/.test(rawNum)) continue;
      const num = rawNum.padStart(3, '0').slice(-3);
      if (drawId <= 0 || drawId > curId || !/^\d{3}$/.test(num)) continue;
      const id = `${drawId}_${num}`;
      const isClaimed = !!(rec.claimed || this.lotteryClaimedKeys.has(id));
      if (isClaimed) this.lotteryClaimedKeys.add(id);
      const prev = byId.get(id);
      const recJp =
        typeof rec.jackpot === 'number' && rec.jackpot >= LOTTERY_JACKPOT_BASE
          ? this.clampLotteryJackpot(rec.jackpot)
          : prev?.jackpot;
      // Chỉ bổ sung vào lotteryJackpotHistory nếu Server chưa có dữ liệu kỳ này để không bao giờ ghi đè giá trị chuẩn của Server
      if (recJp && !this.lotteryJackpotHistory[drawId]) {
        this.lotteryJackpotHistory[drawId] = recJp;
      }
      byId.set(id, {
        id,
        drawId,
        num,
        boughtAt: Number(rec.boughtAt) || prev?.boughtAt || Date.now(),
        claimed: isClaimed || !!prev?.claimed,
        ...(recJp ? { jackpot: recJp } : {}),
      });
    }
    this.myLotteryTickets = Array.from(byId.values()).sort(
      (a, b) => b.drawId - a.drawId || b.boughtAt - a.boughtAt,
    );
    this.saveLocalLotteryMeta(uid, false);
  }

  private parseSoldTicketValue(num: string, rawVal: unknown): LotterySoldTicketInfo | null {
    const rawKey = String(num || '').trim();
    if (!/^\d{1,3}$/.test(rawKey) || !rawVal) return null;
    const cleanNum = rawKey.padStart(3, '0').slice(-3);
    if (typeof rawVal === 'string') {
      const parts = rawVal.split('|');
      const uid = (parts[0] || '').trim();
      const shopName = parts[1] ? _decHex(parts[1]) : 'Tiệm Trái Cây';
      if (!uid) return null;
      return { num: cleanNum, uid, shopName: shopName || 'Tiệm Trái Cây' };
    }
    if (typeof rawVal === 'object') {
      const obj = rawVal as any;
      const uid = String(obj.u || obj.uid || '').trim();
      const shopName = String(obj.s || obj.shopName || 'Tiệm Trái Cây').trim();
      if (!uid) return null;
      return { num: cleanNum, uid, shopName: shopName || 'Tiệm Trái Cây' };
    }
    return null;
  }

  stopLotteryDrawSync() {
    for (const unsub of this.lotteryUnsubs) {
      try {
        unsub();
      } catch {}
    }
    this.lotteryUnsubs = [];
    this.lotteryListeningDrawId = 0;
  }

  private async syncFinishedLotteryDrawOnce(finishedDrawId: number): Promise<void> {
    if (!rtdb || finishedDrawId < 1) return;
    try {
      const [jpSnap, specSnap] = await Promise.all([
        get(ref(rtdb, 'lottery/jackpot')).catch(() => null),
        get(ref(rtdb, `lottery/special_wins/${finishedDrawId}`)).catch(() => null),
      ]);
      if (jpSnap && jpSnap.exists()) {
        const parsed = this.parseJackpotPayload(jpSnap.val());
        if (parsed) {
          for (const [k, v] of Object.entries(parsed.hist)) {
            const dId = Number(k);
            if (dId > 0 && v >= LOTTERY_JACKPOT_BASE) {
              this.lotteryJackpotHistory[dId] = this.clampLotteryJackpot(v);
            }
          }
        }
      }
      if (specSnap && specSnap.exists() && typeof specSnap.val() === 'object') {
        const item = specSnap.val() as any;
        const jp = this.clampLotteryJackpot(item.jackpot);
        this.lotterySpecialWins[finishedDrawId] = {
          drawId: finishedDrawId,
          num: String(item.num || ''),
          uid: String(item.uid || ''),
          shopName: String(item.shopName || 'Tiệm Trái Cây'),
          jackpot: jp,
          wonAt: Number(item.wonAt) || 0,
        };
        this.lotteryJackpotHistory[finishedDrawId] = jp;
      } else if (this.user) {
        // Nếu người chơi đã mua vé từ trước khi bảo trì và trúng Giải Đặc Biệt ở kỳ vừa mở, tự động ghi nhận lên Server để không bao giờ bị mất hay lệch giải
        const myFinished = this.myLotteryTickets.filter((t) => t.drawId === finishedDrawId);
        const specNum = this.computeLotteryDrawResult(finishedDrawId).special;
        const winTk = myFinished.find((t) => t.num === specNum);
        if (winTk && !this.lotterySpecialWins[finishedDrawId]) {
          const jp = this.clampLotteryJackpot(
            winTk.jackpot || this.lotteryJackpotHistory[finishedDrawId] || this.lotteryJackpot,
          );
          const shopName = this.getShopSnapshot().shopName || 'Tiệm Trái Cây';
          const specRecord = {
            drawId: finishedDrawId,
            num: specNum,
            uid: this.user.uid,
            shopName,
            jackpot: jp,
            wonAt: Date.now(),
          };
          this.lotterySpecialWins[finishedDrawId] = specRecord;
          this.lotteryJackpotHistory[finishedDrawId] = jp;
          this.saveLocalLotterySpecWins();
          runTransaction(ref(rtdb, `lottery/special_wins/${finishedDrawId}`), (cur) => {
            if (cur && typeof cur === 'object' && Number((cur as any).jackpot) >= LOTTERY_JACKPOT_BASE) {
              return cur;
            }
            return specRecord;
          }).catch(() => {
            set(ref(rtdb, `lottery/special_wins/${finishedDrawId}`), specRecord).catch(() => undefined);
          });
          runTransaction(ref(rtdb, `refCodes/LOT_SPEC_${finishedDrawId}`), (cur) => {
            if (cur && typeof cur === 'string' && cur.includes('|')) {
              return cur;
            }
            return `${specNum}|${this.user!.uid}|${jp}|${_encHex(shopName)}`;
          }).catch(() => undefined);
        }
      }
    } catch {}
  }

  private startLotteryLocalWinWatcher() {
    if (this.lotteryTickTimer) return;
    let lastCheckedDrawId = this.getCurrentLotteryDrawId();
    this.lotteryTickTimer = setInterval(() => {
      if (!this.user) return;
      const nowDrawId = this.getCurrentLotteryDrawId();
      if (nowDrawId !== lastCheckedDrawId) {
        const justFinishedId = nowDrawId - 1;
        lastCheckedDrawId = nowDrawId;
        const myFinished = this.myLotteryTickets.filter((t) => t.drawId === justFinishedId);
        // Nếu người chơi đang mở cửa sổ Đại Lý Vé Số thì tự chuyển sang lắng nghe kỳ mới
        if (this.lotteryUnsubs.length > 0) {
          this.startLotteryDrawSync(true);
          this.checkAndNotifyNewLotteryDraw(justFinishedId);
          this.emit();
        } else if (myFinished.length > 0) {
          this.syncFinishedLotteryDrawOnce(justFinishedId).finally(() => {
            this.checkAndNotifyNewLotteryDraw(justFinishedId);
            this.emit();
          });
        } else {
          this.emit();
        }
      }
    }, 5000);
  }

  startLotteryDrawSync(force = false) {
    if (!rtdb) return;
    this.loadLocalLotteryJackpotCache();
    this.startLotteryLocalWinWatcher();
    const curDrawId = this.getCurrentLotteryDrawId();
    if (!force && this.lotteryListeningDrawId === curDrawId && this.lotteryUnsubs.length > 0) {
      return;
    }

    const prevDrawId = curDrawId - 1;
    // Bảo lưu danh sách vé bán của kỳ trước liền kề từ bộ nhớ để khi vừa sang kỳ mới không bị trống vé
    const prevSnapshot: Record<string, LotterySoldTicketInfo> =
      this.lotteryListeningDrawId === curDrawId - 1 && Object.keys(this.currentDrawSoldMap).length > 0
        ? { ...this.currentDrawSoldMap }
        : { ...(this.drawSoldMapsCache[prevDrawId] || {}) };

    for (const unsub of this.lotteryUnsubs) {
      try {
        unsub();
      } catch {}
    }
    this.lotteryUnsubs = [];
    this.lotteryListeningDrawId = curDrawId;
    this.currentDrawSoldMap = {};
    this.prevDrawSoldMap = { ...prevSnapshot };
    this.jackpotLoadedForDraw = 0;
    // Luôn đợi phản hồi thực tế từ Firebase RTDB của kỳ trước (prevDrawId) trước khi tự chốt Jackpot mới
    this.prevSoldLoadedForDraw = curDrawId <= 1 ? curDrawId : 0;
    if (Object.keys(prevSnapshot).length > 0) {
      this.drawSoldMapsCache[prevDrawId] = { ...prevSnapshot };
      this.lotteryDrawSoldCountMap[prevDrawId] = Object.keys(prevSnapshot).length;
      const initialPrevWinners = this.computeWinnersForDraw(prevDrawId, prevSnapshot);
      if (initialPrevWinners.length > 0) {
        this.lotteryDrawWinnersCache[prevDrawId] = initialPrevWinners;
      }
    }

    let dedicatedCurrentMap: Record<string, LotterySoldTicketInfo> = {};
    let fallbackCurrentMap: Record<string, LotterySoldTicketInfo> = {};
    let dedicatedPrevMap: Record<string, LotterySoldTicketInfo> = {};
    let fallbackPrevMap: Record<string, LotterySoldTicketInfo> = {};
    let fbCurStarted = false;
    let fbPrevStarted = false;
    let fbJpStarted = false;

    const cleanOldLotteryDraws = () => {
      if (this.user && this.lotteryCleanedUpToDrawId < curDrawId) {
        this.lotteryCleanedUpToDrawId = curDrawId;
        // Giữ lại 72 kỳ (24 giờ liên tục) trên RTDB để người chơi đi ngủ hay offline bật lên vẫn tải và xem đủ kết quả
        for (let oldId = curDrawId - 75; oldId >= curDrawId - 80; oldId--) {
          if (oldId > 0) {
            set(ref(rtdb, `lottery/draws/${oldId}`), null).catch(() => undefined);
          }
        }
      }
    };

    const refreshCachedWinnersReward = () => {
      if (prevDrawId >= 1 && Object.keys(this.prevDrawSoldMap).length > 0) {
        this.lotteryDrawWinnersCache[prevDrawId] = this.computeWinnersForDraw(
          prevDrawId,
          this.prevDrawSoldMap,
        );
      }
      for (const [dKey, cachedList] of Object.entries(this.lotteryDrawWinnersCache)) {
        const dId = Number(dKey);
        if (dId > 0 && Array.isArray(cachedList) && cachedList.length > 0) {
          const authJp = this.getLotteryJackpotForDraw(dId);
          for (const item of cachedList) {
            if (item && item.tier === 'special') {
              item.reward = authJp;
            }
          }
        }
      }
    };

    const tryResolveJackpot = () => {
      if (this.lotteryListeningDrawId !== curDrawId) return;
      if (this.jackpotLoadedForDraw !== curDrawId || this.prevSoldLoadedForDraw !== curDrawId) {
        return;
      }

      const prevSpecialNum = prevDrawId >= 1 ? this.computeLotteryDrawResult(prevDrawId).special : '';
      const prevSpecialTicket =
        prevDrawId >= 1 && prevSpecialNum ? this.prevDrawSoldMap[prevSpecialNum] : null;
      const prevSpecialWon = !!prevSpecialTicket || !!this.lotterySpecialWins[prevDrawId];
      const prevSoldTicketsCount = Object.keys(this.prevDrawSoldMap || {}).length;

      let parsed = this.parseJackpotPayload(this.rawJackpotData);
      if (parsed && parsed.d > curDrawId) {
        parsed = null;
        try {
          localStorage.removeItem('ttc_lot_jp_v1');
        } catch {}
      }

      // Cập nhật toàn bộ lịch sử chuẩn từ Server vào bộ nhớ máy (ghi đè mọi sai lệch cục bộ)
      if (parsed) {
        for (const [k, v] of Object.entries(parsed.hist)) {
          const dId = Number(k);
          if (dId > 0 && dId <= curDrawId && v >= LOTTERY_JACKPOT_BASE) {
            this.lotteryJackpotHistory[dId] = this.clampLotteryJackpot(v);
          }
        }
      }

      let curJp = LOTTERY_JACKPOT_BASE;
      let prevJp = LOTTERY_JACKPOT_BASE;
      let streak = 0;
      let wonFlag = prevSpecialWon;
      let needWrite = false;

      // 1. Nếu kỳ hiện tại đã được đồng bộ chuẩn trên Server (Single Source of Truth)
      if (parsed && parsed.d === curDrawId) {
        curJp = this.clampLotteryJackpot(parsed.j);
        prevJp = this.clampLotteryJackpot(parsed.p);
        wonFlag = parsed.w || prevSpecialWon;

        // Nếu phát hiện kỳ vừa rồi thực tế có người trúng ĐB mà node chưa kịp reset
        if (prevSpecialWon && curJp > LOTTERY_JACKPOT_BASE) {
          curJp = LOTTERY_JACKPOT_BASE;
          streak = 0;
          needWrite = true;
        } else {
          streak = Math.max(
            0,
            Math.min(10, Math.round((curJp - LOTTERY_JACKPOT_BASE) / LOTTERY_JACKPOT_STEP)),
          );
        }
      } else {
        // 2. Cần tính toán Jackpot: tìm mốc chốt gần nhất từ Server
        let anchorDraw = 0;
        let anchorJp = LOTTERY_JACKPOT_BASE;

        if (parsed && parsed.d < curDrawId) {
          anchorDraw = parsed.d;
          anchorJp = this.clampLotteryJackpot(parsed.j);
        } else {
          for (const [k, v] of Object.entries(this.lotteryJackpotHistory)) {
            const dId = Number(k);
            if (dId > 0 && dId < curDrawId && dId > anchorDraw && v >= LOTTERY_JACKPOT_BASE) {
              anchorDraw = dId;
              anchorJp = this.clampLotteryJackpot(v);
            }
          }
        }

        // Kiểm tra xem giữa anchorDraw và curDrawId có kỳ nào nổ Giải Đặc Biệt không
        let latestSpecWinDraw = 0;
        for (const dStr of Object.keys(this.lotterySpecialWins)) {
          const d = Number(dStr);
          if (d >= anchorDraw && d < curDrawId && d > latestSpecWinDraw) {
            latestSpecWinDraw = d;
          }
        }

        if (curDrawId <= 1) {
          curJp = LOTTERY_JACKPOT_BASE;
          prevJp = LOTTERY_JACKPOT_BASE;
          streak = 0;
        } else if (latestSpecWinDraw > 0) {
          // Từng có người nổ ĐB trong khoảng này
          if (latestSpecWinDraw === prevDrawId) {
            prevJp = this.lotterySpecialWins[prevDrawId]?.jackpot || anchorJp;
            curJp = LOTTERY_JACKPOT_BASE;
            streak = 0;
            wonFlag = true;
          } else {
            // Nổ ở kỳ trước đó nữa -> kỳ này khởi điểm lại
            prevJp = LOTTERY_JACKPOT_BASE;
            if (prevSoldTicketsCount > 0) {
              curJp = this.clampLotteryJackpot(prevJp + LOTTERY_JACKPOT_STEP);
              streak = 1;
            } else {
              curJp = prevJp;
              streak = 0;
            }
          }
        } else if (anchorDraw === prevDrawId) {
          prevJp = anchorJp;
          if (prevSpecialWon) {
            curJp = LOTTERY_JACKPOT_BASE;
            streak = 0;
            wonFlag = true;
          } else if (prevSoldTicketsCount > 0) {
            // CHỈ CỘNG DỒN KHI CÓ NGƯỜI CHƠI MUA VÉ
            curJp = this.clampLotteryJackpot(prevJp + LOTTERY_JACKPOT_STEP);
            streak = Math.round((curJp - LOTTERY_JACKPOT_BASE) / LOTTERY_JACKPOT_STEP);
          } else {
            // KỲ TRƯỚC KHÔNG CÓ AI MUA VÉ (vắng khách ban đêm) -> BẢO LƯU QUỸ THƯỞNG!
            curJp = prevJp;
            streak = Math.max(
              0,
              Math.min(10, Math.round((curJp - LOTTERY_JACKPOT_BASE) / LOTTERY_JACKPOT_STEP)),
            );
          }
        } else if (anchorDraw > 0) {
          // Khoảng thời gian vắng người chơi (off ban đêm), quỹ thưởng được bảo lưu
          prevJp = anchorJp;
          if (prevSpecialWon) {
            curJp = LOTTERY_JACKPOT_BASE;
            streak = 0;
            wonFlag = true;
          } else if (prevSoldTicketsCount > 0) {
            curJp = this.clampLotteryJackpot(prevJp + LOTTERY_JACKPOT_STEP);
            streak = Math.round((curJp - LOTTERY_JACKPOT_BASE) / LOTTERY_JACKPOT_STEP);
          } else {
            curJp = prevJp;
            streak = Math.max(
              0,
              Math.min(10, Math.round((curJp - LOTTERY_JACKPOT_BASE) / LOTTERY_JACKPOT_STEP)),
            );
          }
        } else {
          curJp = LOTTERY_JACKPOT_BASE;
          prevJp = LOTTERY_JACKPOT_BASE;
          streak = 0;
        }

        needWrite = true;
      }

      this.lotteryPrevPreserved = (prevSoldTicketsCount === 0 && prevDrawId >= 1 && !prevSpecialWon);

      // Nếu kỳ trước có tiệm trúng Giải Đặc Biệt, lưu vĩnh viễn vào lottery/special_wins (ưu tiên giữ mức jackpot chuẩn của Server)
      if (prevSpecialWon && prevSpecialTicket && !this.lotterySpecialWins[prevDrawId]) {
        const specRecord = {
          drawId: prevDrawId,
          num: prevSpecialNum,
          uid: prevSpecialTicket.uid,
          shopName: prevSpecialTicket.shopName || 'Tiệm Trái Cây',
          jackpot: prevJp,
          wonAt: Date.now(),
        };
        this.lotterySpecialWins[prevDrawId] = specRecord;
        this.saveLocalLotterySpecWins();
        runTransaction(ref(rtdb, `lottery/special_wins/${prevDrawId}`), (cur) => {
          if (cur && typeof cur === 'object' && Number((cur as any).jackpot) >= LOTTERY_JACKPOT_BASE) {
            return cur;
          }
          return specRecord;
        }).catch(() => {
          set(ref(rtdb, `lottery/special_wins/${prevDrawId}`), specRecord).catch(() => undefined);
        });
        runTransaction(ref(rtdb, `refCodes/LOT_SPEC_${prevDrawId}`), (cur) => {
          if (cur && typeof cur === 'string' && cur.includes('|')) {
            return cur;
          }
          return `${prevSpecialNum}|${prevSpecialTicket.uid}|${prevJp}|${_encHex(specRecord.shopName)}`;
        }).catch(() => undefined);
      } else if (this.lotterySpecialWins[prevDrawId]?.jackpot) {
        // Nếu trên Server đã ghi nhận tiệm trúng ĐB của kỳ trước, đồng bộ prevJp theo đúng số tiền tiệm đó nhận được
        prevJp = this.clampLotteryJackpot(this.lotterySpecialWins[prevDrawId].jackpot);
      }

      this.lotteryJackpot = curJp;
      this.lotteryPrevJackpot = prevJp;
      this.lotteryJackpotStreak = streak;
      this.lotteryPrevSpecialWon = wonFlag;
      this.lotteryJackpotHistory[curDrawId] = curJp;
      if (prevDrawId >= 1) {
        this.lotteryJackpotHistory[prevDrawId] = prevJp;
      }

      // Lưu lịch sử 72 kỳ gần nhất (24 giờ) vào cache
      const histEntries: string[] = [];
      for (let dId = curDrawId; dId >= Math.max(1, curDrawId - 72); dId--) {
        const val = this.lotteryJackpotHistory[dId];
        if (typeof val === 'number' && val >= LOTTERY_JACKPOT_BASE) {
          histEntries.push(`${dId}:${this.clampLotteryJackpot(val)}`);
        }
      }
      const payloadStr = `${curDrawId}|${curJp}|${streak}|${prevJp}|${wonFlag ? 1 : 0}|${histEntries.join(',')}`;
      this.saveLocalLotteryJackpotCache(payloadStr);

      if (needWrite && this.user && this.jackpotResolvedForDraw < curDrawId) {
        this.jackpotResolvedForDraw = curDrawId;
        // Dùng Atomic Transaction để đảm bảo mọi thiết bị (Android, iOS, PC) dùng chung 1 kết quả chốt duy nhất, không bao giờ ghi đè chéo nhau
        const txUpdater = (currentRaw: unknown) => {
          const curParsed = this.parseJackpotPayload(currentRaw);
          if (curParsed && curParsed.d === curDrawId) {
            // Chỉ cho phép cập nhật nếu phát hiện kỳ trước trúng ĐB cần reset về 3M
            if (prevSpecialWon && curParsed.j > LOTTERY_JACKPOT_BASE) {
              return payloadStr;
            }
            // Nếu máy trước tính thiếu vé (ví dụ 4.0M) mà máy này đã nạp đủ vé xác nhận có cộng dồn (4.5M) từ cùng mốc prevJp
            if (!prevSpecialWon && prevSoldTicketsCount > 0 && curParsed.p === prevJp && curJp > curParsed.j) {
              return payloadStr;
            }
            return; // Hủy ghi đè, giữ nguyên giá trị chuẩn trên Server!
          }
          if (curParsed && curParsed.d > curDrawId) {
            return;
          }
          return payloadStr;
        };

        runTransaction(ref(rtdb, 'lottery/jackpot'), txUpdater).catch(() => {
          set(ref(rtdb, 'lottery/jackpot'), payloadStr).catch(() => undefined);
        });
        runTransaction(ref(rtdb, 'refCodes/LOT_JP'), txUpdater).catch(() => {
          set(ref(rtdb, 'refCodes/LOT_JP'), payloadStr).catch(() => undefined);
        });
      }

      // Lưu kết quả tóm tắt kỳ trước vào lottery/draw_history/${prevDrawId}
      if (prevDrawId >= 1) {
        set(ref(rtdb, `lottery/draw_history/${prevDrawId}`), {
          drawId: prevDrawId,
          jackpot: prevJp,
          soldCount: prevSoldTicketsCount,
          specialWon: prevSpecialWon,
        }).catch(() => undefined);
      }

      refreshCachedWinnersReward();
      cleanOldLotteryDraws();
      this.emit();
    };

    const rebuildCurrentSold = () => {
      this.currentDrawSoldMap = { ...fallbackCurrentMap, ...dedicatedCurrentMap };
      // Luôn đảm bảo vé của người chơi mua ở kỳ này hiển thị tức thì trên sạp vé
      const myUid = this.user?.uid || '';
      const myShop = this.getShopSnapshot().shopName || 'Tiệm của bạn';
      for (const tk of this.myLotteryTickets) {
        if (tk.drawId === curDrawId && !this.currentDrawSoldMap[tk.num]) {
          this.currentDrawSoldMap[tk.num] = {
            num: tk.num,
            uid: myUid,
            shopName: myShop,
          };
        }
      }
      this.emit();
    };
    const rebuildPrevSold = () => {
      this.prevDrawSoldMap = { ...prevSnapshot, ...fallbackPrevMap, ...dedicatedPrevMap };
      // Luôn đảm bảo vé của người chơi ở kỳ trước có trong prevDrawSoldMap
      const myUid = this.user?.uid || '';
      const myShop = this.getShopSnapshot().shopName || 'Tiệm của bạn';
      for (const tk of this.myLotteryTickets) {
        if (tk.drawId === prevDrawId && !this.prevDrawSoldMap[tk.num]) {
          this.prevDrawSoldMap[tk.num] = {
            num: tk.num,
            uid: myUid,
            shopName: myShop,
          };
        }
      }
      this.drawSoldMapsCache[prevDrawId] = { ...this.prevDrawSoldMap };
      this.lotteryDrawSoldCountMap[prevDrawId] = Object.keys(this.prevDrawSoldMap).length;
      this.prevSoldLoadedForDraw = curDrawId;
      const updatedPrevWinners = this.computeWinnersForDraw(prevDrawId, this.prevDrawSoldMap);
      this.lotteryDrawWinnersCache[prevDrawId] = updatedPrevWinners;
      tryResolveJackpot();
      this.emit();
    };

    const startFallbackJp = () => {
      if (fbJpStarted || this.lotteryListeningDrawId !== curDrawId) return;
      fbJpStarted = true;
      try {
        const fbJpRef = ref(rtdb, 'refCodes/LOT_JP');
        const unsubFbJp = onValue(
          fbJpRef,
          (snap) => {
            this.rawJackpotData = snap.exists() ? snap.val() : null;
            this.jackpotLoadedForDraw = curDrawId;
            tryResolveJackpot();
          },
          () => {
            this.jackpotLoadedForDraw = curDrawId;
            tryResolveJackpot();
          },
        );
        this.lotteryUnsubs.push(unsubFbJp);
      } catch {}
    };

    const startFallbackCur = () => {
      if (fbCurStarted || this.lotteryListeningDrawId !== curDrawId) return;
      fbCurStarted = true;
      try {
        const fbCurPrefix = `LOT_${curDrawId}_`;
        const fbCurQuery = query(
          ref(rtdb, 'refCodes'),
          orderByKey(),
          startAt(fbCurPrefix),
          endAt(`${fbCurPrefix}\uf8ff`),
        );
        const unsubFbCur = onValue(
          fbCurQuery,
          (snap) => {
            const map: Record<string, LotterySoldTicketInfo> = {};
            if (snap.exists() && typeof snap.val() === 'object') {
              for (const [k, v] of Object.entries(snap.val() || {})) {
                if (!k.startsWith(fbCurPrefix)) continue;
                const tail = k.slice(fbCurPrefix.length);
                const dashIdx = tail.indexOf('-');
                const rawNum = dashIdx >= 0 ? tail.slice(0, dashIdx) : tail;
                const hexShop = dashIdx >= 0 ? tail.slice(dashIdx + 1) : '';
                const uid = String(v || '').trim();
                if (/^\d{1,3}$/.test(rawNum) && uid) {
                  const num = rawNum.padStart(3, '0').slice(-3);
                  map[num] = {
                    num,
                    uid,
                    shopName: hexShop ? _decHex(hexShop) : map[num]?.shopName || 'Tiệm Trái Cây',
                  };
                }
              }
            }
            fallbackCurrentMap = map;
            rebuildCurrentSold();
          },
          () => undefined,
        );
        this.lotteryUnsubs.push(unsubFbCur);
      } catch {}
    };

    const startFallbackPrev = () => {
      if (fbPrevStarted || this.lotteryListeningDrawId !== curDrawId) return;
      fbPrevStarted = true;
      try {
        const fbPrevPrefix = `LOT_${prevDrawId}_`;
        const fbPrevQuery = query(
          ref(rtdb, 'refCodes'),
          orderByKey(),
          startAt(fbPrevPrefix),
          endAt(`${fbPrevPrefix}\uf8ff`),
        );
        const unsubFbPrev = onValue(
          fbPrevQuery,
          (snap) => {
            const map: Record<string, LotterySoldTicketInfo> = {};
            if (snap.exists() && typeof snap.val() === 'object') {
              for (const [k, v] of Object.entries(snap.val() || {})) {
                if (!k.startsWith(fbPrevPrefix)) continue;
                const tail = k.slice(fbPrevPrefix.length);
                const dashIdx = tail.indexOf('-');
                const rawNum = dashIdx >= 0 ? tail.slice(0, dashIdx) : tail;
                const hexShop = dashIdx >= 0 ? tail.slice(dashIdx + 1) : '';
                const uid = String(v || '').trim();
                if (/^\d{1,3}$/.test(rawNum) && uid) {
                  const num = rawNum.padStart(3, '0').slice(-3);
                  map[num] = {
                    num,
                    uid,
                    shopName: hexShop ? _decHex(hexShop) : map[num]?.shopName || 'Tiệm Trái Cây',
                  };
                }
              }
            }
            fallbackPrevMap = map;
            rebuildPrevSold();
          },
          () => {
            this.prevSoldLoadedForDraw = curDrawId;
            tryResolveJackpot();
          },
        );
        this.lotteryUnsubs.push(unsubFbPrev);
      } catch {}
    };

    let fbSpecStarted = false;
    const startFallbackSpecWins = () => {
      if (fbSpecStarted || this.lotteryListeningDrawId !== curDrawId) return;
      fbSpecStarted = true;
      try {
        const fbSpecQuery = query(
          ref(rtdb, 'refCodes'),
          orderByKey(),
          startAt('LOT_SPEC_'),
          endAt('LOT_SPEC_\uf8ff'),
        );
        const unsubFbSpec = onValue(
          fbSpecQuery,
          (snap) => {
            if (snap.exists() && typeof snap.val() === 'object') {
              for (const [k, v] of Object.entries(snap.val() || {})) {
                if (!k.startsWith('LOT_SPEC_')) continue;
                const dId = Number(k.slice('LOT_SPEC_'.length));
                if (dId > 0 && typeof v === 'string') {
                  const [num, uid, jpRaw, hexShop] = v.split('|');
                  const jp = this.clampLotteryJackpot(Number(jpRaw) || LOTTERY_JACKPOT_BASE);
                  this.lotterySpecialWins[dId] = {
                    drawId: dId,
                    num: num || '',
                    uid: uid || '',
                    shopName: hexShop ? _decHex(hexShop) : 'Tiệm Trái Cây',
                    jackpot: jp,
                    wonAt: 0,
                  };
                  this.lotteryJackpotHistory[dId] = jp;
                }
              }
              this.saveLocalLotterySpecWins();
              refreshCachedWinnersReward();
              tryResolveJackpot();
              this.emit();
            }
          },
          () => undefined,
        );
        this.lotteryUnsubs.push(unsubFbSpec);
      } catch {}
    };

    try {
      // Lắng nghe trạng thái Bảo trì Đại lý Vé số thời gian thực (siêu nhẹ, chỉ đọc khóa SEC_BAN___LOTTERY_MAINT___)
      const maintQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('SEC_BAN___LOTTERY_MAINT___'),
        endAt('SEC_BAN___LOTTERY_MAINT___\uf8ff'),
      );
      const unsubMaint = onValue(
        maintQuery,
        (snap) => {
          for (const k of Object.keys(this.rawSecBanMap)) {
            if (k.startsWith('SEC_BAN___LOTTERY_MAINT___')) {
              delete this.rawSecBanMap[k];
            }
          }
          if (snap.exists() && typeof snap.val() === 'object') {
            Object.assign(this.rawSecBanMap, snap.val());
          }
          this.recomputeSecurityModeration(this.user?.uid || '');
          this.emit();
        },
        () => undefined,
      );
      this.lotteryUnsubs.push(unsubMaint);

      // Lắng nghe các kỳ nổ Giải Đặc Biệt được lưu vĩnh viễn
      const specWinsRef = ref(rtdb, 'lottery/special_wins');
      const unsubSpec = onValue(
        specWinsRef,
        (snap) => {
          if (snap.exists() && typeof snap.val() === 'object') {
            for (const [k, v] of Object.entries(snap.val() || {})) {
              const dId = Number(k);
              if (dId > 0 && v && typeof v === 'object') {
                const item = v as any;
                this.lotterySpecialWins[dId] = {
                  drawId: dId,
                  num: String(item.num || ''),
                  uid: String(item.uid || ''),
                  shopName: String(item.shopName || 'Tiệm Trái Cây'),
                  jackpot: this.clampLotteryJackpot(item.jackpot),
                  wonAt: Number(item.wonAt) || 0,
                };
                this.lotteryJackpotHistory[dId] = this.clampLotteryJackpot(item.jackpot);
              }
            }
            this.saveLocalLotterySpecWins();
            refreshCachedWinnersReward();
            tryResolveJackpot();
            this.emit();
          }
        },
        () => {
          startFallbackSpecWins();
        },
      );
      this.lotteryUnsubs.push(unsubSpec);

      // Lắng nghe node Jackpot siêu gọn (~65 bytes)
      const jpRef = ref(rtdb, 'lottery/jackpot');
      const unsubJp = onValue(
        jpRef,
        (snap) => {
          this.rawJackpotData = snap.exists() ? snap.val() : null;
          this.jackpotLoadedForDraw = curDrawId;
          tryResolveJackpot();
        },
        () => {
          startFallbackJp();
        },
      );
      this.lotteryUnsubs.push(unsubJp);

      // Chỉ lắng nghe nhánh chuyên biệt lottery/draws/{curDrawId}; chỉ bật nhánh dự phòng nếu báo lỗi quyền truy cập
      const curDrawRef = ref(rtdb, `lottery/draws/${curDrawId}`);
      const unsubCur = onValue(
        curDrawRef,
        (snap) => {
          const map: Record<string, LotterySoldTicketInfo> = {};
          if (snap.exists() && typeof snap.val() === 'object') {
            for (const [k, v] of Object.entries(snap.val() || {})) {
              const parsed = this.parseSoldTicketValue(k, v);
              if (parsed) map[parsed.num] = parsed;
            }
          }
          dedicatedCurrentMap = map;
          rebuildCurrentSold();
        },
        () => {
          startFallbackCur();
        },
      );
      this.lotteryUnsubs.push(unsubCur);

      if (prevDrawId >= 1) {
        const prevDrawRef = ref(rtdb, `lottery/draws/${prevDrawId}`);
        const unsubPrev = onValue(
          prevDrawRef,
          (snap) => {
            const map: Record<string, LotterySoldTicketInfo> = {};
            if (snap.exists() && typeof snap.val() === 'object') {
              for (const [k, v] of Object.entries(snap.val() || {})) {
                const parsed = this.parseSoldTicketValue(k, v);
                if (parsed) map[parsed.num] = parsed;
              }
            }
            dedicatedPrevMap = map;
            rebuildPrevSold();
          },
          () => {
            startFallbackPrev();
          },
        );
        this.lotteryUnsubs.push(unsubPrev);
      }
    } catch {}
  }

  private checkAndNotifyNewLotteryDraw(finishedDrawId: number) {
    if (!this.user || this.lastNotifiedWinDrawId >= finishedDrawId) return;
    const myFinished = this.myLotteryTickets.filter((t) => t.drawId === finishedDrawId);
    if (myFinished.length === 0) return;
    this.lastNotifiedWinDrawId = finishedDrawId;

    let wonCount = 0;
    let totalWon = 0;
    for (const tk of myFinished) {
      const pr = this.evaluateLotteryTicketPrize(finishedDrawId, tk.num);
      if (pr.won && pr.reward > 0) {
        wonCount++;
        totalWon += pr.reward;
      }
    }
    if (wonCount > 0) {
      this.bridge?.playSound?.('success');
      this.bridge?.notify(
        `Kỳ vé số #${finishedDrawId} vừa mở thưởng! Bạn trúng ${wonCount} vé (+${totalWon.toLocaleString('vi-VN')}đ), vào Đại Lý Vé Số lãnh thưởng ngay nha!`,
        'good',
      );
    } else {
      this.bridge?.notify(
        `Kỳ vé số #${finishedDrawId} đã có kết quả mở thưởng! Ghé Đại Lý Vé Số để dò kết quả nha.`,
        'info',
      );
    }
  }

  async buyLotteryTicket(numRaw: string): Promise<boolean> {
    if (!this.user) {
      this.bridge?.notify('Vui lòng đăng nhập tài khoản trước khi mua vé số kiến thiết nha!', 'bad');
      return false;
    }
    if (this.isKickedByOtherDevice || this.isCurrentAccountBanned) return false;
    if (this.lotteryMaintenance) {
      this.bridge?.notify('Admin đang bảo trì chức năng này, vui lòng quay lại sau!', 'bad');
      return false;
    }
    if (this.lotteryBusy) return false;
    const rawInput = String(numRaw || '').trim();
    const num = rawInput.padStart(3, '0').slice(-3);
    if (!/^\d{1,3}$/.test(rawInput) || !/^\d{3}$/.test(num)) {
      this.bridge?.notify('Vui lòng chọn số vé hợp lệ từ 000 đến 999 nha!', 'bad');
      return false;
    }

    const shop = this.getShopSnapshot();
    if (!shop.hasShop) {
      this.bridge?.notify('Vui lòng mở tiệm trước khi mua vé số kiến thiết nha!', 'bad');
      return false;
    }
    if (shop.level < 3 || shop.day < 5) {
      this.bridge?.notify(
        'Tiệm cần đạt Cấp 3 và từ Ngày 5 trở lên mới mở khóa Đại lý Vé số Kiến thiết nha!',
        'bad',
      );
      return false;
    }

    const curDrawId = this.getCurrentLotteryDrawId();
    const boardTickets = this.getLotteryBoardTickets(curDrawId);
    if (!boardTickets.includes(num)) {
      this.bridge?.notify('Tờ vé số này không có trong 200 vé phát hành của kỳ hiện tại nha!', 'bad');
      return false;
    }

    if (this.lotteryListeningDrawId !== curDrawId) {
      this.startLotteryDrawSync(true);
    }

    const existingSold = this.currentDrawSoldMap[num];
    if (existingSold) {
      if (existingSold.uid === this.user.uid) {
        this.bridge?.notify(`Bạn đã mua vé số ${num} trong kỳ này rồi!`, 'info');
      } else {
        this.bridge?.notify(
          `Vé số ${num} đã được tiệm "${existingSold.shopName}" mua trước rồi! Hãy chọn số khác nha.`,
          'bad',
        );
      }
      return false;
    }

    const myCurrentTickets = this.getMyTicketsInCurrentDraw();
    if (myCurrentTickets.length >= LOTTERY_MAX_PER_DRAW) {
      this.bridge?.notify(
        `Mỗi kỳ mở thưởng một tiệm chỉ được mua tối đa ${LOTTERY_MAX_PER_DRAW} tờ vé số thôi nha!`,
        'bad',
      );
      return false;
    }

    if (shop.money < LOTTERY_TICKET_PRICE) {
      this.bridge?.notify(
        `Chưa đủ tiền trong két! Cần ${LOTTERY_TICKET_PRICE.toLocaleString('vi-VN')}đ để mua 1 tờ vé số.`,
        'bad',
      );
      return false;
    }

    const uid = this.user.uid;
    const cleanShop = (shop.shopName || 'Tiệm Trái Cây').slice(0, 26);
    const hexShop = _encHex(cleanShop);
    const compactVal = `${uid}|${hexShop}`;

    this.lotteryBusy = true;
    this.emit();
    try {
      let claimedOnServer = false;
      const ticketRef = ref(rtdb, `lottery/draws/${curDrawId}/${num}`);

      // Thử khóa vé trên nhánh tối ưu lottery/draws/{curDrawId}/{num}
      try {
        const txRes = await runTransaction(ticketRef, (cur) => {
          if (cur) return;
          return compactVal;
        });
        if (txRes.committed && String(txRes.snapshot.val() || '').startsWith(`${uid}|`)) {
          claimedOnServer = true;
        } else {
          const checkSnap = await get(ticketRef);
          if (checkSnap.exists() && !String(checkSnap.val() || '').startsWith(`${uid}|`)) {
            this.bridge?.notify(
              `Vé số ${num} vừa có chủ tiệm khác nhanh tay mua mất rồi! Hãy chọn số khác nha.`,
              'bad',
            );
            return false;
          }
        }
      } catch {
        // Nếu nhánh lottery/draws chưa được cập nhật Rule trên Console, dùng nhánh dự phòng tương thích ngược
        const fbLockRef = ref(rtdb, `refCodes/LOT_${curDrawId}_${num}`);
        const existingSnap = await get(fbLockRef);
        if (existingSnap.exists() && String(existingSnap.val() || '') !== uid) {
          this.bridge?.notify(
            `Vé số ${num} vừa có chủ tiệm khác nhanh tay mua mất rồi! Hãy chọn số khác nha.`,
            'bad',
          );
          return false;
        }
        await set(fbLockRef, uid);
        const verifySnap = await get(fbLockRef);
        if (verifySnap.exists() && String(verifySnap.val() || '') === uid) {
          claimedOnServer = true;
          set(ref(rtdb, `refCodes/LOT_${curDrawId}_${num}-${hexShop}`), uid).catch(() => undefined);
        }
      }

      if (!claimedOnServer) {
        this.bridge?.notify(
          `Vé số ${num} vừa có người mua trước rồi! Hãy chọn con số may mắn khác nha.`,
          'bad',
        );
        return false;
      }

      const paid = this.bridge?.spendShopMoney?.(LOTTERY_TICKET_PRICE);
      if (!paid) {
        this.bridge?.notify('Không thể trừ tiền trong két, vui lòng vào tiệm kiểm tra lại nha!', 'bad');
        return false;
      }

      const now = this.getServerNow();
      const ticketId = `${curDrawId}_${num}`;
      const activeJackpot = this.getLotteryJackpotForDraw(curDrawId);
      this.lotteryJackpotHistory[curDrawId] = activeJackpot;
      this.currentDrawSoldMap[num] = { num, uid, shopName: cleanShop };
      this.mergeCloudLotteryTickets(uid, [
        {
          id: ticketId,
          drawId: curDrawId,
          num,
          boughtAt: now,
          claimed: false,
          jackpot: activeJackpot,
        },
      ]);
      this.saveLocalLotteryMeta(uid, true);

      this.bridge?.playSound?.('cash');
      this.bridge?.notify(
        `Đã mua vé số [${num}] (Kỳ #${curDrawId}) giá ${LOTTERY_TICKET_PRICE.toLocaleString('vi-VN')}đ! Giải Đặc Biệt kỳ này: ${activeJackpot.toLocaleString('vi-VN')}đ!`,
        'good',
      );
      return true;
    } catch {
      this.bridge?.notify('Chưa mua được vé số, vui lòng kiểm tra kết nối mạng rồi thử lại nha!', 'bad');
      return false;
    } finally {
      this.lotteryBusy = false;
      this.emit();
    }
  }

  async claimLotteryTicket(ticketId: string): Promise<boolean> {
    if (!this.user || this.lotteryBusy || this.isKickedByOtherDevice || this.isCurrentAccountBanned) return false;
    const uid = this.user.uid;
    const curDrawId = this.getCurrentLotteryDrawId();
    const tk = this.myLotteryTickets.find((x) => x.id === ticketId);
    if (!tk || tk.drawId >= curDrawId || tk.claimed || this.lotteryClaimedKeys.has(tk.id)) {
      return false;
    }
    const pr = this.evaluateLotteryTicketPrize(tk.drawId, tk.num);
    if (!pr.won || pr.reward <= 0) return false;

    if (this.bridge?.hasActiveShop && !this.bridge.hasActiveShop()) {
      this.bridge?.notify('Vui lòng vào tiệm trước khi lĩnh tiền thưởng vé số nha!', 'bad');
      return false;
    }

    this.lotteryBusy = true;
    this.emit();
    try {
      // Kiểm tra chống lĩnh trùng trên thiết bị khác (chỉ đọc đúng ngăn kéo con của vé số)
      try {
        const [claimedListSnap, ticketClaimSnap] = await Promise.all([
          get(ref(rtdb, `referrals/${uid}/lotteryClaimed`)).catch(() => null),
          get(ref(rtdb, `referrals/${uid}/lotClaim_${ticketId}`)).catch(() => null),
        ]);
        const cloudCl: string[] =
          claimedListSnap?.exists() && Array.isArray(claimedListSnap.val())
            ? claimedListSnap.val()
            : [];
        if (cloudCl.includes(ticketId) || ticketClaimSnap?.exists()) {
          this.lotteryClaimedKeys.add(ticketId);
          tk.claimed = true;
          this.saveLocalLotteryMeta(uid, false);
          this.bridge?.notify('Tờ vé số này đã được lĩnh thưởng trên thiết bị khác rồi!', 'bad');
          return false;
        }
      } catch {}

      this.lotteryClaimedKeys.add(ticketId);
      tk.claimed = true;
      this.saveLocalLotteryMeta(uid, true);

      await update(ref(rtdb, `referrals/${uid}`), {
        [`lotClaim_${ticketId}`]: Date.now(),
        lotteryTickets: this.myLotteryTickets,
        lotteryClaimed: Array.from(this.lotteryClaimedKeys).slice(-60),
      }).catch(() => undefined);

      this.bridge?.grantReferralMoney?.(pr.reward);
      this.bridge?.playSound?.('cash');
      this.bridge?.notify(
        `Chúc mừng! Đã lĩnh thưởng ${pr.title} (Vé số ${tk.num} · Kỳ #${tk.drawId}): +${pr.reward.toLocaleString('vi-VN')}đ vào két!`,
        'good',
      );
      return true;
    } finally {
      this.lotteryBusy = false;
      this.emit();
    }
  }

  async claimAllLotteryTickets(): Promise<number> {
    if (!this.user || this.lotteryBusy) return 0;
    const curDrawId = this.getCurrentLotteryDrawId();
    const claimable = this.myLotteryTickets.filter((tk) => {
      if (tk.drawId >= curDrawId || tk.claimed || this.lotteryClaimedKeys.has(tk.id)) return false;
      const pr = this.evaluateLotteryTicketPrize(tk.drawId, tk.num);
      return pr.won && pr.reward > 0;
    });
    if (claimable.length === 0) return 0;
    let count = 0;
    for (const tk of claimable) {
      const ok = await this.claimLotteryTicket(tk.id);
      if (ok) count++;
    }
    return count;
  }

  public isCurrentAccountBanned = false;
  public isKickedByOtherDevice = false;
  private mySessionId = '';
  private mySessionClaimAt = 0;
  private sessionConfirmedOnServer = false;
  private sessionClaimInProgress = false;
  private mySessionLocalStartMs = 0;
  public bannedUids = new Set<string>();
  public hiddenLbUids = new Set<string>();
  public securityReports: SecurityReportItem[] = [];
  public bugReports: BugReportItem[] = [];
  private rawSecBanMap: Record<string, any> = {};
  private rawSecHideMap: Record<string, any> = {};
  private rawSecRepMap: Record<string, any> = {};
  private rawSecRdelMap: Record<string, any> = {};
  private adminRepUnsubs: Array<() => void> = [];
  private autoReportedKeys = new Set<string>();
  private reportedBugHashes = new Set<string>();
  private lastBugReportSentAt = 0;
  private bugReportSessionCount = 0;

  startAdminReportsRealtime() {
    if (this.adminRepUnsubs.length > 0) return;
    try {
      const repQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('SEC_REP_'),
        endAt('SEC_REP_\uf8ff'),
      );
      const unsubRep = onValue(
        repQuery,
        (snap) => {
          this.rawSecRepMap = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeAdminReports();
          this.emit();
        },
        () => undefined,
      );
      this.adminRepUnsubs.push(unsubRep);

      const rdelQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('SEC_RDEL_'),
        endAt('SEC_RDEL_\uf8ff'),
      );
      const unsubRdel = onValue(
        rdelQuery,
        (snap) => {
          this.rawSecRdelMap = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeAdminReports();
          this.emit();
        },
        () => undefined,
      );
      this.adminRepUnsubs.push(unsubRdel);
    } catch {}
  }

  stopAdminReportsRealtime() {
    while (this.adminRepUnsubs.length > 0) {
      const fn = this.adminRepUnsubs.pop();
      try {
        fn?.();
      } catch {}
    }
  }

  private recomputeSecurityModeration(uid: string) {
    const parseModerationEntries = (rawMap: Record<string, any>, prefix: string) => {
      const latestByUid = new Map<string, { ts: number; state: string }>();
      for (const [k, v] of Object.entries(rawMap)) {
        if (!k.startsWith(prefix) || !v) continue;
        const rest = k.slice(prefix.length);
        const lastDash = rest.lastIndexOf('-');
        const uidAndTs = lastDash > 0 ? rest.slice(0, lastDash) : rest;
        const state = lastDash > 0 ? rest.slice(lastDash + 1) : '1';
        const lastUnderscore = uidAndTs.lastIndexOf('_');
        let targetUid = uidAndTs;
        let ts = 0;
        if (lastUnderscore > 0) {
          const maybeTs = parseInt(uidAndTs.slice(lastUnderscore + 1), 10);
          if (!isNaN(maybeTs) && maybeTs > 1000000000000) {
            targetUid = uidAndTs.slice(0, lastUnderscore);
            ts = maybeTs;
          }
        }
        const prev = latestByUid.get(targetUid);
        if (!prev || ts >= prev.ts) {
          latestByUid.set(targetUid, { ts, state });
        }
      }
      const activeSet = new Set<string>();
      for (const [targetUid, info] of latestByUid.entries()) {
        if (info.state === '1') activeSet.add(targetUid);
      }
      return activeSet;
    };

    const nextBanned = parseModerationEntries(this.rawSecBanMap, 'SEC_BAN_');
    const nextHidden = parseModerationEntries(this.rawSecHideMap, 'SEC_HIDE_');
    const nextLotteryMaint = nextBanned.has('__LOTTERY_MAINT__');
    nextBanned.delete('__LOTTERY_MAINT__');
    const nextChatMaint = nextBanned.has('__CHAT_MAINT__');
    nextBanned.delete('__CHAT_MAINT__');
    const prevChatMaint = this.chatMaintenance;
    this.lotteryMaintenance = nextLotteryMaint;
    this.chatMaintenance = nextChatMaint;
    if (nextChatMaint && !prevChatMaint) {
      this.pauseChatRealtimeListeners();
    }
    this.bannedUids = nextBanned;
    this.hiddenLbUids = nextHidden;
    const activeUid = (uid || this.user?.uid || '').trim();
    this.isCurrentAccountBanned = !!(activeUid && nextBanned.has(activeUid));

    // Lọc ngay lập tức mọi tài khoản bị ẩn/khóa khỏi danh sách BXH trong bộ nhớ máy
    if (this.leaderboard.some((e) => this.isUidHiddenFromLeaderboard(e.uid))) {
      this.leaderboard = this.leaderboard.filter((e) => !this.isUidHiddenFromLeaderboard(e.uid));
    }
    if (this.daysLeaderboard.some((e) => this.isUidHiddenFromLeaderboard(e.uid))) {
      this.daysLeaderboard = this.daysLeaderboard.filter((e) => !this.isUidHiddenFromLeaderboard(e.uid));
    }

    // Nếu đang là Admin, tự động quét và xóa triệt để khỏi Firestore nếu còn sót tài khoản bị ẩn/khóa trên BXH
    if (this.isCurrentUserAdmin()) {
      for (const hUid of Array.from(nextHidden)) {
        if (
          this.leaderboard.some((e) => e.uid === hUid) ||
          this.daysLeaderboard.some((e) => e.uid === hUid)
        ) {
          this.purgeUidFromFirestoreLeaderboards(hUid).catch(() => undefined);
        }
      }
      for (const bUid of Array.from(nextBanned)) {
        if (
          this.leaderboard.some((e) => e.uid === bUid) ||
          this.daysLeaderboard.some((e) => e.uid === bUid)
        ) {
          this.purgeUidFromFirestoreLeaderboards(bUid).catch(() => undefined);
        }
      }
    }
  }

  isUidHiddenFromLeaderboard(uid?: string): boolean {
    if (!uid) return false;
    return this.hiddenLbUids.has(uid) || this.bannedUids.has(uid);
  }

  isUidBanned(uid?: string): boolean {
    if (!uid) return false;
    return this.bannedUids.has(uid);
  }

  getFilteredLeaderboard(list: LeaderboardEntry[]): LeaderboardEntry[] {
    if (!Array.isArray(list)) return [];
    return list.filter(
      (item) => item && !this.isUidHiddenFromLeaderboard(item.uid) && (item.day || 1) >= 10,
    );
  }

  private recomputeAdminReports() {
    const deletedIds = new Set<string>();
    const dismissedAutoUids = new Set<string>();
    for (const [k, v] of Object.entries(this.rawSecRdelMap)) {
      if (k.startsWith('SEC_RDEL_')) {
        const id = k.slice(9);
        deletedIds.add(id);
        if (id.startsWith('SCAN_')) {
          dismissedAutoUids.add(id.slice(5));
        }
        if (typeof v === 'string' && v.startsWith('UID:')) {
          dismissedAutoUids.add(v.slice(4));
        }
      }
    }
    try {
      const localDismissed = JSON.parse(localStorage.getItem('ttc_admin_dismissed_uids_v1') || '[]');
      if (Array.isArray(localDismissed)) {
        for (const u of localDismissed) {
          if (typeof u === 'string' && u) dismissedAutoUids.add(u);
        }
      }
    } catch {}

    const list: SecurityReportItem[] = [];
    const bugList: BugReportItem[] = [];
    const seenAutoUids = new Set<string>();
    const seenBugKeys = new Set<string>();

    // Duyệt từ mới nhất xuống cũ nhất để mỗi UID chỉ giữ 1 báo cáo tự động duy nhất
    const sortedEntries = Object.entries(this.rawSecRepMap).sort((a, b) => b[0].localeCompare(a[0]));

    for (const [k, v] of sortedEntries) {
      if (!k.startsWith('SEC_REP_') || deletedIds.has(k)) continue;
      const rawHex = k.slice(8);
      const firstDash = rawHex.indexOf('-');
      if (firstDash <= 0) continue;
      const ts = parseInt(rawHex.slice(0, firstDash), 10) || 0;
      const jsonStr = _decMsgHex(rawHex.slice(firstDash + 1));
      if (!ts || !jsonStr) continue;
      try {
        let obj: any;
        try {
          obj = JSON.parse(jsonStr);
        } catch {
          if (jsonStr.startsWith('{"t":')) {
            const cleanStr = jsonStr.replace(/\\+$/, '');
            const patched = cleanStr.endsWith('"') ? cleanStr + '}' : cleanStr + '"}';
            try {
              obj = JSON.parse(patched);
            } catch {}
          }
        }
        if (!obj) continue;

        if (obj.t === 'B') {
          const bugMsg = String(obj.e || 'Lỗi không xác định');
          const bugStack = String(obj.st || '');
          if (this.isIgnorableClientError(bugMsg, bugStack)) {
            continue;
          }
          const bugUid = String(obj.u || v || 'GUEST').trim();
          const bugHash = String(obj.h || '').trim() || String(_fnv32(bugMsg));
          const dedupKey = `${bugHash}_${bugUid}`;
          if (seenBugKeys.has(dedupKey)) continue;
          seenBugKeys.add(dedupKey);
          bugList.push({
            id: k,
            hash: bugHash,
            uid: bugUid,
            shopName: String(obj.s || 'Khách / Chưa rõ'),
            day: Number(obj.d) || 1,
            level: Number(obj.l) || 1,
            money: Number(obj.m) || 0,
            phase: String(obj.p || 'unknown'),
            source: String(obj.src || 'runtime'),
            device: String(obj.dv || 'Web'),
            message: bugMsg,
            stack: bugStack,
            createdAt: ts,
          });
          continue;
        }

        const targetUid = String(obj.u || '').trim();
        if (!targetUid || this.bannedUids.has(targetUid)) continue;

        if (obj.t === 'A') {
          if (dismissedAutoUids.has(targetUid) || seenAutoUids.has(targetUid)) {
            continue;
          }
          // Tự động sàng lọc lại các báo cáo tự động cũ bằng bộ lọc mới (loại trừ hoàn toàn báo động giả Cấp 6, 7, 8 hoặc người chơi chân chính)
          const objDay = Number(obj.d) || 1;
          const objLvl = typeof obj.l === 'number' && obj.l >= 1 ? obj.l : 0;
          const reCheck = this.evaluateSuspiciousStats(Number(obj.m) || 0, objDay, objLvl);
          if (!reCheck) {
            // Tự động ghi nhận đã xử lý để dọn sạch báo cáo giả cũ khỏi danh sách
            continue;
          }
          seenAutoUids.add(targetUid);
          obj.r = reCheck;
        }
        list.push({
          id: k,
          type: obj.t === 'A' ? 'AUTO_HACK' : 'USER_REPORT',
          targetUid,
          targetShop: String(obj.s || 'Tiệm Trái Cây'),
          reporterUid: String(v || obj.ru || ''),
          reporterShop: String(obj.rs || 'Hệ thống Anti-Cheat'),
          money: Number(obj.m) || 0,
          day: Number(obj.d) || 1,
          level: Number(obj.l) || 1,
          reason: String(obj.r || ''),
          createdAt: ts,
        });
      } catch {}
    }
    list.sort((a, b) => b.createdAt - a.createdAt);
    bugList.sort((a, b) => b.createdAt - a.createdAt);

    // Tự động quét thêm các tài khoản thực sự gian lận trên BXH hiện tại (bỏ qua các tài khoản Admin đã bấm Bỏ qua)
    for (const entry of this.leaderboard) {
      if (!entry || !entry.uid || this.isEntryAdmin(entry)) continue;
      if (
        dismissedAutoUids.has(entry.uid) ||
        seenAutoUids.has(entry.uid) ||
        deletedIds.has(`SCAN_${entry.uid}`) ||
        this.bannedUids.has(entry.uid)
      ) {
        continue;
      }
      const entryDay = entry.day || 1;
      const explicitLevel =
        typeof entry.level === 'number' && entry.level >= 1 ? entry.level : 0;
      const suspicion = this.evaluateSuspiciousStats(entry.money, entryDay, explicitLevel);
      if (suspicion) {
        seenAutoUids.add(entry.uid);
        list.unshift({
          id: `SCAN_${entry.uid}`,
          type: 'AUTO_HACK',
          targetUid: entry.uid,
          targetShop: entry.shopName,
          reporterUid: 'SYSTEM_SCANNER',
          reporterShop: 'Máy quét BXH Tự động',
          money: entry.money,
          day: entryDay,
          level: explicitLevel || 1,
          reason: suspicion,
          createdAt: entry.updatedAt || Date.now(),
        });
      }
    }
    this.securityReports = list;
    this.bugReports = bugList;
  }

  // Kiểm tra nghi vấn hack thông minh chuẩn xác (CHỈ BÁO CÁO KHI CHẮC CHẮN GIAN LẬN, TUYỆT ĐỐI KHÔNG BÁO NHẦM NGƯỜI CHƠI BÌNH THƯỜNG)
  evaluateSuspiciousStats(money: number, day: number, level?: number): string | null {
    const d = Math.max(1, Math.floor(Number(day) || 1));
    const m = Number(money);
    const lvl = typeof level === 'number' && Number.isFinite(level) && level >= 1 ? Math.floor(level) : 0;

    // 1. Kiểm tra can thiệp giá trị số (NaN, Vô cực, Tiền âm cực lớn - dấu hiệu Cheat Engine)
    if (!Number.isFinite(m) || Number.isNaN(m)) {
      return `Dữ liệu tiền tệ không hợp lệ (NaN hoặc Vô cực)`;
    }
    if (m < -50000000) {
      return `Nghi vấn can thiệp bộ nhớ: Số tiền âm bất thường (${m.toLocaleString('vi-VN')}đ)`;
    }

    // 2. Kiểm tra can thiệp số thập phân lạ từ công cụ chỉnh sửa bộ nhớ (Memory Editor)
    if (m > 1000 && m % 1 !== 0) {
      const decPart = Math.abs(m % 1).toString();
      if (decPart.length > 6) {
        return `Nghi vấn can thiệp bộ nhớ: Tiền chứa số thập phân bất thường (${m})`;
      }
    }

    // 3. Kiểm tra tổng tài sản vượt trần nền kinh tế game (> 50 tỷ đồng)
    if (m > 50000000000) {
      return `Tổng tài sản vượt trần tối đa nền kinh tế game: ${m.toLocaleString('vi-VN')}đ (Ngày ${d})`;
    }

    // 4. Kiểm tra số ngày chơi nhảy vọt bất thường (> 5000 ngày)
    if (d > 5000) {
      return `Số ngày chơi nhảy vọt bất thường: Ngày ${d}`;
    }

    // 5. Kiểm tra cấp tiệm vượt giới hạn thật của game (Trong game có 9 cấp: Cấp 6 Chi nhánh 2, Cấp 7 Vựa đêm, Cấp 8 Xưởng, Cấp 9 Tiệm Đặc Sản Danh Tiếng)
    if (lvl > 9) {
      return `Hack cấp tiệm vượt giới hạn: Cấp ${lvl} (Tối đa Cấp 9)`;
    }

    // 6. Kiểm tra gian lận tiền ở những ngày đầu tiên (đã tính trừ hao Trúng Đặc Biệt vé số 8M + Thưởng mốc giới thiệu bạn bè + Giftcode)
    if (d === 1 && m > 50000000) {
      return `Hack tiền khởi đầu: Ngày 1 nhưng sở hữu ${m.toLocaleString('vi-VN')}đ`;
    }
    if (d === 2 && m > 100000000) {
      return `Tốc độ tăng tiền bất thường: Ngày 2 đạt ${m.toLocaleString('vi-VN')}đ`;
    }
    if (d <= 5 && m > 300000000) {
      return `Tốc độ tăng tiền bất thường: Ngày ${d} đạt ${m.toLocaleString('vi-VN')}đ`;
    }
    if (d <= 10 && m > 800000000) {
      return `Vượt ngưỡng thu nhập giai đoạn đầu: Ngày ${d} đạt ${m.toLocaleString('vi-VN')}đ`;
    }

    // 7. Kiểm tra tỷ lệ tiền kiếm được trung bình mỗi ngày ở giai đoạn đầu (d < 15 ngày mà trung bình > 100M/ngày)
    if (d >= 3 && d < 15 && m / d > 100000000) {
      return `Tỷ lệ sinh lời bất khả thi: Ngày ${d} đạt ${m.toLocaleString('vi-VN')}đ (Trung bình ${(Math.round(m / d)).toLocaleString('vi-VN')}đ/ngày)`;
    }

    // 8. Kiểm tra Cấp tiệm 1-2 nhưng sở hữu trên 500 triệu ngay trong 10 ngày đầu
    if (lvl >= 1 && lvl <= 2 && d <= 10 && m > 500000000) {
      return `Cấp tiệm thấp (Cấp ${lvl}, Ngày ${d}) nhưng tài sản đột biến: ${m.toLocaleString('vi-VN')}đ`;
    }

    return null;
  }

  async inspectAndAutoReportSuspicion(
    uid: string,
    shopName: string,
    money: number,
    day: number,
    level: number,
  ): Promise<void> {
    if (!uid || this.isCurrentUserAdmin()) return;
    const reason = this.evaluateSuspiciousStats(money, day, level);
    if (!reason) return;
    // Chỉ gửi tối đa 1 báo cáo tự động cho mỗi UID cho mỗi mốc 100M để tuyệt đối không bao giờ spam thông báo
    const dedupKey = `auto_rep_v2_${uid}_${Math.floor(money / 100000000)}`;
    if (this.autoReportedKeys.has(dedupKey)) return;
    try {
      if (localStorage.getItem(dedupKey) === '1') {
        this.autoReportedKeys.add(dedupKey);
        return;
      }
      localStorage.setItem(dedupKey, '1');
    } catch {}
    this.autoReportedKeys.add(dedupKey);

    const ts = this.getServerNow();
    const payload = JSON.stringify({
      t: 'A',
      u: uid,
      s: (shopName || 'Tiệm Trái Cây').slice(0, 32),
      rs: 'Hệ thống Anti-Cheat',
      m: Math.round(money),
      d: Math.floor(day),
      l: Math.floor(level),
      r: reason.slice(0, 90),
    });
    const hex = _encMsgHex(payload);
    const key = `SEC_REP_${ts}-${hex}`;
    await set(ref(rtdb, `refCodes/${key}`), uid).catch(() => undefined);
  }

  async submitPlayerReport(
    targetEntry: LeaderboardEntry,
    reasonRaw: string,
  ): Promise<{ ok: boolean; error?: string }> {
    if (!this.user) {
      return { ok: false, error: 'Vui lòng đăng nhập tài khoản trước khi gửi báo cáo nha!' };
    }
    if (!targetEntry || !targetEntry.uid) {
      return { ok: false, error: 'Không xác định được tài khoản cần báo cáo!' };
    }
    if (targetEntry.uid === this.user.uid) {
      return { ok: false, error: 'Bạn không thể tự báo cáo chính mình!' };
    }
    const cleanReason = (reasonRaw || '').trim().slice(0, 100);
    if (!cleanReason) {
      return { ok: false, error: 'Vui lòng chọn hoặc nhập lý do báo cáo!' };
    }
    const myShop = this.getShopSnapshot().shopName || this.user.displayName || 'Người chơi';
    const ts = this.getServerNow();
    const payload = JSON.stringify({
      t: 'U',
      u: targetEntry.uid,
      s: (targetEntry.shopName || 'Tiệm Trái Cây').slice(0, 32),
      rs: myShop.slice(0, 28),
      m: Math.round(targetEntry.money || 0),
      d: Math.floor(targetEntry.day || 1),
      l: 1,
      r: cleanReason,
    });
    const hex = _encMsgHex(payload);
    const key = `SEC_REP_${ts}-${hex}`;
    try {
      await set(ref(rtdb, `refCodes/${key}`), this.user.uid);
      return { ok: true };
    } catch {
      return { ok: false, error: 'Gửi báo cáo thất bại, vui lòng kiểm tra mạng!' };
    }
  }

  async purgeUidFromFirestoreLeaderboards(targetUid: string): Promise<boolean> {
    const cleanUid = (targetUid || '').trim();
    if (!cleanUid || !this.user) return false;

    // 1. Lọc ngay khỏi bộ nhớ tạm của cả 2 BXH
    this.leaderboard = this.leaderboard.filter((item) => item.uid !== cleanUid);
    this.daysLeaderboard = this.daysLeaderboard.filter((item) => item.uid !== cleanUid);
    this.emit();

    let anyUpdated = false;

    // 2. Xóa thông tin khỏi Document BXH chung duy nhất (/leaderboards/global)
    try {
      const lbRef = doc(db, 'leaderboards', 'global');
      const lbSnap = await getDoc(lbRef);
      if (lbSnap.exists()) {
        const rawList = this.parseLeaderboardEntriesList(lbSnap.data()?.entries);
        const filtered = rawList.filter((item) => item.uid !== cleanUid);
        if (filtered.length !== rawList.length) {
          const batch = writeBatch(db);
          batch.update(lbRef, {
            entries: filtered,
            updatedBy: this.user.uid,
            updatedAt: serverTimestamp(),
          });
          await batch.commit();
          anyUpdated = true;
        }
        this.leaderboard = filtered
          .slice()
          .sort((a, b) => b.money - a.money || a.updatedAt - b.updatedAt)
          .slice(0, 2000);
        this.daysLeaderboard = filtered
          .slice()
          .sort(
            (a, b) =>
              (b.day || 1) - (a.day || 1) ||
              b.money - a.money ||
              a.updatedAt - b.updatedAt,
          )
          .slice(0, 2000);
        const now = Date.now();
        this.lastLbFetchAt = now;
        this.lastDaysLbFetchAt = now;
      }
    } catch (err) {
      console.warn('[ttcCloud] Lỗi xóa UID khỏi BXH Global:', err);
    }

    this.emit();
    return anyUpdated;
  }

  async adminSetHideFromLeaderboard(targetUid: string, hide: boolean): Promise<boolean> {
    if (!this.user || !this.isCurrentUserAdmin()) return false;
    const cleanUid = (targetUid || '').trim();
    if (!cleanUid) return false;
    try {
      const ts = this.getServerNow();
      const key = `SEC_HIDE_${cleanUid}_${ts}-${hide ? '1' : '0'}`;
      await set(ref(rtdb, `refCodes/${key}`), this.user.uid);
      if (hide) {
        this.hiddenLbUids.add(cleanUid);
        await this.purgeUidFromFirestoreLeaderboards(cleanUid);
      } else {
        this.hiddenLbUids.delete(cleanUid);
      }
      this.emit();
      return true;
    } catch {
      return false;
    }
  }

  async adminSetBanAccount(targetUid: string, ban: boolean): Promise<boolean> {
    if (!this.user || !this.isCurrentUserAdmin()) return false;
    const cleanUid = (targetUid || '').trim();
    if (!cleanUid) return false;
    try {
      const ts = this.getServerNow();
      const key = `SEC_BAN_${cleanUid}_${ts}-${ban ? '1' : '0'}`;
      await set(ref(rtdb, `refCodes/${key}`), this.user.uid);
      if (ban) {
        this.bannedUids.add(cleanUid);
        await this.purgeUidFromFirestoreLeaderboards(cleanUid);
      } else {
        this.bannedUids.delete(cleanUid);
      }
      this.emit();
      return true;
    } catch {
      return false;
    }
  }

  async adminSetLotteryMaintenance(maint: boolean): Promise<boolean> {
    if (!this.user || !this.isCurrentUserAdmin()) return false;
    try {
      const ts = this.getServerNow();
      const key = `SEC_BAN___LOTTERY_MAINT___${ts}-${maint ? '1' : '0'}`;
      await set(ref(rtdb, `refCodes/${key}`), this.user.uid);
      this.rawSecBanMap[key] = this.user.uid;
      this.lotteryMaintenance = maint;
      this.emit();
      return true;
    } catch {
      return false;
    }
  }

  async adminSetChatMaintenance(maint: boolean): Promise<boolean> {
    if (!this.user || !this.isCurrentUserAdmin()) return false;
    try {
      const ts = this.getServerNow();
      const key = `SEC_BAN___CHAT_MAINT___${ts}-${maint ? '1' : '0'}`;
      await set(ref(rtdb, `refCodes/${key}`), this.user.uid);
      this.rawSecBanMap[key] = this.user.uid;
      this.chatMaintenance = maint;
      if (maint) {
        this.pauseChatRealtimeListeners();
      }
      this.emit();
      return true;
    } catch {
      return false;
    }
  }

  public serverMaintenance: {
    active: boolean;
    title: string;
    message: string;
    endAt: number;
    updatedAt: number;
  } = {
    active: false,
    title: 'BẢO TRÌ NÂNG CẤP MÁY CHỦ',
    message:
      'Hệ thống đang được bảo trì và nâng cấp để mang lại trải nghiệm mượt mà hơn cho các Chủ Tiệm. Dữ liệu tiệm của bạn đã được lưu an toàn! Vui lòng quay lại sau ít phút nhé.',
    endAt: 0,
    updatedAt: 0,
  };
  public adminBypassMaintenance = false;
  private rawSrvMaintMap: Record<string, any> = {};
  private srvMaintUnsub: (() => void) | null = null;

  setAdminBypassMaintenance(bypass: boolean) {
    this.adminBypassMaintenance = !!bypass;
    this.emit();
  }

  private recomputeServerMaintenanceFromRaw() {
    let bestTs = 0;
    let bestState = '0';
    let bestPayloadHex = '';
    for (const [k, v] of Object.entries(this.rawSrvMaintMap)) {
      if (!k.startsWith('SRV_MAINT_') || !v) continue;
      const rest = k.slice('SRV_MAINT_'.length);
      const firstDash = rest.indexOf('-');
      if (firstDash <= 0) continue;
      const ts = parseInt(rest.slice(0, firstDash), 10) || 0;
      if (ts <= 0) continue;
      const afterTs = rest.slice(firstDash + 1);
      const secondDash = afterTs.indexOf('-');
      const state = secondDash >= 0 ? afterTs.slice(0, secondDash) : afterTs;
      const hex = secondDash >= 0 ? afterTs.slice(secondDash + 1) : '';
      if (ts >= bestTs) {
        bestTs = ts;
        bestState = state;
        bestPayloadHex = hex;
      }
    }
    const defaultTitle = 'BẢO TRÌ NÂNG CẤP MÁY CHỦ';
    const defaultMsg =
      'Hệ thống đang được bảo trì và nâng cấp để mang lại trải nghiệm mượt mà hơn cho các Chủ Tiệm. Dữ liệu tiệm của bạn đã được lưu an toàn! Vui lòng quay lại sau ít phút nhé.';
    if (bestTs <= 0) {
      this.serverMaintenance = {
        active: false,
        title: this.serverMaintenance.title || defaultTitle,
        message: this.serverMaintenance.message || defaultMsg,
        endAt: 0,
        updatedAt: 0,
      };
      return;
    }
    let parsedTitle = defaultTitle;
    let parsedMsg = defaultMsg;
    let parsedEndAt = 0;
    if (bestPayloadHex) {
      try {
        const jsonStr = _decMsgHex(bestPayloadHex);
        const obj = JSON.parse(jsonStr);
        if (obj && typeof obj === 'object') {
          if (typeof obj.t === 'string' && obj.t.trim()) parsedTitle = obj.t.trim();
          if (typeof obj.m === 'string' && obj.m.trim()) parsedMsg = obj.m.trim();
          if (typeof obj.e === 'number' && Number.isFinite(obj.e) && obj.e > 0) {
            parsedEndAt = Math.floor(obj.e);
          }
        }
      } catch {}
    }
    const nextActive = bestState === '1';
    if (!nextActive) {
      this.adminBypassMaintenance = false;
    }
    this.serverMaintenance = {
      active: nextActive,
      title: parsedTitle,
      message: parsedMsg,
      endAt: nextActive ? parsedEndAt : 0,
      updatedAt: bestTs,
    };
  }

  startServerMaintenanceRealtime() {
    if (this.srvMaintUnsub || !rtdb) return;
    try {
      const maintQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('SRV_MAINT_'),
        endAt('SRV_MAINT_\uf8ff'),
      );
      this.srvMaintUnsub = onValue(
        maintQuery,
        (snap) => {
          this.rawSrvMaintMap =
            snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
          this.recomputeServerMaintenanceFromRaw();
          this.emit();
        },
        () => undefined,
      );
    } catch {}
  }

  async adminSetServerMaintenance(opts: {
    active: boolean;
    title?: string;
    message?: string;
    endAt?: number;
  }): Promise<boolean> {
    if (!this.user || !this.isCurrentUserAdmin()) return false;
    const defaultTitle = 'BẢO TRÌ NÂNG CẤP MÁY CHỦ';
    const defaultMsg =
      'Hệ thống đang được bảo trì và nâng cấp để mang lại trải nghiệm mượt mà hơn cho các Chủ Tiệm. Dữ liệu tiệm của bạn đã được lưu an toàn! Vui lòng quay lại sau ít phút nhé.';
    const cleanTitle =
      String(opts.title ?? this.serverMaintenance.title ?? defaultTitle)
        .trim()
        .slice(0, 100) || defaultTitle;
    const cleanMessage =
      String(opts.message ?? this.serverMaintenance.message ?? defaultMsg)
        .trim()
        .slice(0, 420) || defaultMsg;
    const cleanEndAt = opts.active ? Math.max(0, Math.floor(Number(opts.endAt) || 0)) : 0;
    const ts = this.getServerNow();
    const payloadJson = JSON.stringify({
      t: cleanTitle,
      m: cleanMessage,
      e: cleanEndAt,
    });
    const hex = _encMsgHex(payloadJson);
    const key = `SRV_MAINT_${ts}-${opts.active ? '1' : '0'}-${hex}`;
    const prevKeys = Object.keys(this.rawSrvMaintMap).filter(
      (k) => k.startsWith('SRV_MAINT_') && k !== key,
    );
    try {
      await set(ref(rtdb, `refCodes/${key}`), this.user.uid);
      this.rawSrvMaintMap[key] = this.user.uid;
      for (const oldKey of prevKeys) {
        delete this.rawSrvMaintMap[oldKey];
        set(ref(rtdb, `refCodes/${oldKey}`), null).catch(() => undefined);
      }
      if (!opts.active) {
        this.adminBypassMaintenance = false;
      }
      this.serverMaintenance = {
        active: !!opts.active,
        title: cleanTitle,
        message: cleanMessage,
        endAt: cleanEndAt,
        updatedAt: ts,
      };
      this.emit();
      return true;
    } catch {
      return false;
    }
  }

  async adminDismissSecurityReport(reportId: string): Promise<boolean> {
    if (!this.user || !this.isCurrentUserAdmin()) return false;
    const found = this.securityReports.find((r) => r.id === reportId);
    const targetUid = found?.targetUid || (reportId.startsWith('SCAN_') ? reportId.slice(5) : '');
    const isAuto = found?.type === 'AUTO_HACK' || reportId.startsWith('SCAN_');

    if (isAuto && targetUid) {
      try {
        const prev = JSON.parse(localStorage.getItem('ttc_admin_dismissed_uids_v1') || '[]');
        const next = Array.from(new Set([...(Array.isArray(prev) ? prev : []), targetUid]));
        localStorage.setItem('ttc_admin_dismissed_uids_v1', JSON.stringify(next));
      } catch {}
    }

    try {
      const delKey = `SEC_RDEL_${reportId}`;
      const delVal = isAuto && targetUid ? `UID:${targetUid}` : this.user.uid;
      this.rawSecRdelMap[delKey] = delVal;
      await set(ref(rtdb, `refCodes/${delKey}`), delVal);
      if (isAuto && targetUid) {
        const scanDelKey = `SEC_RDEL_SCAN_${targetUid}`;
        this.rawSecRdelMap[scanDelKey] = `UID:${targetUid}`;
        set(ref(rtdb, `refCodes/${scanDelKey}`), `UID:${targetUid}`).catch(() => undefined);
        this.securityReports = this.securityReports.filter(
          (r) => !(r.type === 'AUTO_HACK' && r.targetUid === targetUid),
        );
      } else {
        this.securityReports = this.securityReports.filter((r) => r.id !== reportId);
      }
      this.emit();
      return true;
    } catch {
      this.securityReports = this.securityReports.filter((r) => r.id !== reportId);
      this.emit();
      return true;
    }
  }

  async adminDismissBugReport(reportId: string): Promise<boolean> {
    if (!this.user || !reportId) return false;
    try {
      const delKey = `SEC_RDEL_${reportId}`;
      this.rawSecRdelMap[delKey] = this.user.uid;
      await set(ref(rtdb, `refCodes/${delKey}`), this.user.uid);
    } catch {}
    this.bugReports = this.bugReports.filter((b) => b.id !== reportId);
    this.emit();
    return true;
  }

  async adminClearAllBugReports(): Promise<boolean> {
    if (!this.user) return false;
    const current = [...this.bugReports];
    this.bugReports = [];
    this.emit();
    for (const item of current) {
      try {
        const delKey = `SEC_RDEL_${item.id}`;
        this.rawSecRdelMap[delKey] = this.user.uid;
        await set(ref(rtdb, `refCodes/${delKey}`), this.user.uid);
      } catch {}
    }
    return true;
  }

  private async flushPendingBugReports(uid: string): Promise<void> {
    if (!uid) return;
    try {
      const raw = localStorage.getItem('ttc_pending_bug_keys_v1');
      if (!raw) return;
      const keys = JSON.parse(raw);
      localStorage.removeItem('ttc_pending_bug_keys_v1');
      if (!Array.isArray(keys) || keys.length === 0) return;
      for (const k of keys.slice(0, 3)) {
        if (typeof k === 'string' && k.startsWith('SEC_REP_')) {
          await set(ref(rtdb, `refCodes/${k}`), uid).catch(() => undefined);
        }
      }
    } catch {}
  }

  private isIgnorableClientError(msg: string, stack = ''): boolean {
    const lower = `${msg || ''} ${stack || ''}`.toLowerCase();
    if (!lower.trim()) return true;
    const harmlessPatterns = [
      'resizeobserver',
      'script error',
      'networkerror',
      'failed to fetch',
      'load failed',
      'network request failed',
      'internet connection appears to be offline',
      'quotaexceeded',
      'storage quota',
      'extension',
      'non-error promise rejection',
      'database deleted by request of the user',
      'pending promise was never set',
      'internal assertion failed',
      'connection is closing',
      'indexeddb',
      'idbdatabase',
      'backing store',
      'webkit.messagehandlers',
      'zalo',
      'fb_iab',
      'bytetelemetry',
      'ttwebview',
      'popup-closed-by-user',
      'cancelled-popup-request',
      'auth/popup-blocked',
      'auth/network-request-failed',
      'auth/user-cancelled',
      'auth/web-storage-unsupported',
      'the operation was aborted',
      'the user aborted a request',
      'aborterror',
      'notallowederror',
      'play() request was interrupted',
      'play() failed',
      'user didn\'t interact',
      'fullscreen',
      'orientation.lock',
      'loading chunk',
      'dynamically imported module',
    ];
    return harmlessPatterns.some((p) => lower.includes(p));
  }

  async reportClientGameError(
    err: unknown,
    source = 'runtime',
    extraContext?: {
      phase?: string;
      shopName?: string;
      day?: number;
      level?: number;
      money?: number;
    },
  ): Promise<void> {
    try {
      if (err && typeof err === 'object') {
        const errName = String((err as any).name || '').toLowerCase();
        if (
          errName === 'aborterror' ||
          errName === 'notallowederror' ||
          errName === 'quotaexceedederror' ||
          errName === 'unknownerror' ||
          errName === 'securityerror'
        ) {
          return;
        }
      }
      const rawMsg =
        err instanceof Error
          ? err.message || String(err)
          : typeof err === 'string'
            ? err
            : JSON.stringify(err || 'Unknown error');
      const cleanMsg = String(rawMsg || 'Unknown error')
        .replace(/\s+/g, ' ')
        .trim();
      if (!cleanMsg || cleanMsg === '{}' || cleanMsg === 'null' || cleanMsg === 'undefined') return;

      const rawStack = err instanceof Error && typeof err.stack === 'string' ? err.stack : '';
      if (this.isIgnorableClientError(cleanMsg, rawStack)) {
        return;
      }

      let compactStack = '';
      if (rawStack) {
        const lines = rawStack
          .split('\n')
          .map((l) => l.trim())
          .filter((l) => l.startsWith('at '));
        compactStack = (lines[0] || '')
          .replace(/^at\s+/, '')
          .replace(/https?:\/\/[^/]+\//g, '')
          .slice(0, 48);
      }

      const hash = _fnv32(`${source}:${cleanMsg.slice(0, 80)}:${compactStack.slice(0, 24)}`).toString(36);
      if (this.reportedBugHashes.has(hash)) return;

      const now = Date.now();
      if (now - this.lastBugReportSentAt < 15000) return;
      if (this.bugReportSessionCount >= 3) return;

      try {
        const sessionHashes = JSON.parse(sessionStorage.getItem('ttc_bug_hashes_v1') || '[]');
        if (Array.isArray(sessionHashes) && sessionHashes.includes(hash)) {
          this.reportedBugHashes.add(hash);
          return;
        }
        const nextHashes = Array.isArray(sessionHashes) ? [...sessionHashes.slice(-15), hash] : [hash];
        sessionStorage.setItem('ttc_bug_hashes_v1', JSON.stringify(nextHashes));
      } catch {}

      try {
        const dayBucket = new Date(now).toISOString().slice(0, 10);
        const quotaRaw = JSON.parse(localStorage.getItem('ttc_bug_quota_v1') || '{}');
        const usedToday = quotaRaw && quotaRaw.d === dayBucket ? Number(quotaRaw.c) || 0 : 0;
        if (usedToday >= 5) return;
        localStorage.setItem('ttc_bug_quota_v1', JSON.stringify({ d: dayBucket, c: usedToday + 1 }));
      } catch {}

      this.reportedBugHashes.add(hash);
      this.lastBugReportSentAt = now;
      this.bugReportSessionCount += 1;

      let localExp: LocalExportData | null = null;
      try {
        localExp = this.bridge?.getLocalExport?.() || null;
      } catch {}

      const uid = (this.user?.uid || 'GUEST').slice(0, 28);
      const shopName = String(
        extraContext?.shopName ||
          localExp?.summary?.shopName ||
          this.user?.displayName ||
          'Khách',
      )
        .replace(/["\\]/g, '')
        .trim()
        .slice(0, 16);
      const day = Math.max(1, Math.floor(Number(extraContext?.day ?? localExp?.summary?.day ?? 1) || 1));
      const level = Math.max(1, Math.floor(Number(extraContext?.level ?? localExp?.summary?.level ?? 1) || 1));
      const money = Math.floor(Number(extraContext?.money ?? localExp?.summary?.money ?? 0) || 0);
      const phase = String(extraContext?.phase || 'game').slice(0, 10);
      const ua = typeof navigator !== 'undefined' ? navigator.userAgent || '' : '';
      const isMob = /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
      const osTag = /Android/i.test(ua)
        ? 'Android'
        : /iPhone|iPad|iPod/i.test(ua)
          ? 'iOS'
          : /Win/i.test(ua)
            ? 'Win'
            : /Mac/i.test(ua)
              ? 'Mac'
              : 'Web';
      const vw = typeof window !== 'undefined' ? window.innerWidth || 0 : 0;
      const vh = typeof window !== 'undefined' ? window.innerHeight || 0 : 0;
      const device = `${osTag}${isMob ? '-M' : '-PC'} ${vw}x${vh}`.slice(0, 20);

      let msgLimit = 85;
      let payloadStr = '';
      while (msgLimit >= 25) {
        const payloadObj = {
          t: 'B',
          h: hash.slice(0, 8),
          u: uid,
          s: shopName || 'Khách',
          d: day,
          l: level,
          m: money,
          p: phase,
          src: String(source || 'ui').slice(0, 8),
          dv: device,
          e: cleanMsg.replace(/["\\]/g, "'").slice(0, msgLimit),
          st: compactStack.replace(/["\\]/g, "'").slice(0, 36),
        };
        payloadStr = JSON.stringify(payloadObj);
        if (payloadStr.length <= 300) break;
        msgLimit -= 15;
      }

      const key = `SEC_REP_${now}-${_encMsgHex(payloadStr)}`;
      try {
        await set(ref(rtdb, `refCodes/${key}`), this.user?.uid || 'GUEST');
      } catch {
        try {
          const prev = JSON.parse(localStorage.getItem('ttc_pending_bug_keys_v1') || '[]');
          const next = Array.isArray(prev) ? [...prev.slice(-2), key] : [key];
          localStorage.setItem('ttc_pending_bug_keys_v1', JSON.stringify(next));
        } catch {}
      }
    } catch {}
  }

  public serverNotices: ServerNoticeItem[] = [];
  public adminAllNotices: ServerNoticeItem[] = [];
  public lixiBag: LixiBagItem[] = [];
  public activeLixiOpening: ActiveLixiOpening | null = null;
  private _lixiOpSeq = 0;
  private rawNtAllMap: Record<string, any> = {};
  private rawNtUidMap: Record<string, any> = {};
  private rawNtDelMap: Record<string, any> = {};
  private deletedNoticeIds = new Set<string>();
  private readNoticeIds = new Set<string>();
  private claimedNoticeIds = new Set<string>();
  private claimedNoticeTimestamps = new Set<number>();
  private toastedNoticeIds = new Set<string>();
  private lixiNoticeActionMap: Record<string, 'opened' | 'stored'> = {};
  private openedLixiIds = new Set<string>();

  private sanitizeLixiBag(raw: unknown): LixiBagItem[] {
    if (!Array.isArray(raw)) return [];
    const seen = new Set<string>();
    const out: LixiBagItem[] = [];
    for (const item of raw) {
      if (!item || typeof item !== 'object') continue;
      const obj = item as Record<string, any>;
      const id = typeof obj.id === 'string' ? obj.id.trim() : '';
      const amount = Math.max(0, Math.floor(Number(obj.amount) || 0));
      if (!id || amount <= 0 || seen.has(id) || this.openedLixiIds.has(id)) continue;
      seen.add(id);
      const style: LixiStyle =
        obj.style === 'gold' || obj.style === 'jade' ? obj.style : 'red';
      out.push({
        id,
        amount,
        style,
        senderName: String(obj.senderName || 'Ban Quản Trị').slice(0, 40),
        message: String(obj.message || '').slice(0, 180),
        receivedAt: Math.max(0, Math.floor(Number(obj.receivedAt) || Date.now())),
        createdAt: Math.max(0, Math.floor(Number(obj.createdAt) || Date.now())),
      });
    }
    return out.slice(0, 100);
  }

  clearActiveLixiOpening(): void {
    if (!this.activeLixiOpening) return;
    this.activeLixiOpening = null;
    this.emit();
  }

  private loadLocalNoticeMeta(uid: string) {
    try {
      const delRaw = JSON.parse(localStorage.getItem(`ttc_nt_del_${uid}`) || '[]');
      const readRaw = JSON.parse(localStorage.getItem(`ttc_nt_read_${uid}`) || '[]');
      const claimRaw = JSON.parse(localStorage.getItem(`ttc_nt_claim_${uid}`) || '[]');
      const toastRaw = JSON.parse(localStorage.getItem(`ttc_nt_toast_${uid}`) || '[]');
      const lixiOpenRaw = JSON.parse(localStorage.getItem(`ttc_lixi_open_${uid}`) || '[]');
      const lixiActRaw = JSON.parse(localStorage.getItem(`ttc_lixi_act_${uid}`) || '{}');
      const lixiBagRaw = JSON.parse(localStorage.getItem(`ttc_lixi_bag_${uid}`) || '[]');
      for (const id of Array.isArray(delRaw) ? delRaw : []) this.deletedNoticeIds.add(id);
      for (const id of Array.isArray(readRaw) ? readRaw : []) this.readNoticeIds.add(id);
      for (const id of Array.isArray(claimRaw) ? claimRaw : []) this.claimedNoticeIds.add(id);
      for (const id of Array.isArray(toastRaw) ? toastRaw : []) this.toastedNoticeIds.add(id);
      for (const id of Array.isArray(lixiOpenRaw) ? lixiOpenRaw : []) {
        if (typeof id === 'string' && id) this.openedLixiIds.add(id);
      }
      if (lixiActRaw && typeof lixiActRaw === 'object') {
        for (const [k, v] of Object.entries(lixiActRaw)) {
          if (v === 'opened' || v === 'stored') {
            this.lixiNoticeActionMap[k] = this.openedLixiIds.has(k) ? 'opened' : v;
          }
        }
      }
      const shopBag = this.sanitizeLixiBag(this.bridge?.getShopInfo?.()?.lixiBag);
      const localBag = this.sanitizeLixiBag(lixiBagRaw);
      const memBag = this.sanitizeLixiBag(this.lixiBag);
      const merged = new Map<string, LixiBagItem>();
      for (const it of [...localBag, ...shopBag, ...memBag]) {
        if (!this.openedLixiIds.has(it.id) && !merged.has(it.id)) merged.set(it.id, it);
      }
      this.lixiBag = Array.from(merged.values())
        .sort((a, b) => b.receivedAt - a.receivedAt)
        .slice(0, 100);
    } catch {}
  }

  private pruneDeadNoticeIds() {
    if (!this.hasLoadedServerNoticesOnce) return;
    const isAliveOnServer = (id: string) =>
      (Object.prototype.hasOwnProperty.call(this.rawNtAllMap, id) ||
        Object.prototype.hasOwnProperty.call(this.rawNtUidMap, id)) &&
      !this.isNoticeRevokedOnServer(id);

    for (const id of Array.from(this.deletedNoticeIds)) {
      if (!isAliveOnServer(id)) {
        this.deletedNoticeIds.delete(id);
      }
    }
    for (const id of Array.from(this.readNoticeIds)) {
      if (!isAliveOnServer(id) && !this.claimedNoticeIds.has(id)) {
        this.readNoticeIds.delete(id);
      }
    }
    for (const id of Array.from(this.toastedNoticeIds)) {
      if (!isAliveOnServer(id)) {
        this.toastedNoticeIds.delete(id);
      }
    }
  }

  private saveLocalNoticeMeta(uid: string, syncToCloud = false) {
    this.pruneDeadNoticeIds();
    const delArr = Array.from(this.deletedNoticeIds).slice(-200);
    const readArr = Array.from(this.readNoticeIds).slice(-200);
    const claimArr = Array.from(this.claimedNoticeIds).slice(-200);
    const toastArr = Array.from(this.toastedNoticeIds).slice(-200);
    const lixiOpenArr = Array.from(this.openedLixiIds).slice(-200);
    const cleanBag = this.sanitizeLixiBag(this.lixiBag);
    this.lixiBag = cleanBag;
    const actEntries = Object.entries(this.lixiNoticeActionMap).slice(-200);
    const cleanActMap: Record<string, 'opened' | 'stored'> = {};
    for (const [k, v] of actEntries) cleanActMap[k] = v;
    try {
      localStorage.setItem(`ttc_nt_del_${uid}`, JSON.stringify(delArr));
      localStorage.setItem(`ttc_nt_read_${uid}`, JSON.stringify(readArr));
      localStorage.setItem(`ttc_nt_claim_${uid}`, JSON.stringify(claimArr));
      localStorage.setItem(`ttc_nt_toast_${uid}`, JSON.stringify(toastArr));
      localStorage.setItem(`ttc_lixi_open_${uid}`, JSON.stringify(lixiOpenArr));
      localStorage.setItem(`ttc_lixi_act_${uid}`, JSON.stringify(cleanActMap));
      localStorage.setItem(`ttc_lixi_bag_${uid}`, JSON.stringify(cleanBag));
    } catch {}
    if (syncToCloud && uid) {
      update(ref(rtdb, `referrals/${uid}`), {
        ntDeleted: delArr,
        ntRead: readArr,
        ntClaimed: claimArr,
        lixiOpened: lixiOpenArr,
        ntLixiAct: cleanActMap,
        lixiBag: cleanBag,
      }).catch(() => undefined);
    }
  }

  private parseSingleNoticeKey(fullKey: string, senderUid: string): ServerNoticeItem | null {
    const parsePayload = (
      rawPayload: string,
    ): {
      senderName: string;
      text: string;
      isLixi: boolean;
      lixiStyle: LixiStyle;
    } => {
      if (rawPayload.startsWith('LIXI_') && rawPayload.includes('~')) {
        const [tag, sHex, ...mRest] = rawPayload.split('~');
        const stRaw = tag.slice(5);
        const lixiStyle: LixiStyle =
          stRaw === 'gold' || stRaw === 'jade' ? stRaw : 'red';
        return {
          senderName: _decMsgHex(sHex || '') || 'Ban Quản Trị',
          text: _decMsgHex(mRest.join('~')) || 'Chúc Chủ Tiệm buôn may bán đắt!',
          isLixi: true,
          lixiStyle,
        };
      }
      if (rawPayload.includes('~')) {
        const [sHex, ...mRest] = rawPayload.split('~');
        return {
          senderName: _decMsgHex(sHex) || 'Ban Quản Trị',
          text: _decMsgHex(mRest.join('~')),
          isLixi: false,
          lixiStyle: 'red',
        };
      }
      return {
        senderName: 'Ban Quản Trị',
        text: _decMsgHex(rawPayload),
        isLixi: false,
        lixiStyle: 'red',
      };
    };

    const resolveLixiAction = (isClaimed: boolean): 'opened' | 'stored' | null => {
      if (this.openedLixiIds.has(fullKey)) return 'opened';
      const act = this.lixiNoticeActionMap[fullKey];
      if (act === 'opened' || act === 'stored') return act;
      return isClaimed ? 'opened' : null;
    };

    if (fullKey.startsWith('NT_ALL_')) {
      const tail = fullKey.slice(7);
      const parts = tail.split('-');
      const ts = parseInt(parts[0] || '0', 10) || 0;
      const reward = Math.max(0, parseInt(parts[1] || '0', 10) || 0);
      const { senderName, text, isLixi, lixiStyle } = parsePayload(parts.slice(2).join('-'));
      if (!ts || !text) return null;
      const isClaimed =
        this.claimedNoticeIds.has(fullKey) ||
        this.claimedNoticeTimestamps.has(ts) ||
        this.openedLixiIds.has(fullKey) ||
        !!this.lixiNoticeActionMap[fullKey];
      return {
        id: fullKey,
        scope: 'ALL',
        targetUid: 'ALL',
        createdAt: ts,
        reward,
        senderName,
        text,
        senderUid,
        read: this.readNoticeIds.has(fullKey) || isClaimed,
        claimed: isClaimed,
        isLixi,
        lixiStyle,
        lixiAction: isLixi ? resolveLixiAction(isClaimed) : null,
      };
    }
    if (fullKey.startsWith('NT_U_')) {
      const rest = fullKey.slice(5);
      const splitMatch = rest.match(/^(.+)_(\d+-\d+-.+)$/);
      if (!splitMatch) return null;
      const targetUid = splitMatch[1];
      const tail = splitMatch[2];
      const parts = tail.split('-');
      const ts = parseInt(parts[0] || '0', 10) || 0;
      const reward = Math.max(0, parseInt(parts[1] || '0', 10) || 0);
      const { senderName, text, isLixi, lixiStyle } = parsePayload(parts.slice(2).join('-'));
      if (!ts || !text) return null;
      const isClaimed =
        this.claimedNoticeIds.has(fullKey) ||
        this.claimedNoticeTimestamps.has(ts) ||
        this.openedLixiIds.has(fullKey) ||
        !!this.lixiNoticeActionMap[fullKey];
      return {
        id: fullKey,
        scope: 'UID',
        targetUid,
        createdAt: ts,
        reward,
        senderName,
        text,
        senderUid,
        read: this.readNoticeIds.has(fullKey) || isClaimed,
        claimed: isClaimed,
        isLixi,
        lixiStyle,
        lixiAction: isLixi ? resolveLixiAction(isClaimed) : null,
      };
    }
    return null;
  }

  private isNoticeRevokedOnServer(noticeId: string): boolean {
    return !!this.rawNtDelMap[`NT_DEL_${noticeId}`];
  }

  private recomputeServerNotices(uid: string) {
    if (!uid || this.user?.uid !== uid) return;
    const list: ServerNoticeItem[] = [];

    for (const [k, v] of Object.entries(this.rawNtAllMap)) {
      if (this.deletedNoticeIds.has(k) || this.isNoticeRevokedOnServer(k)) continue;
      const parsed = this.parseSingleNoticeKey(k, String(v || ''));
      if (parsed) list.push(parsed);
    }
    for (const [k, v] of Object.entries(this.rawNtUidMap)) {
      if (this.deletedNoticeIds.has(k) || this.isNoticeRevokedOnServer(k)) continue;
      const parsed = this.parseSingleNoticeKey(k, String(v || ''));
      if (parsed) list.push(parsed);
    }

    list.sort((a, b) => b.createdAt - a.createdAt);
    this.serverNotices = list;

    // Chỉ phát âm thanh & hiện thông báo đúng 1 lần duy nhất cho thư/bao lì xì chưa từng báo
    let hasBrandNewUnread = false;
    let hasBrandNewLixi = false;
    for (const item of list) {
      if (!item.read && !item.claimed && !this.toastedNoticeIds.has(item.id)) {
        this.toastedNoticeIds.add(item.id);
        hasBrandNewUnread = true;
        if (item.isLixi) hasBrandNewLixi = true;
      }
    }
    if (hasBrandNewUnread) {
      this.saveLocalNoticeMeta(uid, false);
      this.bridge?.playSound?.('ting');
      this.bridge?.notify(
        hasBrandNewLixi
          ? 'Bạn vừa nhận được Bao Lì Xì mới trong Hộp thư!'
          : 'Bạn có thư mới trong Hộp thư thông báo!',
        hasBrandNewLixi ? 'good' : 'info',
      );
    }
  }

  getUnreadNoticeCount(): number {
    return this.serverNotices.filter((n) => !n.read).length;
  }

  markAllNoticesRead(): void {
    if (!this.user) return;
    let changed = false;
    for (const item of this.serverNotices) {
      if (!this.readNoticeIds.has(item.id)) {
        this.readNoticeIds.add(item.id);
        this.toastedNoticeIds.add(item.id);
        item.read = true;
        changed = true;
      }
    }
    if (changed) {
      this.saveLocalNoticeMeta(this.user.uid, true);
      this.emit();
    }
  }

  async claimNoticeReward(noticeId: string): Promise<boolean> {
    if (!this.user) return false;
    const uid = this.user.uid;
    const item = this.serverNotices.find((n) => n.id === noticeId);
    if (
      !item ||
      item.isLixi ||
      item.reward <= 0 ||
      item.claimed ||
      this.claimedNoticeIds.has(noticeId) ||
      this.claimedNoticeTimestamps.has(item.createdAt)
    ) {
      return false;
    }

    if (this.bridge?.hasActiveShop && !this.bridge.hasActiveShop()) {
      this.bridge?.notify('Vui lòng vào tiệm trước khi nhận quà đính kèm nha!', 'bad');
      return false;
    }

    // Kiểm tra trực tiếp trên Server (chỉ đọc đúng ngăn kéo con của thư thay vì tải cả referrals/{uid})
    try {
      const [claimedSnap, tsClaimSnap] = await Promise.all([
        get(ref(rtdb, `referrals/${uid}/ntClaimed`)).catch(() => null),
        get(ref(rtdb, `referrals/${uid}/ntClaim_${item.createdAt}`)).catch(() => null),
      ]);
      const cloudClaimed: string[] =
        claimedSnap?.exists() && Array.isArray(claimedSnap.val()) ? claimedSnap.val() : [];
      if (cloudClaimed.includes(noticeId) || tsClaimSnap?.exists()) {
        this.claimedNoticeIds.add(noticeId);
        this.claimedNoticeTimestamps.add(item.createdAt);
        this.readNoticeIds.add(noticeId);
        item.claimed = true;
        item.read = true;
        this.saveLocalNoticeMeta(uid, false);
        this.bridge?.notify('Tài khoản của bạn đã nhận quà từ thư này trên thiết bị khác rồi!', 'bad');
        this.emit();
        return false;
      }
    } catch {}

    this.claimedNoticeIds.add(noticeId);
    this.claimedNoticeTimestamps.add(item.createdAt);
    this.readNoticeIds.add(noticeId);
    this.toastedNoticeIds.add(noticeId);
    item.claimed = true;
    item.read = true;
    this.saveLocalNoticeMeta(uid, true);

    await update(ref(rtdb, `referrals/${uid}`), {
      [`ntClaim_${item.createdAt}`]: Date.now(),
      ntClaimed: Array.from(this.claimedNoticeIds).slice(-200),
      ntRead: Array.from(this.readNoticeIds).slice(-200),
    }).catch(() => undefined);

    this.bridge?.grantReferralMoney?.(item.reward);
    this.bridge?.playSound?.('cash');
    this.bridge?.notify(
      `Đã nhận +${item.reward.toLocaleString('vi-VN')}đ từ Hộp thư thông báo!`,
      'good',
    );
    this.emit();
    return true;
  }

  async openLixiFromNotice(noticeId: string): Promise<boolean> {
    if (!this.user) return false;
    const uid = this.user.uid;
    const item = this.serverNotices.find((n) => n.id === noticeId);
    if (
      !item ||
      !item.isLixi ||
      item.reward <= 0 ||
      item.claimed ||
      this.claimedNoticeIds.has(noticeId) ||
      this.claimedNoticeTimestamps.has(item.createdAt) ||
      this.openedLixiIds.has(noticeId) ||
      !!this.lixiNoticeActionMap[noticeId]
    ) {
      return false;
    }

    if (this.bridge?.hasActiveShop && !this.bridge.hasActiveShop()) {
      this.bridge?.notify('Vui lòng vào tiệm trước khi mở Bao Lì Xì nha!', 'bad');
      return false;
    }

    try {
      const [claimedSnap, openedSnap, actSnap, tsClaimSnap] = await Promise.all([
        get(ref(rtdb, `referrals/${uid}/ntClaimed`)).catch(() => null),
        get(ref(rtdb, `referrals/${uid}/lixiOpened`)).catch(() => null),
        get(ref(rtdb, `referrals/${uid}/ntLixiAct/${noticeId}`)).catch(() => null),
        get(ref(rtdb, `referrals/${uid}/ntClaim_${item.createdAt}`)).catch(() => null),
      ]);
      const cloudClaimed: string[] =
        claimedSnap?.exists() && Array.isArray(claimedSnap.val()) ? claimedSnap.val() : [];
      const cloudOpened: string[] =
        openedSnap?.exists() && Array.isArray(openedSnap.val()) ? openedSnap.val() : [];
      const cloudAct = actSnap?.exists() ? actSnap.val() : undefined;
      if (
        cloudClaimed.includes(noticeId) ||
        cloudOpened.includes(noticeId) ||
        !!cloudAct ||
        tsClaimSnap?.exists()
      ) {
        this.claimedNoticeIds.add(noticeId);
        this.claimedNoticeTimestamps.add(item.createdAt);
        this.readNoticeIds.add(noticeId);
        if (cloudOpened.includes(noticeId) || cloudAct === 'opened') {
          this.openedLixiIds.add(noticeId);
          this.lixiNoticeActionMap[noticeId] = 'opened';
        } else if (cloudAct === 'stored') {
          this.lixiNoticeActionMap[noticeId] = 'stored';
        }
        item.claimed = true;
        item.read = true;
        item.lixiAction = this.lixiNoticeActionMap[noticeId] || 'opened';
        this.saveLocalNoticeMeta(uid, false);
        this.bridge?.notify('Bao Lì Xì này đã được nhận trên thiết bị khác rồi!', 'bad');
        this.emit();
        return false;
      }
    } catch {}

    this.claimedNoticeIds.add(noticeId);
    this.claimedNoticeTimestamps.add(item.createdAt);
    this.openedLixiIds.add(noticeId);
    this.readNoticeIds.add(noticeId);
    this.toastedNoticeIds.add(noticeId);
    this.lixiNoticeActionMap[noticeId] = 'opened';
    item.claimed = true;
    item.read = true;
    item.lixiAction = 'opened';
    this.saveLocalNoticeMeta(uid, true);

    await update(ref(rtdb, `referrals/${uid}`), {
      [`ntClaim_${item.createdAt}`]: Date.now(),
      ntClaimed: Array.from(this.claimedNoticeIds).slice(-200),
      ntRead: Array.from(this.readNoticeIds).slice(-200),
      lixiOpened: Array.from(this.openedLixiIds).slice(-200),
      ntLixiAct: this.lixiNoticeActionMap,
    }).catch(() => undefined);

    this.bridge?.grantReferralMoney?.(item.reward);
    this.activeLixiOpening = {
      key: ++this._lixiOpSeq,
      amount: item.reward,
      count: 1,
      style: item.lixiStyle || 'red',
      senderName: item.senderName || 'Ban Quản Trị',
      message: item.text || 'Chúc Chủ Tiệm buôn may bán đắt!',
    };
    this.bridge?.playSound?.('ting');
    this.emit();
    return true;
  }

  async storeLixiFromNotice(noticeId: string): Promise<boolean> {
    if (!this.user) return false;
    const uid = this.user.uid;
    const item = this.serverNotices.find((n) => n.id === noticeId);
    if (
      !item ||
      !item.isLixi ||
      item.reward <= 0 ||
      item.claimed ||
      this.claimedNoticeIds.has(noticeId) ||
      this.claimedNoticeTimestamps.has(item.createdAt) ||
      this.openedLixiIds.has(noticeId) ||
      !!this.lixiNoticeActionMap[noticeId]
    ) {
      return false;
    }

    if (this.bridge?.hasActiveShop && !this.bridge.hasActiveShop()) {
      this.bridge?.notify('Vui lòng vào tiệm trước khi cất Bao Lì Xì vào kho nha!', 'bad');
      return false;
    }

    try {
      const [claimedSnap, openedSnap, actSnap, tsClaimSnap] = await Promise.all([
        get(ref(rtdb, `referrals/${uid}/ntClaimed`)).catch(() => null),
        get(ref(rtdb, `referrals/${uid}/lixiOpened`)).catch(() => null),
        get(ref(rtdb, `referrals/${uid}/ntLixiAct/${noticeId}`)).catch(() => null),
        get(ref(rtdb, `referrals/${uid}/ntClaim_${item.createdAt}`)).catch(() => null),
      ]);
      const cloudClaimed: string[] =
        claimedSnap?.exists() && Array.isArray(claimedSnap.val()) ? claimedSnap.val() : [];
      const cloudOpened: string[] =
        openedSnap?.exists() && Array.isArray(openedSnap.val()) ? openedSnap.val() : [];
      const cloudAct = actSnap?.exists() ? actSnap.val() : undefined;
      if (
        cloudClaimed.includes(noticeId) ||
        cloudOpened.includes(noticeId) ||
        !!cloudAct ||
        tsClaimSnap?.exists()
      ) {
        this.claimedNoticeIds.add(noticeId);
        this.claimedNoticeTimestamps.add(item.createdAt);
        this.readNoticeIds.add(noticeId);
        if (cloudOpened.includes(noticeId) || cloudAct === 'opened') {
          this.openedLixiIds.add(noticeId);
          this.lixiNoticeActionMap[noticeId] = 'opened';
        } else if (cloudAct === 'stored') {
          this.lixiNoticeActionMap[noticeId] = 'stored';
        }
        item.claimed = true;
        item.read = true;
        item.lixiAction = this.lixiNoticeActionMap[noticeId] || 'stored';
        this.saveLocalNoticeMeta(uid, false);
        this.bridge?.notify('Bao Lì Xì này đã được xử lý trên thiết bị khác rồi!', 'bad');
        this.emit();
        return false;
      }
    } catch {}

    const bagItem: LixiBagItem = {
      id: noticeId,
      amount: item.reward,
      style: item.lixiStyle || 'red',
      senderName: item.senderName || 'Ban Quản Trị',
      message: item.text || 'Chúc Chủ Tiệm buôn may bán đắt!',
      receivedAt: this.getServerNow(),
      createdAt: item.createdAt,
    };

    const nextBag = [bagItem, ...this.lixiBag.filter((x) => x.id !== noticeId)].slice(0, 100);
    this.lixiBag = nextBag;
    this.claimedNoticeIds.add(noticeId);
    this.claimedNoticeTimestamps.add(item.createdAt);
    this.readNoticeIds.add(noticeId);
    this.toastedNoticeIds.add(noticeId);
    this.lixiNoticeActionMap[noticeId] = 'stored';
    item.claimed = true;
    item.read = true;
    item.lixiAction = 'stored';

    this.bridge?.syncLixiBag?.(nextBag);
    this.saveLocalNoticeMeta(uid, true);

    await update(ref(rtdb, `referrals/${uid}`), {
      [`ntClaim_${item.createdAt}`]: Date.now(),
      ntClaimed: Array.from(this.claimedNoticeIds).slice(-200),
      ntRead: Array.from(this.readNoticeIds).slice(-200),
      ntLixiAct: this.lixiNoticeActionMap,
      lixiBag: nextBag,
    }).catch(() => undefined);

    this.bridge?.playSound?.('tap');
    this.bridge?.notify('Đã cất Bao Lì Xì vào Kho hàng của tiệm! 🧧', 'good');
    this.emit();
    return true;
  }

  async openStoredLixi(lixiId: string): Promise<boolean> {
    if (!this.user) {
      this.bridge?.notify('Vui lòng đăng nhập tài khoản trước khi mở Bao Lì Xì nha!', 'bad');
      return false;
    }
    if (this.bridge?.hasActiveShop && !this.bridge.hasActiveShop()) {
      this.bridge?.notify('Vui lòng vào tiệm trước khi mở Bao Lì Xì nha!', 'bad');
      return false;
    }
    const uid = this.user.uid;
    const target = this.lixiBag.find((x) => x.id === lixiId);
    if (!target || target.amount <= 0) return false;

    try {
      const openedSnap = await get(ref(rtdb, `referrals/${uid}/lixiOpened`)).catch(() => null);
      if (openedSnap && openedSnap.exists()) {
        const cloudOpened: string[] = Array.isArray(openedSnap.val()) ? openedSnap.val() : [];
        if (cloudOpened.includes(lixiId)) {
          this.openedLixiIds.add(lixiId);
          this.lixiNoticeActionMap[lixiId] = 'opened';
          const cleaned = this.lixiBag.filter((x) => x.id !== lixiId);
          this.lixiBag = cleaned;
          this.bridge?.syncLixiBag?.(cleaned);
          const nItem = this.serverNotices.find((n) => n.id === lixiId);
          if (nItem) nItem.lixiAction = 'opened';
          this.saveLocalNoticeMeta(uid, false);
          this.bridge?.notify('Bao Lì Xì này đã được mở trên thiết bị khác rồi!', 'bad');
          this.emit();
          return false;
        }
      }
    } catch {}

    const nextBag = this.lixiBag.filter((x) => x.id !== lixiId);
    this.lixiBag = nextBag;
    this.openedLixiIds.add(lixiId);
    this.lixiNoticeActionMap[lixiId] = 'opened';
    const nItem = this.serverNotices.find((n) => n.id === lixiId);
    if (nItem) {
      nItem.lixiAction = 'opened';
      nItem.claimed = true;
      nItem.read = true;
    }

    this.bridge?.syncLixiBag?.(nextBag);
    this.saveLocalNoticeMeta(uid, true);

    await update(ref(rtdb, `referrals/${uid}`), {
      lixiBag: nextBag,
      lixiOpened: Array.from(this.openedLixiIds).slice(-200),
      ntLixiAct: this.lixiNoticeActionMap,
    }).catch(() => undefined);

    this.bridge?.grantReferralMoney?.(target.amount);
    this.activeLixiOpening = {
      key: ++this._lixiOpSeq,
      amount: target.amount,
      count: 1,
      style: target.style || 'red',
      senderName: target.senderName || 'Ban Quản Trị',
      message: target.message || 'Chúc Chủ Tiệm buôn may bán đắt!',
    };
    this.bridge?.playSound?.('ting');
    this.emit();
    return true;
  }

  async openAllStoredLixi(): Promise<boolean> {
    if (!this.user) {
      this.bridge?.notify('Vui lòng đăng nhập tài khoản trước khi mở Bao Lì Xì nha!', 'bad');
      return false;
    }
    if (this.lixiBag.length === 0) return false;
    if (this.lixiBag.length === 1) {
      return this.openStoredLixi(this.lixiBag[0].id);
    }
    if (this.bridge?.hasActiveShop && !this.bridge.hasActiveShop()) {
      this.bridge?.notify('Vui lòng vào tiệm trước khi mở Bao Lì Xì nha!', 'bad');
      return false;
    }

    const uid = this.user.uid;
    let serverOpened = new Set<string>(this.openedLixiIds);
    try {
      const openedSnap = await get(ref(rtdb, `referrals/${uid}/lixiOpened`)).catch(() => null);
      if (openedSnap && openedSnap.exists()) {
        const cloudOpened: string[] = Array.isArray(openedSnap.val()) ? openedSnap.val() : [];
        for (const id of cloudOpened) serverOpened.add(id);
      }
    } catch {}

    const validItems = this.lixiBag.filter((x) => !serverOpened.has(x.id) && x.amount > 0);
    for (const item of this.lixiBag) {
      this.openedLixiIds.add(item.id);
      this.lixiNoticeActionMap[item.id] = 'opened';
      const nItem = this.serverNotices.find((n) => n.id === item.id);
      if (nItem) {
        nItem.lixiAction = 'opened';
        nItem.claimed = true;
        nItem.read = true;
      }
    }

    this.lixiBag = [];
    this.bridge?.syncLixiBag?.([]);
    this.saveLocalNoticeMeta(uid, true);

    await update(ref(rtdb, `referrals/${uid}`), {
      lixiBag: [],
      lixiOpened: Array.from(this.openedLixiIds).slice(-200),
      ntLixiAct: this.lixiNoticeActionMap,
    }).catch(() => undefined);

    if (validItems.length === 0) {
      this.bridge?.notify('Các Bao Lì Xì này đã được mở trên thiết bị khác rồi!', 'bad');
      this.emit();
      return false;
    }

    const totalAmount = validItems.reduce((sum, x) => sum + x.amount, 0);
    const first = validItems[0];
    this.bridge?.grantReferralMoney?.(totalAmount);
    this.activeLixiOpening = {
      key: ++this._lixiOpSeq,
      amount: totalAmount,
      count: validItems.length,
      style: first.style || 'red',
      senderName: first.senderName || 'Ban Quản Trị',
      message:
        validItems.length > 1
          ? first.message || 'Phát tài phát lộc, buôn may bán đắt!'
          : first.message,
    };
    this.bridge?.playSound?.('ting');
    this.emit();
    return true;
  }

  async deletePlayerNotice(noticeId: string): Promise<void> {
    if (!this.user) return;
    const uid = this.user.uid;
    this.deletedNoticeIds.add(noticeId);
    this.readNoticeIds.add(noticeId);
    this.toastedNoticeIds.add(noticeId);
    this.serverNotices = this.serverNotices.filter((n) => n.id !== noticeId);
    this.emit();

    // Nếu là thư cá nhân (NT_U_{uid}_*), xóa thẳng gói thư trên nhánh refCodes để giải phóng băng thông vĩnh viễn
    if (noticeId.startsWith(`NT_U_${uid}_`)) {
      try {
        await set(ref(rtdb, `refCodes/${noticeId}`), null);
        delete this.rawNtUidMap[noticeId];
        this.deletedNoticeIds.delete(noticeId);
        if (!this.claimedNoticeIds.has(noticeId)) {
          this.readNoticeIds.delete(noticeId);
        }
        this.toastedNoticeIds.delete(noticeId);
      } catch {}
    }
    this.saveLocalNoticeMeta(uid, true);
  }

  async clearAllPlayerNotices(): Promise<void> {
    if (!this.user) return;
    const uid = this.user.uid;
    const currentItems = [...this.serverNotices];
    for (const item of currentItems) {
      this.deletedNoticeIds.add(item.id);
      this.readNoticeIds.add(item.id);
      this.toastedNoticeIds.add(item.id);
    }
    this.serverNotices = [];
    this.emit();

    const personalIds = currentItems
      .map((x) => x.id)
      .filter((id) => id.startsWith(`NT_U_${uid}_`));
    if (personalIds.length > 0) {
      await Promise.all(
        personalIds.map(async (id) => {
          try {
            await set(ref(rtdb, `refCodes/${id}`), null);
            delete this.rawNtUidMap[id];
            this.deletedNoticeIds.delete(id);
            if (!this.claimedNoticeIds.has(id)) {
              this.readNoticeIds.delete(id);
            }
            this.toastedNoticeIds.delete(id);
          } catch {}
        }),
      );
    }
    this.saveLocalNoticeMeta(uid, true);
  }

  async sendAdminRealtimeNotice(
    targetUidRaw: string,
    message: string,
    rewardAmount = 0,
    senderNameRaw = '',
    options?: { isLixi?: boolean; lixiStyle?: LixiStyle },
  ): Promise<{ ok: boolean; error?: string }> {
    if (!this.user || !this.isCurrentUserAdmin()) {
      return { ok: false, error: 'Bạn cần đăng nhập đúng tài khoản Admin trước khi gửi!' };
    }
    const isLixi = !!options?.isLixi;
    const lixiStyle: LixiStyle =
      options?.lixiStyle === 'gold' || options?.lixiStyle === 'jade'
        ? options.lixiStyle
        : 'red';
    const cleanMsg =
      (message || '').trim().slice(0, 180) ||
      (isLixi ? 'Chúc Chủ Tiệm buôn may bán đắt, tiền vô như nước!' : '');
    if (!cleanMsg) {
      return { ok: false, error: 'Vui lòng nhập nội dung thông báo!' };
    }
    const reward = Math.max(0, Math.floor(Number(rewardAmount) || 0));
    if (isLixi && reward <= 0) {
      return { ok: false, error: 'Vui lòng nhập số tiền trong Bao Lì Xì lớn hơn 0!' };
    }
    const cleanSender = (senderNameRaw || '').trim().slice(0, 40) || 'Ban Quản Trị';
    const cleanTarget = (targetUidRaw || '').replace(/^UID\s*:\s*/i, '').trim();
    const isAll = !cleanTarget || cleanTarget.toUpperCase() === 'ALL';
    if (!isAll && /[.#$\[\]/\s]/.test(cleanTarget)) {
      return {
        ok: false,
        error: 'UID người chơi không hợp lệ (chứa khoảng trắng hoặc ký tự đặc biệt . # $ [ ] /)!',
      };
    }
    const ts = this.getServerNow();
    const hexSender = _encMsgHex(cleanSender);
    const hexMsg = _encMsgHex(cleanMsg);
    const payload = isLixi
      ? `LIXI_${lixiStyle}~${hexSender}~${hexMsg}`
      : `${hexSender}~${hexMsg}`;
    const key = isAll
      ? `NT_ALL_${ts}-${reward}-${payload}`
      : `NT_U_${cleanTarget}_${ts}-${reward}-${payload}`;

    try {
      await set(ref(rtdb, `refCodes/${key}`), this.user.uid);
      await this.fetchAdminSentNotices();
      return { ok: true };
    } catch {
      return { ok: false, error: 'Không thể gửi thông báo, kiểm tra kết nối mạng!' };
    }
  }

  async fetchAdminSentNotices(): Promise<void> {
    if (!this.user || !this.isCurrentUserAdmin()) return;
    try {
      const q = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('NT_'),
        endAt('NT_\uf8ff'),
      );
      const snap = await get(q);
      const val = snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
      const revokedSet = new Set<string>();
      for (const k of Object.keys(val)) {
        if (k.startsWith('NT_DEL_')) {
          const origKey = k.slice(7);
          revokedSet.add(origKey);
          this.rawNtDelMap[k] = val[k];
          // Tự động dọn sạch các thư đã thu hồi và cờ NT_DEL_ cũ trên RTDB để không tốn băng thông
          set(ref(rtdb, `refCodes/${origKey}`), null)
            .then(() => set(ref(rtdb, `refCodes/${k}`), null))
            .then(() => {
              delete this.rawNtDelMap[k];
              delete this.rawNtAllMap[origKey];
              delete this.rawNtUidMap[origKey];
            })
            .catch(() => undefined);
        }
      }
      const list: ServerNoticeItem[] = [];
      for (const [k, v] of Object.entries(val)) {
        if (k.startsWith('NT_DEL_') || revokedSet.has(k)) continue;
        const parsed = this.parseSingleNoticeKey(k, String(v || ''));
        if (parsed) list.push(parsed);
      }
      list.sort((a, b) => b.createdAt - a.createdAt);
      this.adminAllNotices = list;
      this.emit();
    } catch {}
  }

  checkSecretDevRoute(): boolean {
    return isSecretDevRoute();
  }

  checkSecretDevPin(pin: string): boolean {
    return verifySecretDevPin(pin);
  }

  async revokeAdminNotice(noticeId: string): Promise<boolean> {
    if (!this.user || !this.isCurrentUserAdmin()) return false;
    try {
      const delKey = `NT_DEL_${noticeId}`;
      let directDeleted = false;
      try {
        // Ưu tiên xóa thẳng bức thư gốc trên refCodes để giải phóng 100% dung lượng
        await set(ref(rtdb, `refCodes/${noticeId}`), null);
        directDeleted = true;
      } catch {}

      if (directDeleted) {
        // Nếu đã xóa sạch thư gốc thì xóa luôn cả cờ NT_DEL_ (nếu có) để không lưu rác trên RTDB
        set(ref(rtdb, `refCodes/${delKey}`), null).catch(() => undefined);
        delete this.rawNtDelMap[delKey];
      } else {
        // Dự phòng nếu Rules cũ chưa cho phép xóa null
        await set(ref(rtdb, `refCodes/${delKey}`), this.user.uid);
        this.rawNtDelMap[delKey] = this.user.uid;
      }
      delete this.rawNtAllMap[noticeId];
      delete this.rawNtUidMap[noticeId];
      this.adminAllNotices = this.adminAllNotices.filter((n) => n.id !== noticeId);
      this.serverNotices = this.serverNotices.filter((n) => n.id !== noticeId);
      this.emit();
      return true;
    } catch {
      return false;
    }
  }

  private recomputeCouplePackets(uid: string) {
    if (!uid || this.user?.uid !== uid) return;

    // A. Xử lý các gói phản hồi CP_ANS_{uid}_{ts}-{action}-{ringKey}-{hexShop}
    const ansPrefix = `CP_ANS_${uid}_`;
    const cancelBySender = new Map<string, number>();
    for (const [fullKey, senderUidRaw] of Object.entries(this.rawAnsMap)) {
      const senderUid = String(senderUidRaw || '');
      if (!senderUid || !fullKey.startsWith(ansPrefix)) continue;
      const tail = fullKey.slice(ansPrefix.length);
      const parts = tail.split('-');
      const ts = parseInt(parts[0] || '0', 10) || 0;
      const action = parts[1] || '';
      const ringKey = (parts[2] || 'silver') as 'silver' | 'gold' | 'diamond';
      const senderShop = _decHex(parts[3] || '');
      if (!ts) continue;

      if (action === 'CAN') {
        const prev = cancelBySender.get(senderUid) || 0;
        if (ts > prev) cancelBySender.set(senderUid, ts);
      }

      if (action === 'DIV' && ts > this.coupleDivorcedAt) {
        this.coupleDivorcedAt = ts;
      }

      // Nếu mình đang gửi lời cầu hôn cho senderUid và nhận được phản hồi (kể cả khi hai máy bị lệch giờ hoặc chỉnh đồng hồ)
      const isMatchingProposal =
        this.coupleState.status === 'single' &&
        !!this.outgoingProposal &&
        this.outgoingProposal.toUid === senderUid;

      const isFreshResponse =
        isMatchingProposal &&
        ts > this.coupleHandledTs &&
        (action === 'ACC' ||
          action === 'DEC' ||
          ts >= (this.outgoingProposal?.createdAt || 0) - 600000);

      if (isMatchingProposal && isFreshResponse) {
        const handledTs = Math.max(ts, this.outgoingProposal?.createdAt || 0, this.coupleHandledTs + 1);
        this.coupleHandledTs = handledTs;
        if (action === 'ACC') {
          const usedRingId = this.getRingDef(ringKey).id;
          const nextRings = this.ownedRings.filter((r, idx) => {
            const firstIdx = this.ownedRings.indexOf(usedRingId);
            return firstIdx >= 0 ? idx !== firstIdx : idx !== 0;
          });
          this.ownedRings = nextRings;
          this.bridge?.syncCoupleRings?.(nextRings);
          const nextCoupleState: CoupleMarriageState = {
            status: 'married',
            partnerUid: senderUid,
            partnerShop: senderShop || 'Bạn Đời',
            ringId: usedRingId,
            marriedAt: ts || this.getServerNow(),
            myHeartsSent: 0,
            myPointsSent: 0,
            dailyDate: this.getTodayKey(),
            dailyFreeUsed: 0,
            dailyGiftUsed: 0,
          };
          this.coupleState = nextCoupleState;
          this.outgoingProposal = null;
          update(ref(rtdb, `referrals/${uid}`), {
            coupleState: nextCoupleState,
            coupleOutProposal: null,
            coupleOwnedRings: nextRings,
            coupleHandledTs: handledTs,
            coupleClaimedMilestones: this.coupleClaimedMilestones,
            updatedAt: Date.now(),
          }).catch(() => undefined);
          this.bridge?.playSound?.('success');
          this.bridge?.notify(
            `💍 Chúc mừng! Chủ tiệm "${senderShop || 'Bạn Đời'}" đã đồng ý kết hôn với bạn!`,
            'good',
          );
        } else if (action === 'DEC') {
          this.outgoingProposal = null;
          update(ref(rtdb, `referrals/${uid}`), {
            coupleOutProposal: null,
            coupleHandledTs: handledTs,
            updatedAt: Date.now(),
          }).catch(() => undefined);
          this.bridge?.notify(
            `Chủ tiệm "${senderShop || 'Bạn Đời'}" chưa đồng ý lời cầu hôn. Nhẫn vẫn được giữ nguyên trong túi của bạn!`,
            'info',
          );
        }
      }

      // Nếu đang kết hôn với senderUid mà bên kia bấm hủy kết hôn (DIV)
      if (
        this.coupleState.status === 'married' &&
        this.coupleState.partnerUid === senderUid &&
        action === 'DIV' &&
        ts > this.coupleState.marriedAt &&
        ts > this.coupleHandledTs
      ) {
        this.coupleHandledTs = ts;
        this.coupleDivorcedAt = Math.max(this.coupleDivorcedAt, ts);
        this.coupleState = {
          status: 'single',
          partnerUid: '',
          partnerShop: '',
          ringId: 'ring_silver',
          marriedAt: 0,
          myHeartsSent: 0,
          myPointsSent: 0,
          dailyDate: '',
          dailyFreeUsed: 0,
          dailyGiftUsed: 0,
        };
        this.partnerHeartsReceived = 0;
        this.partnerPointsReceived = 0;
        this.bridge?.syncCoupleMeta?.({
          claimedMilestones: this.coupleClaimedMilestones,
          divorcedAt: this.coupleDivorcedAt,
        });
        update(ref(rtdb, `referrals/${uid}`), {
          coupleState: null,
          coupleHandledTs: ts,
          coupleDivorcedAt: this.coupleDivorcedAt,
          coupleClaimedMilestones: this.coupleClaimedMilestones,
          updatedAt: Date.now(),
        }).catch(() => undefined);
        this.bridge?.notify(
          `Chủ tiệm "${senderShop}" đã kết thúc cuộc hôn nhân với tiệm của bạn. Sau khi chia tay cần đợi 24 giờ mới có thể kết hôn lại.`,
          'info',
        );
      }
    }

    // B. Xử lý danh sách lời cầu hôn gửi đến mình CP_ASK_{uid}_{ts}-{ringKey}-{hexShop}
    if (this.coupleState.status === 'single') {
      const askPrefix = `CP_ASK_${uid}_`;
      const latestByProposer = new Map<string, CoupleProposalInfo>();
      for (const [fullKey, fromUidRaw] of Object.entries(this.rawAskMap)) {
        const fromUid = String(fromUidRaw || '');
        if (!fromUid || fromUid === uid || !fullKey.startsWith(askPrefix)) continue;
        const tail = fullKey.slice(askPrefix.length);
        const parts = tail.split('-');
        const ts = parseInt(parts[0] || '0', 10) || 0;
        const ringKeyRaw = parts[1] || 'silver';
        const fromShop = _decHex(parts[2] || '');
        if (!ts || ts <= this.coupleHandledTs) continue;
        const cancelTs = cancelBySender.get(fromUid) || 0;
        if (cancelTs >= ts) continue;
        if (ringKeyRaw === 'cancel') continue;
        const rDef = this.getRingDef(ringKeyRaw);
        const prev = latestByProposer.get(fromUid);
        if (!prev || ts > prev.createdAt) {
          latestByProposer.set(fromUid, {
            fromUid,
            fromShop,
            toUid: uid,
            ringId: rDef.id,
            ringKey: rDef.key,
            createdAt: ts,
          });
        }
      }
      const list = Array.from(latestByProposer.values()).sort((a, b) => b.createdAt - a.createdAt);
      this.incomingProposals = list;
      if (list.length > 0) {
        const newest = list[0];
        if (this.lastNotifiedAskTs === 0) {
          this.lastNotifiedAskTs = newest.createdAt;
        } else if (newest.createdAt > this.lastNotifiedAskTs) {
          this.lastNotifiedAskTs = newest.createdAt;
          this.bridge?.playSound?.('ting');
          this.bridge?.notify(
            `💍 Chủ tiệm "${newest.fromShop}" vừa gửi lời cầu hôn đến bạn!`,
            'good',
          );
        }
      }
    } else {
      this.incomingProposals = [];
    }

    // C. Xử lý tổng số Tim & Điểm Thân Mật nhận được từ bạn đời: CP_HRT_{uid}_{ts}-{hearts}-{points}-{kind}-{hexShop}
    if (this.coupleState.status === 'married' && this.coupleState.partnerUid) {
      const hrtPrefix = `CP_HRT_${uid}_`;
      let totalH = 0;
      let totalP = 0;
      let latestHrtTs = 0;
      let latestHrtCount = 0;
      let latestHrtPts = 0;
      let latestPartnerShop = this.coupleState.partnerShop;

      for (const [fullKey, senderUidRaw] of Object.entries(this.rawHrtMap)) {
        const senderUid = String(senderUidRaw || '');
        if (senderUid !== this.coupleState.partnerUid || !fullKey.startsWith(hrtPrefix)) continue;
        const tail = fullKey.slice(hrtPrefix.length);
        const parts = tail.split('-');
        const ts = parseInt(parts[0] || '0', 10) || 0;
        const hCount = Math.max(0, Math.min(20, parseInt(parts[1] || '0', 10) || 0));
        const pCount = Math.max(0, Math.min(500, parseInt(parts[2] || '0', 10) || 0));
        const pShop = parts[4] ? _decHex(parts[4]) : '';
        if (!ts || ts < this.coupleState.marriedAt - 60000) continue;
        totalH += hCount;
        totalP += pCount;
        if (ts > latestHrtTs) {
          latestHrtTs = ts;
          latestHrtCount = hCount;
          latestHrtPts = pCount;
          if (pShop) latestPartnerShop = pShop;
        }
      }

      this.partnerHeartsReceived = totalH;
      this.partnerPointsReceived = totalP;
      if (latestPartnerShop && latestPartnerShop !== this.coupleState.partnerShop) {
        this.coupleState.partnerShop = latestPartnerShop;
      }
      if (latestHrtTs > 0) {
        this.lastPartnerGiftText = `${this.coupleState.partnerShop} đã tặng bạn +${latestHrtCount} Tim (+${latestHrtPts} điểm)`;
        if (this.lastNotifiedHeartTs === 0) {
          this.lastNotifiedHeartTs = latestHrtTs;
        } else if (latestHrtTs > this.lastNotifiedHeartTs) {
          this.lastNotifiedHeartTs = latestHrtTs;
          this.bridge?.playSound?.('heart');
          this.bridge?.notify(
            `💕 "${this.coupleState.partnerShop}" vừa gửi tặng bạn +${latestHrtCount} Tim (+${latestHrtPts} Điểm Thân Mật)!`,
            'good',
          );
        }
      }
    } else {
      this.partnerHeartsReceived = 0;
      this.partnerPointsReceived = 0;
      this.lastPartnerGiftText = '';
    }
  }

  async refreshCoupleState(): Promise<void> {
    if (!this.user) return;
    const uid = this.user.uid;
    if (this.coupleListeningUid !== uid || this.coupleUnsubs.length === 0) {
      this.startCoupleRealtime(uid);
    }
    try {
      const myMCode = _makeMarryCode(uid);
      this.marryCode = myMCode;
      const codeSnap = await get(ref(rtdb, `refCodes/${myMCode}`));
      if (!codeSnap.exists()) {
        await set(ref(rtdb, `refCodes/${myMCode}`), uid).catch(() => undefined);
      }
      this.recomputeCouplePackets(uid);
      this.emit();
    } catch {
      this.emit();
    }
  }

  async buyCoupleRing(ringId: string): Promise<boolean> {
    if (!this.user) {
      this.bridge?.notify('Vui lòng đăng nhập Google trước khi mua nhẫn cầu hôn nha!', 'bad');
      return false;
    }
    if (this.coupleBusy || this.isKickedByOtherDevice || this.isCurrentAccountBanned) return false;
    const shop = this.getShopSnapshot();
    if (!shop.hasShop) {
      this.bridge?.notify('Vui lòng mở tiệm trước khi mua nhẫn trong Cửa hàng Cặp Đôi nha!', 'bad');
      return false;
    }
    if (shop.level < 2) {
      this.bridge?.notify('Cần nâng cấp tiệm đạt Cấp 2 mới mở khóa Cửa hàng Cặp Đôi & Kết hôn nha!', 'bad');
      return false;
    }
    const ring = COUPLE_RINGS.find((r) => r.id === ringId);
    if (!ring) return false;
    if (this.ownedRings.includes(ring.id)) {
      this.selectedRingId = ring.id;
      this.bridge?.notify(`Bạn đã sở hữu ${ring.name} trong túi rồi!`, 'info');
      this.emit();
      return false;
    }
    if (shop.money < ring.price) {
      this.bridge?.notify(
        `Chưa đủ tiền trong két! Cần ${ring.price.toLocaleString('vi-VN')}đ để mua ${ring.name}.`,
        'bad',
      );
      return false;
    }

    this.coupleBusy = true;
    this.emit();
    try {
      const paid = this.bridge?.spendShopMoney?.(ring.price);
      if (!paid) {
        this.bridge?.notify('Không thể trừ tiền trong két, vui lòng vào tiệm kiểm tra lại nha!', 'bad');
        return false;
      }
      const nextRings = Array.from(new Set([...this.ownedRings, ring.id]));
      this.ownedRings = nextRings;
      this.selectedRingId = ring.id;
      this.bridge?.syncCoupleRings?.(nextRings);
      await update(ref(rtdb, `referrals/${this.user.uid}`), {
        coupleOwnedRings: nextRings,
        updatedAt: Date.now(),
      });
      this.bridge?.playSound?.('cash');
      this.bridge?.notify(
        `Đã mua "${ring.name}" thành công! Giờ bạn có thể nhập Mã Kết Hôn để cầu hôn nha! 💍`,
        'good',
      );
      return true;
    } catch {
      this.bridge?.notify('Đã mua nhẫn vào túi! Kiểm tra kết nối mạng để đồng bộ nha.', 'info');
      return true;
    } finally {
      this.coupleBusy = false;
      this.emit();
    }
  }

  async sendMarriageProposal(rawCode: string, ringId?: string): Promise<boolean> {
    if (!this.user) {
      this.bridge?.notify('Vui lòng đăng nhập Google trước khi gửi lời cầu hôn nha!', 'bad');
      return false;
    }
    if (this.coupleBusy) return false;
    const shop = this.getShopSnapshot();
    if (shop.level < 2) {
      this.bridge?.notify('Tiệm cần đạt Cấp 2 mới có thể mở khóa tính năng Kết hôn nha!', 'bad');
      return false;
    }
    if (this.coupleState.status === 'married') {
      this.bridge?.notify('Bạn đã kết hôn rồi, không thể gửi thêm lời cầu hôn!', 'bad');
      return false;
    }
    if (this.getCoupleCooldownRemainingMs() > 0) {
      this.bridge?.notify(
        `Bạn vừa chia tay/ly hôn chưa đủ 24 giờ! Cần đợi thêm ${this.formatCoupleCooldown()} nữa mới có thể gửi lời cầu hôn mới nha!`,
        'bad',
      );
      return false;
    }
    if (this.ownedRings.length === 0) {
      this.bridge?.notify(
        'Bạn cần có Nhẫn Cầu Hôn mới có thể cầu hôn! Hãy ghé Cửa hàng Cặp Đôi mua nhẫn trước nha.',
        'bad',
      );
      return false;
    }
    const chosenRingId =
      ringId && this.ownedRings.includes(ringId)
        ? ringId
        : this.ownedRings.includes(this.selectedRingId)
          ? this.selectedRingId
          : this.ownedRings[this.ownedRings.length - 1];
    const ringDef = this.getRingDef(chosenRingId);

    const clean = (rawCode || '').trim().toUpperCase();
    if (!clean) {
      this.bridge?.notify('Vui lòng nhập Mã Kết Hôn của người chơi muốn kết hôn nha!', 'bad');
      return false;
    }

    const candidates: string[] = [];
    if (/^(TIM|TTC)-[A-Z0-9]{6}$/.test(clean)) {
      candidates.push(clean);
      const suffix = clean.slice(4);
      candidates.push(clean.startsWith('TIM-') ? `TTC-${suffix}` : `TIM-${suffix}`);
    } else if (/^[A-Z0-9]{6}$/.test(clean)) {
      candidates.push(`TIM-${clean}`, `TTC-${clean}`);
    } else {
      this.bridge?.notify('Mã Kết Hôn không đúng định dạng (ví dụ: TIM-XXXXXX)!', 'bad');
      return false;
    }

    const uid = this.user.uid;
    this.coupleBusy = true;
    this.emit();
    try {
      let targetUid = '';
      let matchedCode = candidates[0];
      for (const c of candidates) {
        const snap = await get(ref(rtdb, `refCodes/${c}`));
        if (snap.exists() && snap.val()) {
          targetUid = String(snap.val() || '');
          matchedCode = c;
          break;
        }
      }
      if (!targetUid) {
        this.bridge?.notify('Mã Kết Hôn không tồn tại hoặc người chơi này chưa kích hoạt!', 'bad');
        return false;
      }
      if (targetUid === uid) {
        this.bridge?.notify('Bạn không thể tự cầu hôn chính mình nha!', 'bad');
        return false;
      }

      const now = this.getServerNow();
      const myShopName = (shop.shopName || 'Tiệm Trái Cây').slice(0, 26);
      const askKey = `refCodes/CP_ASK_${targetUid}_${now}-${ringDef.key}-${_encHex(myShopName)}`;
      await set(ref(rtdb, askKey), uid);

      const proposalOut = {
        fromUid: uid,
        fromShop: myShopName,
        toUid: targetUid,
        toCode: matchedCode,
        ringId: ringDef.id,
        ringKey: ringDef.key,
        createdAt: now,
        status: 'pending',
      };
      await update(ref(rtdb, `referrals/${uid}`), {
        coupleOutProposal: proposalOut,
        updatedAt: now,
      });

      this.outgoingProposal = proposalOut;
      this.bridge?.playSound?.('success');
      this.bridge?.notify(
        `Đã gửi lời cầu hôn kèm "${ringDef.name}" tới mã ${matchedCode}! Hãy chờ người ấy đồng ý nha! 💍`,
        'good',
      );
      return true;
    } catch {
      this.bridge?.notify('Chưa gửi được lời cầu hôn, vui lòng kiểm tra mạng rồi thử lại nha!', 'bad');
      return false;
    } finally {
      this.coupleBusy = false;
      this.emit();
    }
  }

  async cancelMarriageProposal(): Promise<boolean> {
    if (!this.user || !this.outgoingProposal || this.coupleBusy) return false;
    const uid = this.user.uid;
    const targetUid = this.outgoingProposal.toUid;
    const shop = this.getShopSnapshot();
    this.coupleBusy = true;
    this.emit();
    try {
      const now = this.getServerNow();
      const canKey = `refCodes/CP_ANS_${targetUid}_${now}-CAN-${this.outgoingProposal.ringKey}-${_encHex(shop.shopName)}`;
      await Promise.all([
        set(ref(rtdb, canKey), uid).catch(() => undefined),
        update(ref(rtdb, `referrals/${uid}`), {
          coupleOutProposal: null,
          updatedAt: now,
        }),
      ]);
      this.outgoingProposal = null;
      this.bridge?.notify('Đã thu hồi lời cầu hôn. Nhẫn cầu hôn vẫn ở trong túi của bạn!', 'info');
      return true;
    } catch {
      return false;
    } finally {
      this.coupleBusy = false;
      this.emit();
    }
  }

  async acceptMarriageProposal(proposal: CoupleProposalInfo): Promise<boolean> {
    if (!this.user || this.coupleBusy) return false;
    const shop = this.getShopSnapshot();
    if (shop.level < 2) {
      this.bridge?.notify('Tiệm của bạn cần đạt Cấp 2 mới có thể kết hôn nha!', 'bad');
      return false;
    }
    if (this.getCoupleCooldownRemainingMs() > 0) {
      this.bridge?.notify(
        `Bạn vừa chia tay/ly hôn chưa đủ 24 giờ! Cần đợi thêm ${this.formatCoupleCooldown()} nữa mới có thể kết hôn lại nha!`,
        'bad',
      );
      return false;
    }
    const uid = this.user.uid;
    const now = this.getServerNow();
    const myShopName = (shop.shopName || 'Tiệm Trái Cây').slice(0, 26);
    const rDef = this.getRingDef(proposal.ringId);

    this.coupleBusy = true;
    this.emit();
    try {
      const ansKey = `refCodes/CP_ANS_${proposal.fromUid}_${now}-ACC-${rDef.key}-${_encHex(myShopName)}`;
      const nextCoupleState: CoupleMarriageState = {
        status: 'married',
        partnerUid: proposal.fromUid,
        partnerShop: proposal.fromShop || 'Tiệm Trái Cây',
        ringId: rDef.id,
        marriedAt: now,
        myHeartsSent: 0,
        myPointsSent: 0,
        dailyDate: this.getTodayKey(),
        dailyFreeUsed: 0,
        dailyGiftUsed: 0,
      };

      await set(ref(rtdb, ansKey), uid);
      await update(ref(rtdb, `referrals/${uid}`), {
        coupleState: nextCoupleState,
        coupleOutProposal: null,
        coupleHandledTs: now,
        coupleClaimedMilestones: this.coupleClaimedMilestones,
        updatedAt: now,
      });

      this.coupleHandledTs = now;
      this.coupleState = nextCoupleState;
      this.incomingProposals = [];
      this.outgoingProposal = null;
      this.bridge?.playSound?.('success');
      this.bridge?.notify(
        `💍 Chúc mừng hai chủ tiệm! Bạn và "${proposal.fromShop}" đã chính thức Kết Hôn!`,
        'good',
      );
      return true;
    } catch {
      this.bridge?.notify('Chưa xác nhận được lời cầu hôn, vui lòng thử lại nha!', 'bad');
      return false;
    } finally {
      this.coupleBusy = false;
      this.emit();
    }
  }

  async declineMarriageProposal(proposal: CoupleProposalInfo): Promise<boolean> {
    if (!this.user || this.coupleBusy) return false;
    const uid = this.user.uid;
    const now = this.getServerNow();
    const shop = this.getShopSnapshot();
    const rDef = this.getRingDef(proposal.ringId);

    this.coupleBusy = true;
    this.emit();
    try {
      const ansKey = `refCodes/CP_ANS_${proposal.fromUid}_${now}-DEC-${rDef.key}-${_encHex(shop.shopName)}`;
      await Promise.all([
        set(ref(rtdb, ansKey), uid).catch(() => undefined),
        update(ref(rtdb, `referrals/${uid}`), {
          coupleHandledTs: now,
          updatedAt: now,
        }),
      ]);
      this.coupleHandledTs = now;
      this.incomingProposals = this.incomingProposals.filter((p) => p.fromUid !== proposal.fromUid);
      this.bridge?.notify(`Đã từ chối lời cầu hôn từ tiệm "${proposal.fromShop}".`, 'info');
      return true;
    } catch {
      return false;
    } finally {
      this.coupleBusy = false;
      this.emit();
    }
  }

  async sendCoupleHeart(kind: 'free' | 'gift'): Promise<boolean> {
    if (!this.user || this.coupleBusy || this.isKickedByOtherDevice || this.isCurrentAccountBanned || this.coupleState.status !== 'married') return false;
    const shop = this.getShopSnapshot();
    const today = this.getTodayKey();
    const { freeLeft, giftLeft } = this.getDailyHeartRemaining();

    const isGift = kind === 'gift';
    const cost = isGift ? 50000 : 0;
    const heartsAdd = isGift ? 3 : 1;
    const pointsAdd = isGift ? 50 : 15;

    if (!isGift && freeLeft <= 0) {
      this.bridge?.notify('Hôm nay bạn đã dùng hết 3 lượt Tặng Tim miễn phí rồi! Mai tặng tiếp nha.', 'info');
      return false;
    }
    if (isGift && giftLeft <= 0) {
      this.bridge?.notify('Hôm nay bạn đã tặng tối đa 3 Giỏ Trái Cây Tình Yêu rồi!', 'info');
      return false;
    }
    if (isGift) {
      if (!shop.hasShop || shop.money < cost) {
        this.bridge?.notify(
          `Cần ${cost.toLocaleString('vi-VN')}đ trong két tiệm để tặng Giỏ Trái Cây Tình Yêu!`,
          'bad',
        );
        return false;
      }
      const paid = this.bridge?.spendShopMoney?.(cost);
      if (!paid) {
        this.bridge?.notify('Không thể trừ tiền trong két, vui lòng vào tiệm kiểm tra lại nha!', 'bad');
        return false;
      }
    }

    const uid = this.user.uid;
    const partnerUid = this.coupleState.partnerUid;
    const now = this.getServerNow();
    const myShopName = (shop.shopName || 'Tiệm Trái Cây').slice(0, 26);

    this.coupleBusy = true;
    this.emit();
    try {
      const sameDay = this.coupleState.dailyDate === today;
      const nextFree = (sameDay ? this.coupleState.dailyFreeUsed : 0) + (isGift ? 0 : 1);
      const nextGift = (sameDay ? this.coupleState.dailyGiftUsed : 0) + (isGift ? 1 : 0);
      const nextHearts = (this.coupleState.myHeartsSent || 0) + heartsAdd;
      const nextPoints = (this.coupleState.myPointsSent || 0) + pointsAdd;

      const hrtKey = `refCodes/CP_HRT_${partnerUid}_${now}-${heartsAdd}-${pointsAdd}-${kind}-${_encHex(myShopName)}`;
      const nextState: CoupleMarriageState = {
        ...this.coupleState,
        myHeartsSent: nextHearts,
        myPointsSent: nextPoints,
        dailyDate: today,
        dailyFreeUsed: nextFree,
        dailyGiftUsed: nextGift,
      };

      await set(ref(rtdb, hrtKey), uid);
      await update(ref(rtdb, `referrals/${uid}`), {
        coupleState: nextState,
        updatedAt: now,
      });

      this.coupleState = nextState;
      this.bridge?.playSound?.('heart');
      this.bridge?.notify(
        `💕 Đã gửi tặng +${heartsAdd} Tim (+${pointsAdd} Điểm Thân Mật) cho "${this.coupleState.partnerShop}"!`,
        'good',
      );
      return true;
    } catch {
      this.bridge?.notify('Chưa gửi được Tim, vui lòng kiểm tra mạng rồi thử lại nha!', 'bad');
      return false;
    } finally {
      this.coupleBusy = false;
      this.emit();
    }
  }

  async claimCoupleMilestone(milestoneId: number): Promise<boolean> {
    if (!this.user || this.coupleBusy || this.isKickedByOtherDevice || this.isCurrentAccountBanned || this.coupleState.status !== 'married') return false;
    const m = COUPLE_MILESTONES.find((x) => x.id === milestoneId);
    if (!m) return false;
    if (
      this.coupleClaimedMilestones.includes(m.id) ||
      this.getTotalCouplePoints() < m.targetPoints
    ) {
      return false;
    }

    this.coupleBusy = true;
    this.emit();
    try {
      const uid = this.user.uid;
      const nextClaimed = Array.from(new Set([...this.coupleClaimedMilestones, m.id]));
      await update(ref(rtdb, `referrals/${uid}`), {
        coupleClaimedMilestones: nextClaimed,
        updatedAt: Date.now(),
      });
      this.coupleClaimedMilestones = nextClaimed;
      this.bridge?.syncCoupleMeta?.({
        claimedMilestones: nextClaimed,
        divorcedAt: this.coupleDivorcedAt,
      });
      this.bridge?.grantReferralMoney?.(m.reward);
      this.bridge?.playSound?.('cash');
      this.bridge?.notify(
        `💝 Đã nhận thưởng Cặp Đôi "${m.title}": +${m.reward.toLocaleString('vi-VN')}đ vào két tiệm!`,
        'good',
      );
      return true;
    } catch {
      this.bridge?.notify('Chưa nhận thưởng được, vui lòng thử lại nha!', 'bad');
      return false;
    } finally {
      this.coupleBusy = false;
      this.emit();
    }
  }

  async divorceCouple(): Promise<boolean> {
    if (!this.user || this.coupleBusy || this.coupleState.status !== 'married') return false;
    const uid = this.user.uid;
    const partnerUid = this.coupleState.partnerUid;
    const partnerShop = this.coupleState.partnerShop;
    const shop = this.getShopSnapshot();
    const now = this.getServerNow();

    this.coupleBusy = true;
    this.emit();
    try {
      const divKey = `refCodes/CP_ANS_${partnerUid}_${now}-DIV-none-${_encHex(shop.shopName)}`;
      await Promise.all([
        set(ref(rtdb, divKey), uid).catch(() => undefined),
        update(ref(rtdb, `referrals/${uid}`), {
          coupleState: null,
          coupleHandledTs: now,
          coupleDivorcedAt: now,
          coupleClaimedMilestones: this.coupleClaimedMilestones,
          updatedAt: now,
        }),
      ]);
      this.coupleHandledTs = now;
      this.coupleDivorcedAt = now;
      this.coupleState = {
        status: 'single',
        partnerUid: '',
        partnerShop: '',
        ringId: 'ring_silver',
        marriedAt: 0,
        myHeartsSent: 0,
        myPointsSent: 0,
        dailyDate: '',
        dailyFreeUsed: 0,
        dailyGiftUsed: 0,
      };
      this.partnerHeartsReceived = 0;
      this.partnerPointsReceived = 0;
      this.bridge?.syncCoupleMeta?.({
        claimedMilestones: this.coupleClaimedMilestones,
        divorcedAt: now,
      });
      this.bridge?.notify(
        `Đã hủy kết hôn với tiệm "${partnerShop}". Cần đợi 24 giờ sau khi chia tay mới có thể kết hôn lại nha!`,
        'info',
      );
      return true;
    } catch {
      return false;
    } finally {
      this.coupleBusy = false;
      this.emit();
    }
  }

  async redeemGiftcode(rawInput: string): Promise<boolean> {
    if (!this.user) {
      this.bridge?.notify('Vui lòng đăng nhập Google trước khi nhập Giftcode nha!', 'bad');
      return false;
    }
    if (this.giftcodeBusy || this.isKickedByOtherDevice || this.isCurrentAccountBanned) return false;
    const clean = (rawInput || '').trim().toUpperCase().replace(/\s+/g, ' ');
    if (!clean) {
      this.bridge?.notify('Vui lòng nhập mã Giftcode nha!', 'bad');
      return false;
    }

    let rtdbKey = '';
    let codeType: 'creator' | 'money' | 'pool_money' | '' = '';
    let displayCode = clean;
    let rewardAmount = 0;
    let maxClaims = 1;

    if (clean === 'CREATOR') {
      rtdbKey = 'refCodes/GC_CREATOR';
      codeType = 'creator';
      displayCode = 'CREATOR';
    } else if (clean === 'KHOINGHIEP') {
      rtdbKey = 'refCodes/GC_KHOINGHIEP';
      codeType = 'money';
      displayCode = 'KHOINGHIEP';
      rewardAmount = 5000000;
    } else if (clean === 'KHOINGHIEP 1' || clean === 'KHOINGHIEP1') {
      rtdbKey = 'refCodes/GC_KHOINGHIEP_1';
      codeType = 'money';
      displayCode = 'KHOINGHIEP 1';
      rewardAmount = 5000000;
    } else if (clean === 'HAIBARAAI' || clean === 'HAIBARA AI') {
      rtdbKey = 'refCodes/GC_HAIBARAAI';
      codeType = 'pool_money';
      displayCode = 'HAIBARAAI';
      rewardAmount = 1000000;
      maxClaims = 500;
    } else if (clean === 'CAPDOI' || clean === 'CAP DOI' || clean === 'CẶP ĐÔI' || clean === 'CẶPĐÔI') {
      rtdbKey = 'refCodes/GC_CAPDOI';
      codeType = 'pool_money';
      displayCode = 'CAPDOI';
      rewardAmount = 2000000;
      maxClaims = 100;
    } else if (clean === 'CHAOMUNG' || clean === 'CHAO MUNG' || clean === 'CHÀO MỪNG' || clean === 'CHÀOMỪNG') {
      rtdbKey = 'refCodes/GC_CHAOMUNG';
      codeType = 'pool_money';
      displayCode = 'CHAOMUNG';
      rewardAmount = 2000000;
      maxClaims = 999999999;
    } else if (clean === 'HAPPY') {
      rtdbKey = 'refCodes/GC_HAPPY';
      codeType = 'pool_money';
      displayCode = 'HAPPY';
      rewardAmount = 2000000;
      maxClaims = 300;
    } else {
      this.bridge?.notify('Mã Giftcode không chính xác hoặc không tồn tại!', 'bad');
      return false;
    }

    if (
      (codeType === 'money' || codeType === 'pool_money') &&
      this.bridge?.hasActiveShop &&
      !this.bridge.hasActiveShop()
    ) {
      const rewardText = `${rewardAmount.toLocaleString('vi-VN')}đ`;
      this.bridge?.notify(`Vui lòng mở tiệm trước khi nhập mã nhận ${rewardText} nha!`, 'bad');
      return false;
    }

    const uid = this.user.uid;
    this.giftcodeBusy = true;
    this.emit();
    try {
      if (codeType === 'pool_money') {
        const userRef = ref(rtdb, `referrals/${uid}`);
        const myClaimKey = `refCodes/GC_${displayCode}_${uid}`;

        // 1. Kiểm tra tài khoản hiện tại đã nhận quà từ mã này chưa (chỉ đọc đúng ngăn kéo con của giftcode)
        const rawSubKey = rtdbKey.slice(9);
        const [giftSubSnap, giftDispSnap, myClaimSnap] = await Promise.all([
          get(ref(rtdb, `referrals/${uid}/gift_${rawSubKey}`)).catch(() => null),
          get(ref(rtdb, `referrals/${uid}/gift_${displayCode}`)).catch(() => null),
          get(ref(rtdb, myClaimKey)).catch(() => null),
        ]);
        const alreadyClaimed = !!(
          giftSubSnap?.exists() ||
          giftDispSnap?.exists() ||
          myClaimSnap?.exists()
        );

        if (alreadyClaimed) {
          this.bridge?.notify(
            `Bạn đã nhập mã ${displayCode} và nhận ${rewardAmount.toLocaleString('vi-VN')}đ trước đó rồi!`,
            'bad',
          );
          return false;
        }

        // 2. Đếm tổng số lượt đã nhận trên toàn server bằng query tiền tố GC_CAPDOI_* hoặc GC_HAIBARAAI_*
        const poolQuery = query(
          ref(rtdb, 'refCodes'),
          orderByKey(),
          startAt(`GC_${displayCode}_`),
          endAt(`GC_${displayCode}_\uf8ff`),
        );
        const poolSnap = await get(poolQuery);
        const claimsMap =
          poolSnap.exists() && typeof poolSnap.val() === 'object' ? poolSnap.val() || {} : {};
        const totalClaims = Object.keys(claimsMap).length;

        if (totalClaims >= maxClaims) {
          this.bridge?.notify(
            `Mã ${displayCode} đã đạt giới hạn ${maxClaims} lượt nhập trên toàn server!`,
            'bad',
          );
          return false;
        }

        // 3. Ghi nhận claim dưới dạng String UID chuẩn (phù hợp tuyệt đối với Security Rules của refCodes)
        await set(ref(rtdb, myClaimKey), uid);

        // 4. Đánh dấu đã nhận trong profile cá nhân của user
        await update(userRef, {
          [`gift_${rawSubKey}`]: Date.now(),
          [`gift_${displayCode}`]: Date.now(),
          updatedAt: Date.now(),
        }).catch(() => undefined);

        // 5. Cộng tiền thưởng vào két tiệm
        this.bridge?.grantReferralMoney?.(rewardAmount);
        this.bridge?.notify(
          `Nhập mã ${displayCode} thành công! Tiệm được nhận +${rewardAmount.toLocaleString('vi-VN')}đ!`,
          'good',
        );
        return true;
      }
      const codeRef = ref(rtdb, rtdbKey);
      const existingSnap = await get(codeRef);
      if (existingSnap.exists()) {
        const owner = String(existingSnap.val() || '');
        if (owner === uid) {
          if (codeType === 'creator') {
            this.creatorUid = uid;
            try {
              localStorage.setItem(_C_STORE, uid);
            } catch {}
            this.leaderboard = this.leaderboard.map((item) =>
              item.uid === uid ? { ...item, cTag: _makeCTag(uid) } : item,
            );
            this.daysLeaderboard = this.daysLeaderboard.map((item) =>
              item.uid === uid ? { ...item, cTag: _makeCTag(uid) } : item,
            );
            this.bridge?.notify('Tài khoản của bạn đã sở hữu danh hiệu CREATOR TIKTOK rồi!', 'info');
            return false;
          }
          this.bridge?.notify(`Bạn đã nhập mã ${displayCode} và nhận 5.000.000đ trước đó rồi!`, 'bad');
          return false;
        }
        this.bridge?.notify(
          `Mã ${displayCode} chỉ có 1 lượt nhập duy nhất và đã có người nhập mất rồi!`,
          'bad',
        );
        return false;
      }

      try {
        await runTransaction(codeRef, (cur) => {
          if (cur) return;
          return uid;
        });
      } catch {
        await set(codeRef, uid);
      }

      const verifySnap = await get(codeRef);
      if (!verifySnap.exists() || String(verifySnap.val() || '') !== uid) {
        this.bridge?.notify(
          `Mã ${displayCode} chỉ có 1 lượt nhập duy nhất và vừa có người nhập trước rồi!`,
          'bad',
        );
        return false;
      }

      if (codeType === 'creator') {
        this.creatorUid = uid;
        try {
          localStorage.setItem(_C_STORE, uid);
        } catch {}
        await update(ref(rtdb, `referrals/${uid}`), {
          creatorBadge: true,
          updatedAt: Date.now(),
        }).catch(() => undefined);
        this.leaderboard = this.leaderboard.map((item) =>
          item.uid === uid ? { ...item, cTag: _makeCTag(uid) } : item,
        );
        this.daysLeaderboard = this.daysLeaderboard.map((item) =>
          item.uid === uid ? { ...item, cTag: _makeCTag(uid) } : item,
        );
        this.bridge?.notify(
          'Chúc mừng! Bạn đã nhận được danh hiệu độc quyền CREATOR TIKTOK!',
          'good',
        );
        return true;
      } else {
        await update(ref(rtdb, `referrals/${uid}`), {
          [`gift_${rtdbKey.slice(9)}`]: Date.now(),
          updatedAt: Date.now(),
        }).catch(() => undefined);
        this.bridge?.grantReferralMoney?.(5000000);
        this.bridge?.notify(
          `Nhập mã ${displayCode} thành công! Tiệm được nhận +5.000.000đ vốn khởi nghiệp!`,
          'good',
        );
        return true;
      }
    } catch {
      this.bridge?.notify('Chưa kết nối được máy chủ Giftcode, vui lòng thử lại nha!', 'bad');
      return false;
    } finally {
      this.giftcodeBusy = false;
      this.emit();
    }
  }

  isCurrentUserCreator(): boolean {
    if (!this.user) return false;
    if (this.creatorUid && this.creatorUid === this.user.uid) return true;
    try {
      return localStorage.getItem(_C_STORE) === this.user.uid;
    } catch {
      return false;
    }
  }

  isEntryCreator(entry?: LeaderboardEntry | null): boolean {
    if (!entry || !entry.uid) return false;
    if (typeof entry.cTag === 'number' && entry.cTag > 0 && entry.cTag === _makeCTag(entry.uid)) {
      return true;
    }
    if (this.creatorUid && entry.uid === this.creatorUid) {
      return true;
    }
    if (this.isCurrentUserCreator() && this.user?.uid === entry.uid) {
      return true;
    }
    return false;
  }

  isCurrentUserAdmin(): boolean {
    return _verifySpecUser(this.user?.email);
  }

  isEntryAdmin(entry?: LeaderboardEntry | null): boolean {
    if (!entry || !entry.uid) return false;
    if (typeof entry.vTag === 'number' && entry.vTag > 0 && entry.vTag === _makeVTag(entry.uid)) {
      return true;
    }
    if (this.isCurrentUserAdmin() && this.user?.uid === entry.uid) {
      return true;
    }
    return false;
  }

  isVerifiedAdmin(entry?: any): boolean {
    if (!entry) return false;
    if (entry.isAdmin === true) return true;
    return this.isEntryAdmin(entry);
  }

  isVerifiedCreator(entry?: any): boolean {
    if (!entry) return false;
    if (entry.isCreator === true) return true;
    return this.isEntryCreator(entry);
  }

  getCustomAvatar(): string {
    try {
      return localStorage.getItem(_V_AV_STORE) || '';
    } catch {
      return '';
    }
  }

  getEntryAvatar(entry?: LeaderboardEntry | null): string {
    if (!entry) return '';
    if (typeof entry.av === 'string' && entry.av) return entry.av;
    if (
      (this.isCurrentUserAdmin() || this.isCurrentUserCreator()) &&
      this.user?.uid === entry.uid
    ) {
      return this.getCustomAvatar();
    }
    return '';
  }

  async updateAdminAvatar(file: File): Promise<void> {
    const isAdm = this.isCurrentUserAdmin();
    const isCre = this.isCurrentUserCreator();
    if (!this.user || (!isAdm && !isCre) || !file) return;
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onerror = () => reject(new Error('read_err'));
        reader.onload = () => {
          const img = new Image();
          img.onerror = () => reject(new Error('img_err'));
          img.onload = () => {
            const size = 112;
            const canvas = document.createElement('canvas');
            canvas.width = size;
            canvas.height = size;
            const ctx = canvas.getContext('2d');
            if (!ctx) return reject(new Error('ctx_err'));
            const minSide = Math.min(img.width, img.height);
            const sx = (img.width - minSide) / 2;
            const sy = (img.height - minSide) / 2;
            ctx.drawImage(img, sx, sy, minSide, minSide, 0, 0, size, size);
            resolve(canvas.toDataURL('image/jpeg', 0.84));
          };
          img.src = String(reader.result || '');
        };
        reader.readAsDataURL(file);
      });
      try {
        localStorage.setItem(_V_AV_STORE, dataUrl);
      } catch {}
      const uid = this.user.uid;
      const tagPatch = {
        ...(isAdm ? { vTag: _makeVTag(uid) } : {}),
        ...(isCre ? { cTag: _makeCTag(uid) } : {}),
        av: dataUrl,
      };

      this.leaderboard = this.leaderboard.map((item) =>
        item.uid === uid ? { ...item, ...tagPatch } : item,
      );
      this.daysLeaderboard = this.daysLeaderboard.map((item) =>
        item.uid === uid ? { ...item, ...tagPatch } : item,
      );
      this.emit();

      const lbRef = doc(db, 'leaderboards', 'global');
      const lbSnap = await getDoc(lbRef);
      if (lbSnap.exists()) {
        const lbData = lbSnap.data();
        if (Array.isArray(lbData?.entries)) {
          let changed = false;
          const updatedEntries = lbData.entries.map((item: any) => {
            if (item && item.uid === uid) {
              changed = true;
              return {
                ...item,
                ...tagPatch,
              };
            }
            return item;
          });
          if (changed) {
            const batch = writeBatch(db);
            batch.update(lbRef, {
              entries: updatedEntries,
              updatedBy: uid,
              updatedAt: serverTimestamp(),
            });
            await batch.commit();
          }
        }
      }
      this.bridge?.notify('Đã cập nhật Avatar hiển thị trên Bảng xếp hạng!', 'good');
    } catch {
      this.bridge?.notify('Không thể đọc ảnh này, vui lòng chọn ảnh khác nha.', 'bad');
    }
  }

  private lastFeedbackSentAt = 0;

  private async detectPlayerLocation(): Promise<string> {
    let tz = '';
    try {
      tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    } catch {}

    let geoText = '';
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 2000);
      const res = await fetch('https://ipwho.is/', { signal: ctrl.signal });
      clearTimeout(timer);
      if (res.ok) {
        const data = await res.json();
        if (data && data.success) {
          const parts = [data.city, data.region, data.country].filter(Boolean);
          const coords =
            typeof data.latitude === 'number' && typeof data.longitude === 'number'
              ? ` (${data.latitude.toFixed(4)}, ${data.longitude.toFixed(4)})`
              : '';
          geoText = `${parts.join(', ')}${coords} · IP: ${data.ip || ''}`;
        }
      }
    } catch {}

    if (geoText && tz) return `${geoText} [Múi giờ: ${tz}]`;
    if (geoText) return geoText;
    if (tz) return `Múi giờ thiết bị: ${tz}`;
    return 'Không xác định được vị trí';
  }

  async prepareFeedbackImage(
    file: File,
  ): Promise<{ ok: true; blob: Blob; fileName: string; sizeKB: number } | { ok: false; reason: 'type' | 'too_large' | 'decode' }> {
    if (!file) return { ok: false, reason: 'type' };
    const isImgType =
      (typeof file.type === 'string' && file.type.startsWith('image/')) ||
      /\.(png|jpe?g|webp|gif|heic|heif|bmp)$/i.test(file.name || '');
    if (!isImgType) {
      return { ok: false, reason: 'type' };
    }
    if (file.size > 25 * 1024 * 1024) {
      return { ok: false, reason: 'too_large' };
    }

    const baseName =
      (file.name || 'screenshot')
        .replace(/\.[^.]+$/, '')
        .replace(/[^a-zA-Z0-9_-]+/g, '_')
        .slice(0, 40) || 'screenshot';

    const maxBytes = 4.5 * 1024 * 1024;
    const objUrl = URL.createObjectURL(file);
    try {
      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const el = new Image();
        el.onload = () => resolve(el);
        el.onerror = () => reject(new Error('IMG_DECODE_FAIL'));
        el.src = objUrl;
      });
      const srcW = img.naturalWidth || img.width || 0;
      const srcH = img.naturalHeight || img.height || 0;
      if (srcW <= 0 || srcH <= 0) {
        throw new Error('IMG_EMPTY');
      }
      const maxDim = 1280;
      const scale = Math.min(1, maxDim / Math.max(srcW, srcH));
      const dstW = Math.max(1, Math.round(srcW * scale));
      const dstH = Math.max(1, Math.round(srcH * scale));
      const canvas = document.createElement('canvas');
      canvas.width = dstW;
      canvas.height = dstH;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        throw new Error('NO_2D_CTX');
      }
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, dstW, dstH);
      ctx.drawImage(img, 0, 0, dstW, dstH);

      let blob = await new Promise<Blob | null>((resolve) =>
        canvas.toBlob((b) => resolve(b), 'image/jpeg', 0.82),
      );
      if (blob && blob.size > 1.5 * 1024 * 1024) {
        const lighter = await new Promise<Blob | null>((resolve) =>
          canvas.toBlob((b) => resolve(b), 'image/jpeg', 0.68),
        );
        if (lighter && lighter.size < blob.size) blob = lighter;
      }
      if (!blob) {
        throw new Error('TO_BLOB_FAIL');
      }
      if (
        file.size <= 600 * 1024 &&
        /^image\/(jpeg|png|webp|gif)$/i.test(file.type || '') &&
        file.size < blob.size
      ) {
        return {
          ok: true,
          blob: file,
          fileName: file.name || `${baseName}.jpg`,
          sizeKB: Math.max(1, Math.round(file.size / 1024)),
        };
      }
      if (blob.size > maxBytes) {
        return { ok: false, reason: 'too_large' };
      }
      return {
        ok: true,
        blob,
        fileName: `${baseName}.jpg`,
        sizeKB: Math.max(1, Math.round(blob.size / 1024)),
      };
    } catch {
      if (file.size <= maxBytes && /^image\/(jpeg|png|webp|gif|heic|heif)$/i.test(file.type || '')) {
        return {
          ok: true,
          blob: file,
          fileName: file.name || `${baseName}.jpg`,
          sizeKB: Math.max(1, Math.round(file.size / 1024)),
        };
      }
      return { ok: false, reason: 'decode' };
    } finally {
      try {
        URL.revokeObjectURL(objUrl);
      } catch {}
    }
  }

  async sendFeedbackReport(
    shopName: string,
    message: string,
    extra?: {
      day?: number;
      money?: string;
      level?: number;
      lang?: string;
      screen?: string;
      attachment?: Blob | File | null;
      attachmentName?: string;
    },
  ): Promise<{ ok: boolean; reason?: string }> {
    const cleanShop = (shopName || '').trim().slice(0, 80) || 'Chưa đặt tên tiệm';
    const cleanMsg = (message || '').trim().slice(0, 1500);
    if (!cleanMsg) {
      return { ok: false, reason: 'empty' };
    }
    if (Date.now() - this.lastFeedbackSentAt < 20000) {
      return { ok: false, reason: 'cooldown' };
    }
    if (extra?.attachment && extra.attachment.size > 5 * 1024 * 1024) {
      return { ok: false, reason: 'file_too_large' };
    }
    try {
      const dest = _V_ARR
        .map((b, i) => String.fromCharCode(b ^ ((0x73 + i * 13) & 0xff)))
        .join('');
      const progressStr =
        extra && extra.day
          ? `Ngày ${extra.day} · ${extra.money || '0đ'} · Cấp ${extra.level || 1}`
          : 'Ở màn hình chính / Chưa mở tiệm';
      let localOwnerUid = '';
      try {
        localOwnerUid = this.bridge?.getLocalExport?.()?.ownerUid || '';
      } catch {}
      const playerUid = this.user?.uid
        ? this.user.uid
        : localOwnerUid
          ? `${localOwnerUid} (Lưu trên máy, đang đăng xuất)`
          : 'Chưa đăng nhập (Khách)';
      const accountStr = this.user
        ? `${this.user.displayName || 'Người chơi'} (${this.user.email || 'Không có email'}) · UID: ${this.user.uid}`
        : 'Chưa đăng nhập Google';

      const screenStr =
        extra?.screen ||
        (typeof window !== 'undefined'
          ? `${window.innerWidth}x${window.innerHeight} (DPR ${window.devicePixelRatio || 1})`
          : '');
      const envStr = [extra?.lang ? `Ngôn ngữ: ${extra.lang}` : '', screenStr]
        .filter(Boolean)
        .join(' · ');

      const playerLocation = await this.detectPlayerLocation();
      const sentAtStr =
        new Date().toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' }) + ' (Giờ VN)';
      const uaStr = typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 200) : '';

      if (extra?.attachment) {
        const fd = new FormData();
        fd.append('_subject', `[Tiệm Trái Cây] Báo lỗi / Góp ý từ tiệm: ${cleanShop}`);
        fd.append('_template', 'table');
        fd.append('_captcha', 'false');
        if (typeof window !== 'undefined' && window.location?.href) {
          fd.append('_url', window.location.href);
        }
        fd.append('Tên tiệm', cleanShop);
        fd.append('UID người chơi', playerUid);
        fd.append('Lời nhắn', cleanMsg);
        fd.append('Tiến trình tiệm', progressStr);
        if (envStr) fd.append('Ngôn ngữ - Màn hình', envStr);
        fd.append('Tài khoản Google', accountStr);
        fd.append('Vị trí người chơi', playerLocation);
        fd.append('Thời gian gửi', sentAtStr);
        fd.append('Thiết bị', uaStr);
        const safeName =
          (extra.attachmentName || 'screenshot.jpg')
            .replace(/[^\w.\-]+/g, '_')
            .slice(0, 80) || 'screenshot.jpg';
        let fileToSend: Blob = extra.attachment;
        try {
          if (!(extra.attachment instanceof File)) {
            fileToSend = new File([extra.attachment], safeName, {
              type: extra.attachment.type || 'image/jpeg',
            });
          }
        } catch {}
        fd.append('attachment', fileToSend, safeName);

        const res = await fetch(`https://formsubmit.co/${encodeURIComponent(dest)}`, {
          method: 'POST',
          body: fd,
        });
        if (!res.ok) {
          return { ok: false, reason: 'network' };
        }
        try {
          const html = await res.text();
          if (
            /This form needs Activation|open this page through a web server|unable to submit|g-recaptcha|not a robot|verify you are/i.test(
              html,
            )
          ) {
            return { ok: false, reason: 'network' };
          }
        } catch {}
        this.lastFeedbackSentAt = Date.now();
        return { ok: true };
      }

      const payload: Record<string, string> = {
        _subject: `[Tiệm Trái Cây] Báo lỗi / Góp ý từ tiệm: ${cleanShop}`,
        _template: 'table',
        _captcha: 'false',
        'Tên tiệm': cleanShop,
        'UID người chơi': playerUid,
        'Lời nhắn / Báo lỗi': cleanMsg,
        'Tiến trình tiệm': progressStr,
        ...(envStr ? { 'Ngôn ngữ & Màn hình': envStr } : {}),
        'Tài khoản Google': accountStr,
        'Vị trí người chơi': playerLocation,
        'Thời gian gửi': sentAtStr,
        'Thiết bị / Trình duyệt': uaStr,
      };
      const res = await fetch(`https://formsubmit.co/ajax/${encodeURIComponent(dest)}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        return { ok: false, reason: 'network' };
      }
      try {
        const json = await res.json();
        if (json && (json.success === false || json.success === 'false')) {
          return { ok: false, reason: 'network' };
        }
      } catch {}
      this.lastFeedbackSentAt = Date.now();
      return { ok: true };
    } catch {
      return { ok: false, reason: 'network' };
    }
  }

  private parseLeaderboardEntriesList(rawEntries: unknown): LeaderboardEntry[] {
    if (!Array.isArray(rawEntries)) return [];
    const out: LeaderboardEntry[] = [];
    for (const item of rawEntries) {
      if (item && typeof item.uid === 'string' && item.uid) {
        const vTag = typeof item.vTag === 'number' ? item.vTag >>> 0 : 0;
        const cTag = typeof item.cTag === 'number' ? item.cTag >>> 0 : 0;
        const av = typeof item.av === 'string' && item.av.length <= 60000 ? item.av : '';
        const pet =
          item.pet === 's' || item.pet === 'shiba'
            ? 's'
            : item.pet === 'm' || item.pet === 'meo_muop'
              ? 'm'
              : '';
        const itemDay =
          typeof item.day === 'number' && Number.isFinite(item.day) && item.day >= 1
            ? Math.floor(item.day)
            : 1;
        const itemLevel =
          typeof item.level === 'number' && Number.isFinite(item.level) && item.level >= 1
            ? Math.floor(item.level)
            : undefined;
        out.push({
          uid: item.uid,
          shopName:
            typeof item.shopName === 'string' && item.shopName
              ? item.shopName.slice(0, 80)
              : 'Tiệm Trái Cây',
          money:
            typeof item.money === 'number' && Number.isFinite(item.money)
              ? Math.round(item.money)
              : 0,
          day: itemDay,
          ...(itemLevel ? { level: itemLevel } : {}),
          fingerprint: typeof item.fingerprint === 'string' ? item.fingerprint : '',
          updatedAt: typeof item.updatedAt === 'number' ? item.updatedAt : 0,
          ...(vTag ? { vTag } : {}),
          ...(cTag ? { cTag } : {}),
          ...(av ? { av } : {}),
          ...(pet ? { pet } : {}),
        });
      }
    }
    return out;
  }

  private async readRawLeaderboardDoc(
    docId: 'global',
    forceServer = false,
  ): Promise<{ exists: boolean; entries: LeaderboardEntry[] }> {
    const refDoc = doc(db, 'leaderboards', docId);
    let snap;
    if (forceServer) {
      try {
        snap = await getDocFromServer(refDoc);
      } catch {
        snap = await getDoc(refDoc);
      }
    } else {
      snap = await getDoc(refDoc);
    }
    if (!snap.exists()) return { exists: false, entries: [] };
    return {
      exists: true,
      entries: this.parseLeaderboardEntriesList(snap.data()?.entries),
    };
  }

  // Đọc danh sách từ 1 Document tổng duy nhất /leaderboards/global (dùng chung cho cả BXH Tài sản, BXH Ngày chơi và kiểm tra vân tay)
  private async readGlobalLeaderboardEntries(forceServer = false): Promise<LeaderboardEntry[]> {
    if (!forceServer && this.leaderboard.length > 0 && Date.now() - this.lastLbFetchAt < 60000) {
      return this.leaderboard;
    }
    const globalRes = await this.readRawLeaderboardDoc('global', forceServer).catch(() => ({
      exists: false,
      entries: [] as LeaderboardEntry[],
    }));
    return globalRes.entries;
  }

  // Dùng chung dữ liệu từ /leaderboards/global cho Bảng xếp hạng Số Ngày Đã Chơi (không đọc thêm document thứ 2)
  private async readDaysLeaderboardEntries(forceServer = false): Promise<LeaderboardEntry[]> {
    return this.readGlobalLeaderboardEntries(forceServer);
  }

  private async getClaimedOwnerFromGlobalDoc(fingerprint: string): Promise<string | null> {
    if (!fingerprint) return null;
    try {
      if (rtdb) {
        const fpSnap = await get(ref(rtdb, `refCodes/FP_OWN_${fingerprint}`)).catch(() => null);
        if (fpSnap && fpSnap.exists()) {
          const ownerFromRtdb = String(fpSnap.val() || '').trim();
          if (ownerFromRtdb) return ownerFromRtdb;
        }
      }
      // Nếu trong bộ nhớ tạm đã có sẵn BXH thì tra cứu trực tiếp trong RAM, tuyệt đối không gọi đọc Firestore
      if (this.leaderboard.length > 0) {
        const cachedFound = this.leaderboard.find((e) => e.fingerprint === fingerprint);
        return cachedFound ? cachedFound.uid : null;
      }
      return null;
    } catch {
      return null;
    }
  }

  private canLocalOverwriteOrConflictWithAccount(
    local: LocalExportData,
    uid: string,
    cloudData: AccountDoc | null,
    claimedOwner: string | null,
  ): boolean {
    if ((local.ownerUid && local.ownerUid !== uid) || (claimedOwner && claimedOwner !== uid)) {
      return false;
    }
    if (cloudData && cloudData.saveCode) {
      const isSameAccount =
        local.ownerUid === uid ||
        claimedOwner === uid ||
        Boolean(cloudData.fingerprint && local.fingerprint === cloudData.fingerprint);
      if (!isSameAccount) {
        return false;
      }
    }
    return true;
  }

  async verifyUnauthenticatedLocalSave(): Promise<void> {
    if (!this.bridge || !this.authReady || this.user) return;
    const local = this.bridge.getLocalExport();
    if (!local || !local.fingerprint) return;

    if (local.ownerUid) {
      this.bridge.clearLocalSaveOnLogout();
      this.emit();
      return;
    }

    const claimedOwner = await this.getClaimedOwnerFromGlobalDoc(local.fingerprint);
    if (claimedOwner && !this.user) {
      this.bridge.clearLocalSaveOnLogout();
      this.emit();
    }
  }

  async checkCanImportRawJson(rawJson: string): Promise<{ allowed: boolean; reason?: string }> {
    if (this.user) {
      return {
        allowed: false,
        reason: 'Bạn đang đăng nhập Google Đám mây nên tính năng nhập mã/file đã được khóa.',
      };
    }
    const { fingerprint, ownerUid } = computeSaveFingerprintFromJson(rawJson);
    if (ownerUid) {
      return {
        allowed: false,
        reason:
          'Tiệm trong mã/file này đã liên kết với tài khoản Google! Mã/file cũ đã bị vô hiệu hóa — vui lòng bấm "Đăng nhập bằng Google" để tải tiệm.',
      };
    }
    if (!fingerprint) {
      return { allowed: true };
    }
    try {
      const claimedOwner = await this.getClaimedOwnerFromGlobalDoc(fingerprint);
      if (claimedOwner) {
        return {
          allowed: false,
          reason:
            'Tiệm trong mã/file này đã được liên kết với tài khoản Google! Mã/file cũ đã bị vô hiệu hóa — vui lòng bấm "Đăng nhập bằng Google" để tải tiệm nha.',
        };
      }
      return { allowed: true };
    } catch {
      return {
        allowed: false,
        reason:
          'Cần có kết nối mạng để xác thực mã/file tiệm chưa bị khóa bởi tài khoản Google khác. Vui lòng kiểm tra mạng rồi thử lại nha!',
      };
    }
  }

  async signInWithGoogle(): Promise<void> {
    if (this.syncing) return;

    // Kích hoạt signInWithPopup NGAY LẬP TỨC trong khung sự kiện click trực tiếp của người dùng
    // (tránh re-render trước làm trình duyệt điện thoại/Safari coi là popup không mong muốn và chặn lại)
    let popupPromise: Promise<any>;
    try {
      popupPromise = signInWithPopup(auth, googleProvider);
    } catch (e: any) {
      if (e?.code === 'auth/popup-blocked') {
        this.bridge?.notify(
          'Trình duyệt đang chặn cửa sổ đăng nhập. Vui lòng cho phép "Cửa sổ bật lên" (Pop-up) rồi thử lại nha!',
          'bad',
        );
      }
      return;
    }

    this.syncing = true;
    this.emit();

    try {
      const cred = await popupPromise;
      if (cred.user) {
        await this.reconcileAfterAuth(cred.user, true);
      }
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/popup-closed-by-user') {
        this.bridge?.notify('Cửa sổ đăng nhập đã đóng. Hãy bấm lại nếu bạn muốn đăng nhập nha.', 'info');
      } else if (code === 'auth/popup-blocked') {
        this.bridge?.notify(
          'Trình duyệt đang chặn cửa sổ đăng nhập. Vui lòng bật "Cho phép cửa sổ bật lên" trong cài đặt trình duyệt nha!',
          'bad',
        );
      } else if (code === 'auth/unauthorized-domain') {
        this.bridge?.notify(
          'Tên miền web này chưa được thêm vào Authorized Domains trên Firebase Console.',
          'bad',
        );
      } else if (code === 'auth/cancelled-popup-request') {
        // Đã có yêu cầu đăng nhập khác đang xử lý, bỏ qua
      } else {
        this.bridge?.notify(
          'Đăng nhập Google chưa thành công. Hãy kiểm tra kết nối mạng hoặc thử lại nha!',
          'bad',
        );
      }
    } finally {
      this.syncing = false;
      this.emit();
    }
  }

  private normalizeIdentifierToEmail(identifier: string): {
    email: string;
    isUsername: boolean;
    cleanIdentifier: string;
  } {
    const clean = (identifier || '').trim().toLowerCase();
    if (!clean) return { email: '', isUsername: false, cleanIdentifier: '' };
    if (clean.includes('@')) {
      return { email: clean, isUsername: false, cleanIdentifier: clean };
    }
    // Chuẩn hóa tên đăng nhập: bỏ dấu tiếng Việt & khoảng trắng
    const slug = clean
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/[^a-z0-9_.-]/g, '');
    if (slug.length < 3) {
      return { email: '', isUsername: true, cleanIdentifier: slug };
    }
    return {
      email: `${slug}@account.tiemtraicay.game`,
      isUsername: true,
      cleanIdentifier: slug,
    };
  }

  getDisplayAccountLabel(u?: User | null): string {
    const target = u !== undefined ? u : this.user;
    if (!target) return '';
    if (target.displayName) return target.displayName;
    const em = target.email || '';
    if (em.endsWith('@account.tiemtraicay.game')) {
      return `ID: ${em.replace('@account.tiemtraicay.game', '')}`;
    }
    return em || 'Tài khoản Đám mây';
  }

  async signInWithAccountPassword(identifier: string, password: string): Promise<boolean> {
    if (this.syncing) return false;
    const { email, isUsername, cleanIdentifier } = this.normalizeIdentifierToEmail(identifier);
    if (!email) {
      this.bridge?.notify(
        isUsername
          ? 'Tên đăng nhập cần tối thiểu 3 ký tự (chữ hoặc số, không dấu) nha!'
          : 'Vui lòng nhập Gmail hoặc Tên đăng nhập hợp lệ nha!',
        'bad',
      );
      return false;
    }
    if (!password || password.length < 6) {
      this.bridge?.notify('Mật khẩu cần có ít nhất 6 ký tự nha!', 'bad');
      return false;
    }

    this.syncing = true;
    this.emit();
    try {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      if (cred.user) {
        await this.reconcileAfterAuth(cred.user, true);
      }
      return true;
    } catch (err: any) {
      const code = err?.code || '';
      if (
        code === 'auth/user-not-found' ||
        code === 'auth/wrong-password' ||
        code === 'auth/invalid-credential' ||
        code === 'auth/invalid-login-credentials'
      ) {
        this.bridge?.notify(
          isUsername
            ? `Tên đăng nhập "${cleanIdentifier}" hoặc mật khẩu chưa chính xác!`
            : 'Gmail hoặc mật khẩu chưa chính xác! Nếu bạn chưa có tài khoản, hãy chuyển sang mục "Đăng ký mới" nha.',
          'bad',
        );
      } else if (code === 'auth/invalid-email') {
        this.bridge?.notify('Định dạng Gmail hoặc Tên đăng nhập không hợp lệ!', 'bad');
      } else if (code === 'auth/too-many-requests') {
        this.bridge?.notify(
          'Bạn đã nhập sai quá nhiều lần. Vui lòng đợi ít phút rồi thử lại nha!',
          'bad',
        );
      } else {
        this.bridge?.notify(
          'Thông tin tài khoản hoặc mật khẩu chưa chính xác, vui lòng kiểm tra lại nha!',
          'bad',
        );
      }
      return false;
    } finally {
      this.syncing = false;
      this.emit();
    }
  }

  async registerWithAccountPassword(
    identifier: string,
    password: string,
    confirmPassword?: string,
  ): Promise<boolean> {
    if (this.syncing) return false;
    const { email, isUsername, cleanIdentifier } = this.normalizeIdentifierToEmail(identifier);
    if (!email) {
      this.bridge?.notify(
        isUsername
          ? 'Tên đăng nhập cần tối thiểu 3 ký tự (chữ hoặc số, không dấu) nha!'
          : 'Vui lòng nhập Gmail hoặc Tên đăng nhập hợp lệ nha!',
        'bad',
      );
      return false;
    }
    if (!password || password.length < 6) {
      this.bridge?.notify('Mật khẩu cần có ít nhất 6 ký tự để bảo mật nha!', 'bad');
      return false;
    }
    if (confirmPassword !== undefined && password !== confirmPassword) {
      this.bridge?.notify('Mật khẩu nhập lại không khớp!', 'bad');
      return false;
    }

    this.syncing = true;
    this.emit();
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      if (cred.user) {
        if (isUsername) {
          await updateProfile(cred.user, { displayName: cleanIdentifier }).catch(() => undefined);
        }
        await this.reconcileAfterAuth(cred.user, true);
      }
      return true;
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/email-already-in-use' || code === 'auth/credential-already-in-use') {
        this.bridge?.notify(
          isUsername
            ? `Tên đăng nhập "${cleanIdentifier}" đã có người sử dụng! Hãy chọn tên khác hoặc bấm sang "Đăng nhập" nha.`
            : 'Gmail này đã được đăng ký trước đó! Hãy chuyển sang mục "Đăng nhập" nha.',
          'bad',
        );
      } else if (code === 'auth/invalid-email') {
        this.bridge?.notify('Định dạng Gmail hoặc Tên đăng nhập không hợp lệ!', 'bad');
      } else if (code === 'auth/weak-password') {
        this.bridge?.notify('Mật khẩu quá yếu, vui lòng nhập ít nhất 6 ký tự nha!', 'bad');
      } else {
        this.bridge?.notify(
          'Không thể tạo tài khoản lúc này, vui lòng kiểm tra lại thông tin rồi thử lại nha!',
          'bad',
        );
      }
      return false;
    } finally {
      this.syncing = false;
      this.emit();
    }
  }

  async resetAccountPassword(identifier: string): Promise<boolean> {
    const clean = (identifier || '').trim().toLowerCase();
    if (!clean || !clean.includes('@') || clean.endsWith('@account.tiemtraicay.game')) {
      this.bridge?.notify(
        'Vui lòng nhập địa chỉ Gmail thật đã đăng ký để nhận thư đặt lại mật khẩu nha!',
        'bad',
      );
      return false;
    }
    try {
      await sendPasswordResetEmail(auth, clean);
      this.bridge?.notify(
        `Đã gửi liên kết đặt lại mật khẩu tới hộp thư ${clean}! Bạn kiểm tra cả mục Hộp thư đến và Thư rác (Spam) nhé.`,
        'good',
      );
      return true;
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/user-not-found') {
        this.bridge?.notify('Không tìm thấy tài khoản nào đăng ký với Gmail này!', 'bad');
      } else {
        this.bridge?.notify('Chưa gửi được yêu cầu đặt lại mật khẩu, vui lòng kiểm tra lại Gmail nha!', 'bad');
      }
      return false;
    }
  }

  async signOutGoogle(): Promise<void> {
    const wasBanned = this.isCurrentAccountBanned;
    const wasKicked = this.isKickedByOtherDevice;
    if (this.syncing && !wasBanned && !wasKicked) return;
    if (this.autoSyncTimer) {
      clearTimeout(this.autoSyncTimer);
      this.autoSyncTimer = null;
    }
    this.syncing = true;
    if (wasBanned) {
      this.isCurrentAccountBanned = false;
    }
    if (wasKicked) {
      this.isKickedByOtherDevice = false;
    }
    this.emit();
    try {
      if (!wasBanned && !wasKicked && this.user && this.bridge) {
        const local = this.bridge.getLocalExport();
        if (local && (!local.ownerUid || local.ownerUid === this.user.uid)) {
          await this.uploadLocalToCloud(this.user.uid, local, false).catch(() => undefined);
        }
      }
      this.conflict = null;
      this.lastAutoSyncHash = '';
      this._lastSyncedAtMem = 0;
      this._lastManualSyncAtMem = 0;
      try {
        localStorage.removeItem('ttc_cloud_last_synced_at');
        localStorage.removeItem('ttc_cloud_last_manual_sync_at');
        localStorage.removeItem('ttc_cloud_last_auto_saved_day');
      } catch {}
      this.isCurrentAccountBanned = false;
      this.isKickedByOtherDevice = false;
      this.stopCoupleRealtime();
      await signOut(auth).catch(() => undefined);
      this.user = null;
      this.isCurrentAccountBanned = false;
      this.isKickedByOtherDevice = false;
      this.bridge?.clearLocalSaveOnLogout();
      this.bridge?.notify(
        wasBanned || wasKicked
          ? 'Đã đăng xuất tài khoản.'
          : 'Đã lưu tiệm lên Đám mây và đăng xuất. Đăng nhập lại bất cứ lúc nào để mở tiệm nha!',
        'info',
      );
    } finally {
      this.isCurrentAccountBanned = false;
      this.isKickedByOtherDevice = false;
      this.syncing = false;
      this.emit();
    }
  }

  private hydrateCloudDocMeta(cloudData: AccountDoc | null): AccountDoc | null {
    if (!cloudData) return null;
    const uAt = cloudData.updatedAt as any;
    const cAt = cloudData.createdAt as any;
    const ms =
      typeof uAt?.toMillis === 'function'
        ? uAt.toMillis()
        : typeof uAt?.seconds === 'number'
          ? uAt.seconds * 1000
          : typeof cAt?.toMillis === 'function'
            ? cAt.toMillis()
            : typeof cAt?.seconds === 'number'
              ? cAt.seconds * 1000
              : 0;
    const decoded =
      cloudData.saveCode && this.bridge?.decodeSaveCodeMeta
        ? this.bridge.decodeSaveCodeMeta(cloudData.saveCode)
        : null;
    const rev =
      typeof cloudData.revision === 'number' && cloudData.revision > 0
        ? Math.floor(cloudData.revision)
        : decoded && typeof decoded.revision === 'number' && decoded.revision > 0
          ? Math.floor(decoded.revision)
          : 0;
    const codeSavedAt =
      decoded && typeof decoded.savedAt === 'number' && decoded.savedAt > 0
        ? decoded.savedAt
        : 0;
    const savedAt = codeSavedAt > 0 ? codeSavedAt : ms > 0 ? ms : 0;
    cloudData.revision = rev;
    cloudData.savedAt = savedAt;
    cloudData.updatedAtMs = ms > 0 ? ms : savedAt;
    return cloudData;
  }

  private isSaveConflict(local: LocalExportData, cloud: AccountDoc): boolean {
    if (local.fingerprint !== cloud.fingerprint) return true;
    const localRev =
      typeof local.revision === 'number' && local.revision > 0 ? Math.floor(local.revision) : 0;
    const cloudRev =
      typeof cloud.revision === 'number' && cloud.revision > 0 ? Math.floor(cloud.revision) : 0;
    if (cloudRev > 0 && localRev < cloudRev) return true;
    const localLevel = Math.max(1, Math.floor(local.summary?.level || 1));
    const cloudLevel = Math.max(1, Math.floor(cloud.level || 1));
    if (localLevel < cloudLevel) return true;
    const localDay = Math.max(1, Math.floor(local.summary?.day || 1));
    const cloudDay = Math.max(1, Math.floor(cloud.day || 1));
    if (localDay < cloudDay) return true;
    return false;
  }

  private isLocalAheadOfCloud(local: LocalExportData, cloud: AccountDoc): boolean {
    if (local.fingerprint !== cloud.fingerprint) return false;
    const localLevel = Math.max(1, Math.floor(local.summary?.level || 1));
    const cloudLevel = Math.max(1, Math.floor(cloud.level || 1));
    if (localLevel > cloudLevel) return true;
    if (localLevel < cloudLevel) return false;
    const localDay = Math.max(1, Math.floor(local.summary?.day || 1));
    const cloudDay = Math.max(1, Math.floor(cloud.day || 1));
    if (localDay > cloudDay) return true;
    if (localDay < cloudDay) return false;
    const localRev =
      typeof local.revision === 'number' && local.revision > 0 ? Math.floor(local.revision) : 0;
    const cloudRev =
      typeof cloud.revision === 'number' && cloud.revision > 0 ? Math.floor(cloud.revision) : 0;
    if (localRev > cloudRev) return true;
    if (cloudRev > 0 && localRev < cloudRev) return false;
    const localSavedAt = typeof local.savedAt === 'number' ? local.savedAt : 0;
    const cloudSavedAt = cloud.savedAt || cloud.updatedAtMs || 0;
    if (localSavedAt > cloudSavedAt + 1500 && local.code !== cloud.saveCode) return true;
    const localMoney = Math.round(local.summary?.money || 0);
    const cloudMoney = Math.round(cloud.money || 0);
    if (localMoney !== cloudMoney && localSavedAt >= cloudSavedAt) return true;
    if (
      local.code &&
      cloud.saveCode &&
      local.code !== cloud.saveCode &&
      localRev >= cloudRev &&
      localSavedAt >= cloudSavedAt
    ) {
      return true;
    }
    return false;
  }

  private computeAutoSyncHash(
    fingerprint: string,
    day?: number,
    level?: number,
    _money?: number,
  ): string {
    const d = Math.max(1, Math.floor(day || 1));
    const lv = Math.max(1, Math.floor(level || 1));
    return `${fingerprint}:${d}:${lv}`;
  }

  private async saveAccountBackupToRtdb(
    uid: string,
    payload: {
      ownerUid: string;
      fingerprint: string;
      shopName: string;
      day: number;
      money: number;
      level: number;
      saveCode: string;
      revision: number;
      savedAt: number;
    },
  ): Promise<boolean> {
    if (!rtdb || !uid) return false;
    try {
      await update(ref(rtdb, `referrals/${uid}`), {
        cloudSave: {
          ownerUid: uid,
          fingerprint: payload.fingerprint,
          shopName: payload.shopName,
          day: payload.day,
          money: payload.money,
          level: payload.level,
          saveCode: payload.saveCode,
          revision: payload.revision,
          savedAt: payload.savedAt,
          updatedAtMs: payload.savedAt,
        },
        updatedAt: payload.savedAt,
      });
      return true;
    } catch {
      return false;
    }
  }

  private async readAccountWithRtdbFallback(uid: string): Promise<{
    accountSnap: any;
    cloudData: AccountDoc | null;
  }> {
    const accountRef = doc(db, 'accounts', uid);
    const [accountSnap, rtdbSnap] = await Promise.all([
      getDocFromServer(accountRef)
        .catch(() => getDoc(accountRef))
        .catch(() => null),
      rtdb ? get(ref(rtdb, `referrals/${uid}/cloudSave`)).catch(() => null) : Promise.resolve(null),
    ]);

    const fsDoc =
      accountSnap && typeof accountSnap.exists === 'function' && accountSnap.exists()
        ? this.hydrateCloudDocMeta(accountSnap.data() as AccountDoc)
        : null;

    let rtdbDoc: AccountDoc | null = null;
    if (rtdbSnap && typeof rtdbSnap.exists === 'function' && rtdbSnap.exists()) {
      const val = rtdbSnap.val();
      if (val && typeof val === 'object' && typeof val.saveCode === 'string' && val.saveCode) {
        rtdbDoc = this.hydrateCloudDocMeta({
          ownerUid: String(val.ownerUid || uid),
          fingerprint: String(val.fingerprint || ''),
          shopName: String(val.shopName || 'Tiệm Trái Cây'),
          day: Math.max(1, Math.floor(Number(val.day) || 1)),
          money: Math.round(Number(val.money) || 0),
          level: Math.max(1, Math.floor(Number(val.level) || 1)),
          saveCode: val.saveCode,
          revision: Math.max(0, Math.floor(Number(val.revision) || 0)),
          savedAt: Math.max(0, Math.floor(Number(val.savedAt || val.updatedAtMs) || 0)),
          updatedAtMs: Math.max(0, Math.floor(Number(val.updatedAtMs || val.savedAt) || 0)),
        } as AccountDoc);
      }
    }

    if (fsDoc && rtdbDoc) {
      const fsRev = fsDoc.revision || 0;
      const rtRev = rtdbDoc.revision || 0;
      const fsDay = fsDoc.day || 1;
      const rtDay = rtdbDoc.day || 1;
      const fsTime = fsDoc.updatedAtMs || fsDoc.savedAt || 0;
      const rtTime = rtdbDoc.updatedAtMs || rtdbDoc.savedAt || 0;
      if (
        rtRev > fsRev ||
        (rtRev === fsRev && rtDay > fsDay) ||
        (rtRev === fsRev && rtDay === fsDay && rtTime > fsTime)
      ) {
        return { accountSnap, cloudData: rtdbDoc };
      }
      return { accountSnap, cloudData: fsDoc };
    }

    return { accountSnap, cloudData: fsDoc || rtdbDoc };
  }

  async resumeSessionOnThisDevice(): Promise<void> {
    if (!this.user || !this.bridge || this.syncing || this.isCurrentAccountBanned) return;
    const uid = this.user.uid;
    this.syncing = true;
    this.emit();
    try {
      const preloadedAccount = await this.readAccountWithRtdbFallback(uid);
      const { cloudData } = preloadedAccount;

      const local = this.bridge.getLocalExport();
      if (cloudData && cloudData.saveCode) {
        const cloudTs = cloudData.savedAt || cloudData.updatedAtMs || 0;
        if (!local || !local.fingerprint) {
          if (this.bridge.applyCloudSaveCode(cloudData.saveCode, uid)) {
            this.bridge.stampCloudRevision?.(
              Math.max(1, cloudData.revision || 1),
              cloudTs || this.lastSyncedAt || Date.now(),
            );
            if (cloudTs > 0) this.lastSyncedAt = cloudTs;
            this.lastAutoSyncedDay = cloudData.day || 0;
            this.lastAutoSyncHash = this.computeAutoSyncHash(
              cloudData.fingerprint,
              cloudData.day,
              cloudData.level,
              cloudData.money,
            );
          }
        } else {
          const isAlreadyKnownSameOwner =
            local.ownerUid === uid ||
            Boolean(cloudData.fingerprint && local.fingerprint === cloudData.fingerprint);
          const claimedOwner = isAlreadyKnownSameOwner
            ? uid
            : await this.getClaimedOwnerFromGlobalDoc(local.fingerprint);
          if (!this.canLocalOverwriteOrConflictWithAccount(local, uid, cloudData, claimedOwner)) {
            this.bridge.clearLocalSaveOnLogout();
            if (this.bridge.applyCloudSaveCode(cloudData.saveCode, uid)) {
              this.bridge.stampCloudRevision?.(
                Math.max(1, cloudData.revision || 1),
                cloudTs || this.lastSyncedAt || Date.now(),
              );
              if (cloudTs > 0) this.lastSyncedAt = cloudTs;
              this.lastAutoSyncedDay = cloudData.day || 0;
              this.lastAutoSyncHash = this.computeAutoSyncHash(
                cloudData.fingerprint,
                cloudData.day,
                cloudData.level,
                cloudData.money,
              );
            }
          } else if (this.isSaveConflict(local, cloudData)) {
            this.conflict = { local, cloud: cloudData };
          } else if (this.isLocalAheadOfCloud(local, cloudData)) {
            const localDay = Math.max(1, Math.floor(local.summary?.day || 1));
            const cloudDay = Math.max(1, Math.floor(cloudData.day || 1));
            const localLevel = Math.max(1, Math.floor(local.summary?.level || 1));
            const cloudLevel = Math.max(1, Math.floor(cloudData.level || 1));
            if (localDay - cloudDay >= 2 || localLevel > cloudLevel) {
              await this.uploadLocalToCloud(uid, local, false, true, preloadedAccount).catch(
                () => undefined,
              );
            } else {
              this.bridge.stampLocalOwnerUid(uid);
              const syncedRev = Math.max(1, local.revision || 0, cloudData.revision || 0);
              this.bridge.stampCloudRevision?.(
                syncedRev,
                Math.max(cloudTs || 0, local.savedAt || 0) || this.lastSyncedAt || Date.now(),
              );
              if (cloudTs > 0) this.lastSyncedAt = cloudTs;
              this.lastAutoSyncedDay = cloudData.day || 0;
              this.lastAutoSyncHash = this.computeAutoSyncHash(
                cloudData.fingerprint,
                cloudData.day,
                cloudData.level,
                cloudData.money,
              );
            }
          } else if (local.fingerprint === cloudData.fingerprint) {
            this.bridge.stampLocalOwnerUid(uid);
            const syncedRev = Math.max(1, local.revision || 0, cloudData.revision || 0);
            this.bridge.stampCloudRevision?.(
              syncedRev,
              Math.max(cloudTs || 0, local.savedAt || 0) || this.lastSyncedAt || Date.now(),
            );
            if (cloudTs > 0) this.lastSyncedAt = cloudTs;
            this.lastAutoSyncedDay = cloudData.day || 0;
            this.lastAutoSyncHash = this.computeAutoSyncHash(
              cloudData.fingerprint,
              cloudData.day,
              cloudData.level,
              cloudData.money,
            );
          } else if (this.bridge.applyCloudSaveCode(cloudData.saveCode, uid)) {
            this.bridge.stampCloudRevision?.(
              Math.max(1, cloudData.revision || 1),
              cloudTs || this.lastSyncedAt || Date.now(),
            );
            if (cloudTs > 0) this.lastSyncedAt = cloudTs;
            this.lastAutoSyncedDay = cloudData.day || 0;
            this.lastAutoSyncHash = this.computeAutoSyncHash(
              cloudData.fingerprint,
              cloudData.day,
              cloudData.level,
              cloudData.money,
            );
          }
        }
      }

      this.claimActiveSession(uid);
      if (this.isCoupleRealtimeModalOpen()) {
        this.startCoupleRealtime(uid);
      } else {
        this.syncUserAndNoticesOnce(uid).catch(() => undefined);
      }
      if (this.lotteryUnsubs.length > 0) {
        this.startLotteryDrawSync(true);
      }
      this.bridge.notify(
        cloudData
          ? `Đã đồng bộ dữ liệu mới nhất của tiệm "${cloudData.shopName}" (Ngày ${cloudData.day}) và tiếp tục trên thiết bị này!`
          : 'Đã kích hoạt lại phiên chơi trên thiết bị này!',
        'good',
      );
    } catch {
      this.claimActiveSession(uid);
      if (this.lotteryUnsubs.length > 0) {
        this.startLotteryDrawSync(true);
      }
      this.bridge.notify('Đã kích hoạt lại phiên chơi trên thiết bị này!', 'good');
    } finally {
      this.syncing = false;
      this.emit();
    }
  }

  private async reconcileAfterAuth(u: User, interactive: boolean): Promise<void> {
    if (!this.bridge || (this.syncing && !interactive)) return;
    this.syncing = true;
    this.emit();
    try {
      const uid = u.uid;
      if (this.isCurrentAccountBanned || this.isUidBanned(uid)) {
        this.isCurrentAccountBanned = true;
        this.bridge.clearLocalSaveOnLogout();
        this.emit();
        return;
      }
      if (interactive || this.isKickedByOtherDevice) {
        this.claimActiveSession(uid);
      }
      // Mỗi tài khoản có 1 Document riêng duy nhất tại /accounts/{uid} (kèm dự phòng RTDB)
      const preloadedAccount = await this.readAccountWithRtdbFallback(uid);
      const { cloudData } = preloadedAccount;
      const local = this.bridge.getLocalExport();

      if (local && local.fingerprint) {
        const isAlreadyKnownSameOwner =
          local.ownerUid === uid ||
          Boolean(cloudData && cloudData.fingerprint && local.fingerprint === cloudData.fingerprint);
        const claimedOwner = isAlreadyKnownSameOwner
          ? uid
          : await this.getClaimedOwnerFromGlobalDoc(local.fingerprint);
        const isForeignOwner =
          (local.ownerUid && local.ownerUid !== uid) || (claimedOwner && claimedOwner !== uid);
        if (
          isForeignOwner ||
          !this.canLocalOverwriteOrConflictWithAccount(local, uid, cloudData, claimedOwner)
        ) {
          this.bridge.clearLocalSaveOnLogout();
          if (isForeignOwner) {
            this.bridge.notify(
              'Dữ liệu tiệm trên máy này đã thuộc sở hữu của một tài khoản Google khác nên không thể ghi đè sang tài khoản này!',
              'bad',
            );
          }
          if (cloudData && cloudData.saveCode) {
            const cloudTs = cloudData.savedAt || cloudData.updatedAtMs || 0;
            if (this.bridge.applyCloudSaveCode(cloudData.saveCode, uid)) {
              this.bridge.stampCloudRevision?.(
                Math.max(1, cloudData.revision || 1),
                cloudTs || this.lastSyncedAt || Date.now(),
              );
              if (cloudTs > 0) this.lastSyncedAt = cloudTs;
              this.lastAutoSyncedDay = cloudData.day || 0;
              this.lastAutoSyncHash = this.computeAutoSyncHash(
                cloudData.fingerprint,
                cloudData.day,
                cloudData.level,
                cloudData.money,
              );
              if (!isForeignOwner) {
                this.bridge.notify(
                  `Đã khôi phục tiệm "${cloudData.shopName}" (Ngày ${cloudData.day}) từ Đám mây!`,
                  'good',
                );
              }
            }
          }
          return;
        }
      }

      if (!cloudData) {
        if (local && local.fingerprint) {
          await this.uploadLocalToCloud(uid, local, true, true, preloadedAccount);
          this.bridge.notify(
            `Đã liên kết Google & lưu tiệm "${local.summary.shopName}" lên Đám mây!`,
            'good',
          );
        } else if (interactive) {
          this.bridge.notify(
            'Đã đăng nhập Google! Hãy mở tiệm mới để tự động lưu Đám mây nha.',
            'good',
          );
        }
        return;
      }

      const cloudTs = cloudData.savedAt || cloudData.updatedAtMs || 0;

      if (!local || !local.fingerprint) {
        if (this.bridge.applyCloudSaveCode(cloudData.saveCode, uid)) {
          this.bridge.stampCloudRevision?.(
            Math.max(1, cloudData.revision || 1),
            cloudTs || this.lastSyncedAt || Date.now(),
          );
          if (cloudTs > 0) this.lastSyncedAt = cloudTs;
          this.lastAutoSyncedDay = cloudData.day || 0;
          this.lastAutoSyncHash = this.computeAutoSyncHash(
            cloudData.fingerprint,
            cloudData.day,
            cloudData.level,
            cloudData.money,
          );
          this.bridge.notify(
            `Đã khôi phục tiệm "${cloudData.shopName}" (Ngày ${cloudData.day}) từ Đám mây!`,
            'good',
          );
        }
        return;
      }

      if (!this.isSaveConflict(local, cloudData)) {
        // Không có xung đột revision hay lùi cấp độ/ngày chơi
        this.bridge.stampLocalOwnerUid(uid);
        const localDay = Math.max(1, Math.floor(local.summary?.day || 1));
        const cloudDay = Math.max(1, Math.floor(cloudData.day || 1));
        const localLevel = Math.max(1, Math.floor(local.summary?.level || 1));
        const cloudLevel = Math.max(1, Math.floor(cloudData.level || 1));
        if (
          this.isLocalAheadOfCloud(local, cloudData) &&
          (localDay - cloudDay >= 2 || localLevel > cloudLevel)
        ) {
          await this.uploadLocalToCloud(uid, local, false, true, preloadedAccount).catch(
            () => undefined,
          );
          if (interactive) {
            this.bridge.notify(
              `Đã đồng bộ tiến trình mới nhất của tiệm "${local.summary.shopName}" lên Đám mây!`,
              'good',
            );
          }
          return;
        }
        const syncedRev = Math.max(1, local.revision || 0, cloudData.revision || 0);
        this.bridge.stampCloudRevision?.(
          syncedRev,
          Math.max(cloudTs || 0, local.savedAt || 0) || this.lastSyncedAt || Date.now(),
        );
        if (cloudTs > 0) this.lastSyncedAt = cloudTs;
        this.lastAutoSyncedDay = cloudData.day || 0;
        this.lastAutoSyncHash = this.computeAutoSyncHash(
          cloudData.fingerprint,
          cloudData.day,
          cloudData.level,
          cloudData.money,
        );
        if (interactive) {
          this.bridge.notify(`Đã đồng bộ tiệm "${cloudData.shopName}" với Đám mây!`, 'good');
        }
        return;
      }

      this.conflict = {
        local,
        cloud: cloudData,
      };
      this.emit();
    } catch (err) {
      console.error('[cloud] reconcile error', err);
    } finally {
      this.syncing = false;
      this.emit();
    }
  }

  async resolveConflictUseLocal(): Promise<void> {
    if (!this.conflict || !this.user || !this.bridge) return;
    const { local, cloud } = this.conflict;
    const uid = this.user.uid;
    this.syncing = true;
    this.emit();
    try {
      const claimedOwner = await this.getClaimedOwnerFromGlobalDoc(local.fingerprint);
      if (!this.canLocalOverwriteOrConflictWithAccount(local, uid, cloud, claimedOwner)) {
        this.conflict = null;
        this.bridge.clearLocalSaveOnLogout();
        if (cloud && cloud.saveCode && this.bridge.applyCloudSaveCode(cloud.saveCode, uid)) {
          const cloudTs = cloud.savedAt || cloud.updatedAtMs || 0;
          this.bridge.stampCloudRevision?.(
            Math.max(1, cloud.revision || 1),
            cloudTs || this.lastSyncedAt || Date.now(),
          );
          if (cloudTs > 0) this.lastSyncedAt = cloudTs;
          this.lastAutoSyncedDay = cloud.day || 0;
          this.lastAutoSyncHash = this.computeAutoSyncHash(
            cloud.fingerprint,
            cloud.day,
            cloud.level,
            cloud.money,
          );
        }
        this.bridge.notify(
          'Chỉ dữ liệu thuộc cùng một tài khoản mới có thể ghi đè! Đã khôi phục dữ liệu của tài khoản hiện tại.',
          'bad',
        );
        return;
      }
      await this.uploadLocalToCloud(uid, local, false, true);
      this.conflict = null;
      this.bridge.notify(
        `Đã xác nhận giữ tiệm trên máy ("${local.summary.shopName}") và ghi đè lên Đám mây!`,
        'good',
      );
    } catch {
      this.bridge.notify('Chưa lưu lên Đám mây được, vui lòng thử lại nha.', 'bad');
    } finally {
      this.syncing = false;
      this.emit();
    }
  }

  async resolveConflictUseCloud(): Promise<void> {
    if (!this.conflict || !this.user || !this.bridge) return;
    const { cloud } = this.conflict;
    const uid = this.user.uid;
    this.syncing = true;
    this.emit();
    try {
      const ok = this.bridge.applyCloudSaveCode(cloud.saveCode, uid);
      if (ok) {
        const cloudTs = cloud.savedAt || cloud.updatedAtMs || 0;
        this.bridge.stampCloudRevision?.(
          Math.max(1, cloud.revision || 1),
          cloudTs || this.lastSyncedAt || Date.now(),
        );
        this.conflict = null;
        if (cloudTs > 0) this.lastSyncedAt = cloudTs;
        this.lastAutoSyncedDay = cloud.day || 0;
        this.lastAutoSyncHash = this.computeAutoSyncHash(
          cloud.fingerprint,
          cloud.day,
          cloud.level,
          cloud.money,
        );
        this.bridge.notify(
          `Đã tải tiệm "${cloud.shopName}" (Ngày ${cloud.day} · Lv.${cloud.level}) từ Đám mây về máy!`,
          'good',
        );
      } else {
        this.bridge.notify('Không đọc được bản lưu trên Đám mây.', 'bad');
      }
    } finally {
      this.syncing = false;
      this.emit();
    }
  }

  async cancelConflictAndSignOut(): Promise<void> {
    this.conflict = null;
    this.syncing = true;
    if (this.autoSyncTimer) {
      clearTimeout(this.autoSyncTimer);
      this.autoSyncTimer = null;
    }
    this.lastAutoSyncHash = '';
    this._lastSyncedAtMem = 0;
    this._lastManualSyncAtMem = 0;
    try {
      localStorage.removeItem('ttc_cloud_last_synced_at');
      localStorage.removeItem('ttc_cloud_last_manual_sync_at');
      localStorage.removeItem('ttc_cloud_last_auto_saved_day');
    } catch {}
    this.emit();
    try {
      this.bridge?.clearLocalSaveOnLogout();
      await signOut(auth);
      this.user = null;
      this.bridge?.notify('Đã đăng xuất tài khoản Google và dọn dẹp dữ liệu trên trình duyệt.', 'info');
    } catch {
      this.user = null;
    } finally {
      this.syncing = false;
      this.emit();
    }
  }

  getManualSyncCooldownSeconds(): number {
    if (!this.lastManualSyncAt) return 0;
    const elapsed = Date.now() - this.lastManualSyncAt;
    const remaining = Math.ceil((120000 - elapsed) / 1000);
    return remaining > 0 ? remaining : 0;
  }

  async syncNowManual(): Promise<void> {
    if (!this.user || !this.bridge || this.syncing || this.isKickedByOtherDevice || this.isCurrentAccountBanned) return;
    const cooldownRem = this.getManualSyncCooldownSeconds();
    if (cooldownRem > 0) {
      this.bridge.notify(
        `Bạn vừa lưu thủ công rồi! Vui lòng đợi ${cooldownRem} giây nữa để lưu tiếp nha.`,
        'info',
      );
      return;
    }
    const local = this.bridge.getLocalExport();
    if (!local || !local.fingerprint) {
      this.bridge.notify('Chưa có tiệm nào đang mở để lưu lên Đám mây.', 'info');
      return;
    }
    this.syncing = true;
    this.emit();
    try {
      const res = await this.uploadLocalToCloud(this.user.uid, local, false, false);
      if (res?.conflict) {
        this.bridge.notify(
          'Phát hiện xung đột phiên bản với Đám mây! Vui lòng chọn dữ liệu muốn giữ.',
          'info',
        );
        return;
      }
      this.lastManualSyncAt = Date.now();
      this.bridge.notify(`Đã đồng bộ tiệm "${local.summary.shopName}" lên Đám mây!`, 'good');
    } catch {
      this.bridge.notify('Lưu lên Đám mây thất bại, kiểm tra kết nối mạng nha.', 'bad');
    } finally {
      this.syncing = false;
      this.emit();
    }
  }

  private autoSyncInFlight = false;

  scheduleAutoSync() {
    if (!this.user || !this.bridge || this.conflict || this.isKickedByOtherDevice || this.isCurrentAccountBanned) return;
    if (this.syncing || this.autoSyncInFlight) return;
    const preview = this.bridge.getLocalExport();
    if (!preview || !preview.fingerprint) return;
    const curDay = Math.max(1, Math.floor(preview.summary.day || 1));
    const curLevel = Math.max(1, Math.floor(preview.summary.level || 1));
    const nextHash = this.computeAutoSyncHash(preview.fingerprint, curDay, curLevel);
    if (!this.lastAutoSyncHash) {
      const savedDay = this.lastAutoSyncedDay;
      this.lastAutoSyncHash = this.computeAutoSyncHash(
        preview.fingerprint,
        savedDay > 0 && savedDay <= curDay ? savedDay : curDay,
        curLevel,
      );
      if (nextHash === this.lastAutoSyncHash) return;
    }
    if (nextHash === this.lastAutoSyncHash) return;
    const prevParts = this.lastAutoSyncHash.split(':');
    const prevFp = prevParts[0] || '';
    const prevDay = Math.max(1, Math.floor(Number(prevParts[1]) || 1));
    const prevLevel = Math.max(1, Math.floor(Number(prevParts[2]) || 1));
    if (prevFp !== preview.fingerprint) {
      this.lastAutoSyncHash = nextHash;
      return;
    }
    if (curDay < prevDay) {
      this.lastAutoSyncHash = nextHash;
      return;
    }
    const isLevelUp = curLevel > prevLevel;
    const isTwoDaysPassed = curDay - prevDay >= 2;
    if (!isLevelUp && !isTwoDaysPassed) {
      return;
    }
    if (this.autoSyncTimer) clearTimeout(this.autoSyncTimer);
    this.autoSyncTimer = setTimeout(async () => {
      this.autoSyncTimer = null;
      if (!this.user || !this.bridge || this.conflict || this.isKickedByOtherDevice || this.isCurrentAccountBanned) return;
      if (this.syncing || this.autoSyncInFlight) {
        return;
      }
      const local = this.bridge.getLocalExport();
      if (!local || !local.fingerprint) return;
      const curLocalDay = Math.max(1, Math.floor(local.summary.day || 1));
      const curLocalLevel = Math.max(1, Math.floor(local.summary.level || 1));
      const targetHash = this.computeAutoSyncHash(local.fingerprint, curLocalDay, curLocalLevel);
      if (targetHash === this.lastAutoSyncHash) return;
      const pParts = (this.lastAutoSyncHash || '').split(':');
      const pFp = pParts[0] || '';
      const pDay = Math.max(1, Math.floor(Number(pParts[1]) || 1));
      const pLevel = Math.max(1, Math.floor(Number(pParts[2]) || 1));
      if (pFp && pFp === local.fingerprint) {
        const lvlUp = curLocalLevel > pLevel;
        const twoDays = curLocalDay - pDay >= 2;
        if (!lvlUp && !twoDays) return;
      }
      const prevHashBackup = this.lastAutoSyncHash;
      const prevDayBackup = this.lastAutoSyncedDay;
      // Khóa ngay mốc hash & trạng thái syncing TRƯỚC khi gọi uploadLocalToCloud
      // vì bên trong uploadLocalToCloud có gọi stampLocalOwnerUid -> V.save() -> scheduleAutoSync()
      this.lastAutoSyncHash = targetHash;
      this.lastAutoSyncedDay = curLocalDay;
      this.autoSyncInFlight = true;
      this.syncing = true;
      try {
        const res = await this.uploadLocalToCloud(this.user.uid, local, false, false);
        if (res?.ok) {
          this.lastAutoSyncedDay = curLocalDay;
          this.bridge?.notify?.(
            `Đã tự động lưu tiệm lên Đám mây (Mốc Ngày ${curLocalDay})!`,
            'good',
          );
          this.emit();
          if (!this.isCoupleRealtimeModalOpen()) {
            this.runBackgroundPulseSync().catch(() => undefined);
          }
        } else if (!res?.conflict) {
          this.lastAutoSyncHash = prevHashBackup;
          this.lastAutoSyncedDay = prevDayBackup;
        }
      } catch {
        this.lastAutoSyncHash = prevHashBackup;
        this.lastAutoSyncedDay = prevDayBackup;
      } finally {
        this.autoSyncInFlight = false;
        this.syncing = false;
        this.emit();
      }
    }, 1500);
  }

  async onShopReset(): Promise<void> {
    this.lastLbFetchAt = 0;
    this.lastDaysLbFetchAt = 0;
    this.lastAutoSyncHash = '';
    try {
      localStorage.removeItem('ttc_cloud_last_auto_saved_day');
    } catch {}

    if (!this.user) return;
    const uid = this.user.uid;

    // Xóa ngay thông tin của người chơi khỏi bộ nhớ tạm của cả 2 BXH
    this.leaderboard = this.leaderboard.filter((item) => item.uid !== uid);
    this.daysLeaderboard = this.daysLeaderboard.filter((item) => item.uid !== uid);
    this.emit();

    // Xóa thông tin người chơi khỏi Document BXH chung duy nhất (/leaderboards/global)
    try {
      const lbRef = doc(db, 'leaderboards', 'global');
      const lbSnap = await getDoc(lbRef);
      if (lbSnap.exists()) {
        const rawList = this.parseLeaderboardEntriesList(lbSnap.data()?.entries);
        const filtered = rawList.filter((item) => item.uid !== uid);
        if (filtered.length !== rawList.length) {
          const batch = writeBatch(db);
          batch.update(lbRef, {
            entries: filtered,
            updatedBy: uid,
            updatedAt: serverTimestamp(),
          });
          await batch.commit();
        }
        this.leaderboard = filtered
          .slice()
          .sort((a, b) => b.money - a.money || a.updatedAt - b.updatedAt)
          .slice(0, 2000);
        this.daysLeaderboard = filtered
          .slice()
          .sort((a, b) => (b.day || 1) - (a.day || 1) || b.money - a.money || a.updatedAt - b.updatedAt)
          .slice(0, 2000);
        const now = Date.now();
        this.lastLbFetchAt = now;
        this.lastDaysLbFetchAt = now;
      }
    } catch {}

    this.emit();
  }

  async fetchLeaderboard(force = false): Promise<void> {
    if (this.leaderboardLoading) return;
    if (!force && this.leaderboard.length > 0 && Date.now() - this.lastLbFetchAt < 30000) {
      return;
    }
    this.leaderboardLoading = true;
    this.emit();
    try {
      const [entries, creatorSnap] = await Promise.all([
        this.readGlobalLeaderboardEntries(force),
        get(ref(rtdb, 'refCodes/GC_CREATOR')).catch(() => null),
        this.syncPublicModerationOnce(),
      ]);
      if (creatorSnap && creatorSnap.exists()) {
        const cUid = String(creatorSnap.val() || '');
        if (cUid) this.creatorUid = cUid;
      }
      const filtered = entries.filter(
        (item) => !this.isUidHiddenFromLeaderboard(item.uid) && (item.day || 1) >= 10,
      );
      const sortedMoney = filtered
        .slice()
        .sort((a, b) => b.money - a.money || a.updatedAt - b.updatedAt)
        .slice(0, 2000);
      const sortedDays = filtered
        .slice()
        .sort(
          (a, b) =>
            (b.day || 1) - (a.day || 1) ||
            b.money - a.money ||
            a.updatedAt - b.updatedAt,
        )
        .slice(0, 2000);
      this.leaderboard = sortedMoney;
      this.daysLeaderboard = sortedDays;
      const now = Date.now();
      this.lastLbFetchAt = now;
      this.lastDaysLbFetchAt = now;
    } catch {
      // silent
    } finally {
      this.leaderboardLoading = false;
      this.emit();
    }
  }

  async fetchDaysLeaderboard(force = false): Promise<void> {
    if (this.daysLeaderboardLoading) return;
    if (!force && this.daysLeaderboard.length > 0 && Date.now() - this.lastDaysLbFetchAt < 30000) {
      return;
    }
    this.daysLeaderboardLoading = true;
    this.emit();
    try {
      const [entries, creatorSnap] = await Promise.all([
        this.readGlobalLeaderboardEntries(force),
        get(ref(rtdb, 'refCodes/GC_CREATOR')).catch(() => null),
        this.syncPublicModerationOnce(),
      ]);
      if (creatorSnap && creatorSnap.exists()) {
        const cUid = String(creatorSnap.val() || '');
        if (cUid) this.creatorUid = cUid;
      }
      const filtered = entries.filter(
        (item) => !this.isUidHiddenFromLeaderboard(item.uid) && (item.day || 1) >= 10,
      );
      const sortedMoney = filtered
        .slice()
        .sort((a, b) => b.money - a.money || a.updatedAt - b.updatedAt)
        .slice(0, 2000);
      const sortedDays = filtered
        .slice()
        .sort(
          (a, b) =>
            (b.day || 1) - (a.day || 1) ||
            b.money - a.money ||
            a.updatedAt - b.updatedAt,
        )
        .slice(0, 2000);
      this.leaderboard = sortedMoney;
      this.daysLeaderboard = sortedDays;
      const now = Date.now();
      this.lastLbFetchAt = now;
      this.lastDaysLbFetchAt = now;
    } catch {
      // silent
    } finally {
      this.daysLeaderboardLoading = false;
      this.emit();
    }
  }

  private async uploadLocalToCloud(
    uid: string,
    local: LocalExportData,
    isFirstLink: boolean,
    forceOverwrite = false,
    preloadedAccount?: { accountSnap: any; cloudData: AccountDoc | null },
  ): Promise<{ ok: boolean; conflict?: boolean; revision?: number }> {
    if (!this.bridge || this.isKickedByOtherDevice || this.isCurrentAccountBanned) {
      return { ok: false };
    }
    const isKnownLocalOwner =
      local.ownerUid === uid ||
      Boolean(
        preloadedAccount?.cloudData?.fingerprint &&
          local.fingerprint === preloadedAccount.cloudData.fingerprint,
      );
    const claimedOwner = isKnownLocalOwner
      ? uid
      : await this.getClaimedOwnerFromGlobalDoc(local.fingerprint).catch(() => null);
    if ((local.ownerUid && local.ownerUid !== uid) || (claimedOwner && claimedOwner !== uid)) {
      throw new Error('Save fingerprint already claimed by another user');
    }

    // 1. Document riêng của từng tài khoản: /accounts/{uid} (kèm dự phòng RTDB)
    const accountRef = doc(db, 'accounts', uid);
    // 2. Document gộp chung duy nhất cho toàn bộ Bảng xếp hạng (Tài sản & Ngày chơi): /leaderboards/global
    const lbRef = doc(db, 'leaderboards', 'global');

    const previewDay = Math.max(1, Math.min(100000, Math.floor(local.summary?.day || 1)));
    const accountPromise = preloadedAccount
      ? Promise.resolve(preloadedAccount)
      : this.readAccountWithRtdbFallback(uid);

    // Chỉ đọc /leaderboards/global khi người chơi đã đạt từ Ngày 10 trở lên (hoặc đã có tên trên BXH)
    const shouldTouchLeaderboardInitial =
      previewDay >= 10 ||
      (preloadedAccount?.cloudData && (preloadedAccount.cloudData.day || 1) >= 10) ||
      this.leaderboard.some((e) => e.uid === uid);

    let lbReadOk = false;
    let [{ accountSnap, cloudData: existingCloud }, lbSnap] = await Promise.all([
      accountPromise,
      shouldTouchLeaderboardInitial
        ? getDoc(lbRef)
            .then((s) => {
              lbReadOk = true;
              return s;
            })
            .catch(() => null)
        : Promise.resolve(null),
    ]);

    // Nếu trước đó chưa đọc BXH nhưng phát hiện dữ liệu Cloud cũ của tài khoản từng đạt >= Ngày 10 thì mới đọc bổ sung
    if (!shouldTouchLeaderboardInitial && existingCloud && (existingCloud.day || 1) >= 10) {
      lbSnap = await getDoc(lbRef)
        .then((s) => {
          lbReadOk = true;
          return s;
        })
        .catch(() => null);
    }

    if (!this.canLocalOverwriteOrConflictWithAccount(local, uid, existingCloud, claimedOwner)) {
      throw new Error('Cross-account overwrite blocked');
    }

    // Kiểm tra Optimistic Concurrency Control (Revision) & Chống lùi cấp độ/tiến trình
    if (!forceOverwrite && existingCloud && this.isSaveConflict(local, existingCloud)) {
      this.conflict = {
        local,
        cloud: existingCloud,
      };
      this.emit();
      return { ok: false, conflict: true };
    }

    const localRev =
      typeof local.revision === 'number' && local.revision > 0 ? Math.floor(local.revision) : 0;
    const cloudRev =
      typeof existingCloud?.revision === 'number' && existingCloud.revision > 0
        ? Math.floor(existingCloud.revision)
        : 0;
    const nextRevision = Math.max(localRev, cloudRev) + 1;
    const savedAt = Date.now();

    this.bridge.stampLocalOwnerUid(uid);
    this.bridge.stampCloudRevision?.(nextRevision, savedAt);
    const refreshed = this.bridge.getLocalExport() || {
      ...local,
      revision: nextRevision,
      savedAt,
    };

    const batch = writeBatch(db);
    const shopName = (refreshed.summary.shopName || 'Tiệm Trái Cây').slice(0, 80);
    const day = Math.max(1, Math.min(100000, Math.floor(refreshed.summary.day || 1)));
    const money = Math.max(
      -1000000000,
      Math.min(1000000000000, Math.round(refreshed.summary.money || 0)),
    );
    const level = Math.max(1, Math.min(1000, Math.floor(refreshed.summary.level || 1)));

    const backupPayload = {
      ownerUid: uid,
      fingerprint: refreshed.fingerprint,
      shopName,
      day,
      money,
      level,
      saveCode: refreshed.code,
      revision: nextRevision,
      savedAt,
    };

    const fsSnapExists =
      !!(accountSnap && typeof accountSnap.exists === 'function' && accountSnap.exists());

    const writeAccountToBatch = (b: ReturnType<typeof writeBatch>) => {
      if (!fsSnapExists) {
        b.set(accountRef, {
          ownerUid: uid,
          fingerprint: refreshed.fingerprint,
          shopName,
          day,
          money,
          level,
          saveCode: refreshed.code,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } else {
        b.update(accountRef, {
          fingerprint: refreshed.fingerprint,
          shopName,
          day,
          money,
          level,
          saveCode: refreshed.code,
          updatedAt: serverTimestamp(),
        });
      }
    };
    writeAccountToBatch(batch);

    const isSelfHiddenOrBanned =
      this.isUidHiddenFromLeaderboard(uid) || this.isUidBanned(uid);

    const lbExists = !!(lbSnap && typeof lbSnap.exists === 'function' && lbSnap.exists());
    const rawGlobalList =
      lbExists && lbSnap ? this.parseLeaderboardEntriesList(lbSnap.data()?.entries) : [];

    const mapByUid = new Map<string, LeaderboardEntry>();
    for (const item of rawGlobalList) {
      if (
        this.isUidHiddenFromLeaderboard(item.uid) ||
        this.isUidBanned(item.uid) ||
        (item.day || 1) < 10
      ) {
        continue;
      }
      mapByUid.set(item.uid, item);
    }

    const prevEntry = mapByUid.get(uid);
    const isSpec =
      this.isCurrentUserAdmin() ||
      (prevEntry && typeof prevEntry.vTag === 'number' && prevEntry.vTag === _makeVTag(uid));
    const isCre =
      this.isCurrentUserCreator() ||
      (prevEntry && typeof prevEntry.cTag === 'number' && prevEntry.cTag === _makeCTag(uid));
    const customAv = isSpec || isCre ? this.getCustomAvatar() || prevEntry?.av || '' : '';

    // Kiểm tra xem đây là cùng 1 tiệm đang chơi tiếp tục hay người chơi đã xóa dữ liệu mở tiệm mới:
    const isSameShop = !!(
      prevEntry &&
      prevEntry.fingerprint &&
      prevEntry.fingerprint === refreshed.fingerprint
    );

    const peakMoney =
      typeof refreshed.peakMoney === 'number'
        ? refreshed.peakMoney
        : typeof refreshed.summary?.peakMoney === 'number'
          ? refreshed.summary.peakMoney
          : 0;

    // Tiền hiển thị trên Bảng Xếp Hạng dựa trên tiền thực tế trong két của người chơi khi lưu lên Cloud (tăng giảm theo chi tiêu thực tế)
    const effectiveMoney = Math.max(0, money);

    // Tự động kiểm tra nghi vấn hack và gửi báo cáo ngầm cho Admin (TUYỆT ĐỐI KHÔNG CAN THIỆP TÀI KHOẢN)
    this.inspectAndAutoReportSuspicion(uid, shopName, effectiveMoney, day, level).catch(() => undefined);

    if (effectiveMoney > peakMoney && this.bridge?.syncPeakMoney) {
      try {
        this.bridge.syncPeakMoney(effectiveMoney);
      } catch {}
    }

    const prevDay = typeof prevEntry?.day === 'number' ? prevEntry.day : 1;
    const effectiveDay = isSameShop ? Math.max(day, prevDay) : day;

    const rawPet =
      typeof refreshed.pet === 'string'
        ? refreshed.pet
        : typeof local.pet === 'string'
          ? local.pet
          : '';
    const petTag =
      rawPet === 's' || rawPet === 'shiba'
        ? 's'
        : rawPet === 'm' || rawPet === 'meo_muop'
          ? 'm'
          : '';

    const currentEntry: LeaderboardEntry = {
      uid,
      shopName,
      money: effectiveMoney,
      day: effectiveDay,
      level,
      fingerprint: refreshed.fingerprint,
      updatedAt: Date.now(),
      ...(isSpec ? { vTag: _makeVTag(uid) } : {}),
      ...(isCre ? { cTag: _makeCTag(uid) } : {}),
      ...(customAv ? { av: customAv } : {}),
      ...(petTag ? { pet: petTag } : {}),
    };

    const shouldUpdateEntryInLb = !isSelfHiddenOrBanned && effectiveDay >= 10;
    const shouldRemoveExistingFromLb = !shouldUpdateEntryInLb && Boolean(prevEntry);

    if (shouldUpdateEntryInLb) {
      mapByUid.set(uid, currentEntry);
    } else if (shouldRemoveExistingFromLb) {
      mapByUid.delete(uid);
    }

    const allMergedEntries = Array.from(mapByUid.values()).sort(
      (a, b) => b.money - a.money || a.updatedAt - b.updatedAt,
    );
    const mergedEntries = allMergedEntries.slice(0, 1500);

    // CHỈ ghi vào /leaderboards/global khi đã đọc thành công BXH VÀ người chơi thực sự đủ điều kiện lên BXH (hoặc cần gỡ khỏi BXH)
    const canSafelyWriteGlobalLb =
      lbReadOk && (shouldUpdateEntryInLb || shouldRemoveExistingFromLb);
    if (canSafelyWriteGlobalLb) {
      if (!lbExists) {
        batch.set(lbRef, {
          entries: mergedEntries,
          updatedBy: uid,
          updatedAt: serverTimestamp(),
        });
      } else {
        batch.update(lbRef, {
          entries: mergedEntries,
          updatedBy: uid,
          updatedAt: serverTimestamp(),
        });
      }
    }

    const updateInMemoryLeaderboards = () => {
      if (lbReadOk) {
        const visibleEntries = allMergedEntries.filter(
          (e) => !this.isUidHiddenFromLeaderboard(e.uid),
        );
        this.leaderboard = visibleEntries.slice(0, 2000);
        this.daysLeaderboard = visibleEntries
          .slice()
          .sort(
            (a, b) =>
              (b.day || 1) - (a.day || 1) ||
              b.money - a.money ||
              a.updatedAt - b.updatedAt,
          )
          .slice(0, 2000);
        const now = Date.now();
        this.lastLbFetchAt = now;
        this.lastDaysLbFetchAt = now;
      }
    };

    let firestoreSaved = false;
    try {
      try {
        await batch.commit();
        firestoreSaved = true;
      } catch (firstErr) {
        if (canSafelyWriteGlobalLb && mergedEntries.length > 300) {
          try {
            const fallbackBatch = writeBatch(db);
            writeAccountToBatch(fallbackBatch);
            const fallbackEntries = allMergedEntries.slice(0, 300);
            if (!lbExists) {
              fallbackBatch.set(lbRef, {
                entries: fallbackEntries,
                updatedBy: uid,
                updatedAt: serverTimestamp(),
              });
            } else {
              fallbackBatch.update(lbRef, {
                entries: fallbackEntries,
                updatedBy: uid,
                updatedAt: serverTimestamp(),
              });
            }
            await fallbackBatch.commit();
            firestoreSaved = true;
          } catch {
            // Tiếp tục thử lưu riêng accountRef bên dưới
          }
        }
        if (!firestoreSaved) {
          const soloAccountBatch = writeBatch(db);
          writeAccountToBatch(soloAccountBatch);
          await soloAccountBatch.commit();
          firestoreSaved = true;
        }
      }
      updateInMemoryLeaderboards();
      this.lastSyncedAt = Date.now();
      this.lastAutoSyncedDay = day;
      this.lastAutoSyncHash = this.computeAutoSyncHash(refreshed.fingerprint, day, level, money);
      this.ensureRefCodeRegistered(`FP_OWN_${refreshed.fingerprint}`, uid).catch(() => undefined);
      if (rtdb) {
        update(ref(rtdb, `referrals/${uid}`), {
          cloudSave: null,
          updatedAt: savedAt,
        }).catch(() => undefined);
      }
    } catch (err) {
      const rtdbOk = await this.saveAccountBackupToRtdb(uid, backupPayload);
      if (rtdbOk) {
        // Nếu Firestore chưa cập nhật kịp Rules trên Console nhưng Realtime Database đã lưu thành công thì vẫn hoàn tất lưu Đám mây mượt mà
        updateInMemoryLeaderboards();
        this.lastSyncedAt = Date.now();
        this.lastAutoSyncedDay = day;
        this.lastAutoSyncHash = this.computeAutoSyncHash(refreshed.fingerprint, day, level, money);
        this.ensureRefCodeRegistered(`FP_OWN_${refreshed.fingerprint}`, uid).catch(() => undefined);
      } else {
        handleFirestoreError(
          err,
          isFirstLink ? OperationType.CREATE : OperationType.WRITE,
          `accounts/${uid}`,
        );
      }
    }

    return { ok: true, conflict: false, revision: nextRevision };
  }

  // ============================================================================
  // SỰ KIỆN CÂY CỔ THỤ NGUYỆN ƯỚC 10 NGÀY (CHỈ KẾT NỐI REALTIME KHI MỞ GIAO DIỆN)
  // ============================================================================

  isServerEventUpcoming(): boolean {
    const now = this.getServerNow();
    return now < this.serverEventStartMs;
  }

  isServerEventActive(): boolean {
    const now = this.getServerNow();
    return now >= this.serverEventStartMs && now < this.serverEventEndMs;
  }

  isServerEventExpired(): boolean {
    const now = this.getServerNow();
    return now >= this.serverEventEndMs;
  }

  isServerEventVisible(): boolean {
    const now = this.getServerNow();
    return now < this.serverEventEndMs;
  }

  getServerEventStartCountdownSeconds(): number {
    const now = this.getServerNow();
    if (now >= this.serverEventStartMs) return 0;
    return Math.max(0, Math.floor((this.serverEventStartMs - now) / 1000));
  }

  getServerEventRemainingSeconds(): number {
    const now = this.getServerNow();
    if (now >= this.serverEventEndMs || now < this.serverEventStartMs) return 0;
    return Math.max(0, Math.floor((this.serverEventEndMs - now) / 1000));
  }

  getServerEventTreeLevel(): number {
    const pts = Math.max(0, Math.floor(this.serverEventTotalCustomers || 0));
    if (pts <= 0) return 1;
    return Math.min(
      this.serverEventMaxLevel,
      Math.max(1, Math.floor(pts / this.serverEventPointsPerLevel)),
    );
  }

  isServerEventGoalReached(): boolean {
    return this.serverEventTotalCustomers >= this.serverEventTarget;
  }

  getMyRemainingPrayersToday(): number {
    const today = this.getTodayKey();
    if (this.myEventPrayDate !== today) {
      return this.serverEventDailyPrayLimit;
    }
    return Math.max(0, this.serverEventDailyPrayLimit - Math.max(0, Math.floor(this.myEventPrayUsed || 0)));
  }

  hasClaimableServerEventMilestone(): boolean {
    if (!this.user || !this.isServerEventActive()) return false;
    return this.serverEventMilestones.some(
      (m) =>
        this.serverEventTotalCustomers >= m.target &&
        this.myEventCustomers >= m.minPersonal &&
        !this.myEventClaimedMilestones.includes(m.id),
    );
  }

  private getLocalServerEventKey(uid: string): string {
    return `ttc_srv_ev_${this.serverEventId}_${uid}`;
  }

  private getGlobalServerEventCacheKey(): string {
    return `ttc_srv_ev_global_${this.serverEventId}`;
  }

  private loadGlobalServerEventTotalCache() {
    if (this.isServerEventExpired()) {
      try {
        localStorage.removeItem(this.getGlobalServerEventCacheKey());
      } catch {}
      this.serverEventTotalCustomers = 0;
      return;
    }
    try {
      const raw = localStorage.getItem(this.getGlobalServerEventCacheKey());
      if (raw) {
        const parsed = Math.floor(Number(raw) || 0);
        if (parsed > 0) {
          this.serverEventTotalCustomers = Math.min(
            this.serverEventTarget,
            Math.max(this.serverEventTotalCustomers, parsed),
          );
          return;
        }
      }
    } catch {}
    if (this.isServerEventActive() && this.serverEventTotalCustomers <= 0) {
      this.serverEventTotalCustomers = this.serverEventTarget;
    }
  }

  private saveGlobalServerEventTotalCache(total: number) {
    if (this.isServerEventExpired() || total <= 0) return;
    try {
      localStorage.setItem(
        this.getGlobalServerEventCacheKey(),
        String(Math.min(this.serverEventTarget, Math.floor(total))),
      );
    } catch {}
  }

  private loadLocalServerEventCache(uid: string) {
    this.loadGlobalServerEventTotalCache();
    if (!uid) return;
    if (this.isServerEventExpired()) {
      try {
        localStorage.removeItem(this.getLocalServerEventKey(uid));
      } catch {}
      this.myEventCustomers = 0;
      this.myEventClaimedMilestones = [];
      this.myEventSyncedDayKeys = [];
      this.myEventPrayDate = '';
      this.myEventPrayUsed = 0;
      this.myEventLastPrayReward = 0;
      this.myEventWish = '';
      return;
    }
    try {
      const raw = localStorage.getItem(this.getLocalServerEventKey(uid));
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (parsed && parsed.evId === this.serverEventId) {
        const c =
          typeof parsed.c === 'number' && Number.isFinite(parsed.c) && parsed.c >= 0
            ? Math.min(100000, Math.floor(parsed.c))
            : 0;
        const cl = Array.isArray(parsed.cl)
          ? parsed.cl.filter((x: unknown) => typeof x === 'number')
          : [];
        const d = Array.isArray(parsed.d)
          ? parsed.d.filter((x: unknown) => typeof x === 'string').slice(-60)
          : [];
        const w = typeof parsed.w === 'string' ? parsed.w.trim().slice(0, 60) : '';
        const today = this.getTodayKey();
        const pd = typeof parsed.pd === 'string' ? parsed.pd : '';
        const pu =
          pd === today && typeof parsed.pu === 'number' && Number.isFinite(parsed.pu)
            ? Math.min(this.serverEventDailyPrayLimit, Math.max(0, Math.floor(parsed.pu)))
            : 0;
        this.myEventCustomers = Math.max(this.myEventCustomers, c);
        this.myEventClaimedMilestones = Array.from(
          new Set([...this.myEventClaimedMilestones, ...cl]),
        );
        this.myEventSyncedDayKeys = Array.from(
          new Set([...this.myEventSyncedDayKeys, ...d]),
        ).slice(-60);
        if (w && !this.myEventWish) {
          this.myEventWish = w;
        }
        if (this.myEventPrayDate !== today) {
          this.myEventPrayDate = today;
          this.myEventPrayUsed = pu;
        } else {
          this.myEventPrayUsed = Math.max(this.myEventPrayUsed, pu);
        }
      }
    } catch {}
  }

  private saveLocalServerEventCache(uid: string) {
    if (!uid || this.isServerEventExpired()) return;
    try {
      const today = this.getTodayKey();
      const prayUsed = this.myEventPrayDate === today ? this.myEventPrayUsed : 0;
      localStorage.setItem(
        this.getLocalServerEventKey(uid),
        JSON.stringify({
          evId: this.serverEventId,
          c: this.myEventCustomers,
          cl: this.myEventClaimedMilestones,
          d: this.myEventSyncedDayKeys.slice(-60),
          w: this.myEventWish || '',
          pd: today,
          pu: prayUsed,
        }),
      );
    } catch {}
  }

  private lastServerEventSyncAt = 0;

  async syncServerEventOnce(force = false): Promise<void> {
    if (!rtdb || !this.isServerEventActive()) {
      if (!this.isServerEventActive()) {
        this.stopServerEventRealtime();
      }
      return;
    }
    if (
      !force &&
      this.lastServerEventSyncAt > 0 &&
      Date.now() - this.lastServerEventSyncAt < 120000
    ) {
      return;
    }
    this.lastServerEventSyncAt = Date.now();
    try {
      const branchRef = ref(rtdb, `serverEvent/${this.serverEventId}/shops`);
      const branchSnap = await get(branchRef).catch(() => null);
      if (branchSnap && branchSnap.exists() && typeof branchSnap.val() === 'object') {
        this.rawEventShopsBranch = branchSnap.val() || {};
        this.recomputeServerEventState();
        return;
      }
      const evQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('EV2_S_'),
        endAt('EV2_S_\uf8ff'),
      );
      const evSnap = await get(evQuery).catch(() => null);
      if (evSnap) {
        this.rawEventRefCodesMap =
          evSnap.exists() && typeof evSnap.val() === 'object' ? evSnap.val() || {} : {};
      }
      this.recomputeServerEventState();
    } catch {}
  }

  pauseServerEventRealtimeListeners() {
    while (this.serverEventUnsubs.length > 0) {
      const fn = this.serverEventUnsubs.pop();
      try {
        fn?.();
      } catch {}
    }
  }

  checkAndManageServerEventLifecycle() {
    if (this.isServerEventExpired()) {
      this.stopServerEventRealtime();
      this.cleanupExpiredServerEvent().catch(() => undefined);
      return;
    }
    if (this.isServerEventActive()) {
      this.loadGlobalServerEventTotalCache();
      // Chỉ kết nối với Realtime Database khi người chơi thực sự mở giao diện sự kiện
      if (this.activeRealtimeViews.has('serverEvent')) {
        this.startServerEventRealtime();
      } else {
        this.pauseServerEventRealtimeListeners();
      }
      if (!this.serverEventExpiryTimer && typeof window !== 'undefined') {
        this.serverEventExpiryTimer = setInterval(() => {
          if (this.isServerEventExpired()) {
            this.stopServerEventRealtime();
            this.cleanupExpiredServerEvent().catch(() => undefined);
            this.emit();
          }
        }, 15000);
      }
    } else {
      // Đang trong thời gian đếm ngược chờ khai mở lúc 17:00 -> tuyệt đối không kết nối RTDB
      this.pauseServerEventRealtimeListeners();
      if (!this.serverEventExpiryTimer && typeof window !== 'undefined') {
        this.serverEventExpiryTimer = setInterval(() => {
          if (this.isServerEventActive()) {
            if (this.activeRealtimeViews.has('serverEvent')) {
              this.startServerEventRealtime();
            }
            this.emit();
          } else if (this.isServerEventExpired()) {
            this.stopServerEventRealtime();
            this.cleanupExpiredServerEvent().catch(() => undefined);
            this.emit();
          }
        }, 5000);
      }
    }
  }

  startServerEventRealtime() {
    if (!rtdb || !this.isServerEventActive() || !this.activeRealtimeViews.has('serverEvent')) {
      if (!this.isServerEventActive() || !this.activeRealtimeViews.has('serverEvent')) {
        this.pauseServerEventRealtimeListeners();
      }
      return;
    }
    // Nếu toàn server đã đạt 100% điểm (100.000) và đã có dữ liệu BXH thì ngắt kết nối lắng nghe liên tục để tiết kiệm băng thông tối đa
    if (this.isServerEventGoalReached() && this.serverEventLeaderboard.length > 0) {
      this.pauseServerEventRealtimeListeners();
      return;
    }
    if (this.serverEventUnsubs.length > 0) return;

    let fbEvStarted = false;
    const startFallbackRefCodes = () => {
      if (fbEvStarted || !this.isServerEventActive() || !this.activeRealtimeViews.has('serverEvent')) {
        return;
      }
      fbEvStarted = true;
      try {
        const evQuery = query(
          ref(rtdb, 'refCodes'),
          orderByKey(),
          startAt('EV2_S_'),
          endAt('EV2_S_\uf8ff'),
        );
        const unsubRefCodes = onValue(
          evQuery,
          (snap) => {
            if (!this.isServerEventActive() || !this.activeRealtimeViews.has('serverEvent')) {
              this.pauseServerEventRealtimeListeners();
              return;
            }
            this.rawEventRefCodesMap =
              snap.exists() && typeof snap.val() === 'object' ? snap.val() || {} : {};
            this.recomputeServerEventState();
            if (this.isServerEventGoalReached()) {
              this.pauseServerEventRealtimeListeners();
            }
          },
          () => undefined,
        );
        this.serverEventUnsubs.push(unsubRefCodes);
      } catch {}
    };

    try {
      const branchRef = ref(rtdb, `serverEvent/${this.serverEventId}/shops`);
      const unsubBranch = onValue(
        branchRef,
        (snap) => {
          if (!this.isServerEventActive() || !this.activeRealtimeViews.has('serverEvent')) {
            this.pauseServerEventRealtimeListeners();
            return;
          }
          if (snap.exists() && typeof snap.val() === 'object') {
            this.rawEventShopsBranch = snap.val() || {};
            this.lastServerEventSyncAt = Date.now();
            this.recomputeServerEventState();
            if (this.isServerEventGoalReached()) {
              this.pauseServerEventRealtimeListeners();
            }
          } else {
            this.rawEventShopsBranch = {};
            startFallbackRefCodes();
          }
        },
        () => {
          startFallbackRefCodes();
        },
      );
      this.serverEventUnsubs.push(unsubBranch);
    } catch {}
  }

  stopServerEventRealtime() {
    this.pauseServerEventRealtimeListeners();
    if (this.serverEventExpiryTimer) {
      clearInterval(this.serverEventExpiryTimer);
      this.serverEventExpiryTimer = null;
    }
    if (this.isServerEventExpired()) {
      this.rawEventShopsBranch = {};
      this.rawEventRefCodesMap = {};
      this.serverEventTotalCustomers = 0;
      this.serverEventLeaderboard = [];
      this.serverEventWishes = [];
    }
  }

  async cleanupExpiredServerEvent(): Promise<void> {
    if (this.serverEventCleanupDone || !this.isServerEventExpired()) return;
    this.serverEventCleanupDone = true;
    try {
      if (this.user?.uid) {
        try {
          localStorage.removeItem(this.getLocalServerEventKey(this.user.uid));
        } catch {}
      }
      try {
        for (let i = localStorage.length - 1; i >= 0; i--) {
          const k = localStorage.key(i);
          if (k && k.startsWith('ttc_srv_ev_')) {
            localStorage.removeItem(k);
          }
        }
      } catch {}

      if (!rtdb || !this.user) return;
      const uid = this.user.uid;

      await update(ref(rtdb, `referrals/${uid}`), {
        evId: null,
        evCust: null,
        evClaimed: null,
        evDays: null,
        evWish: null,
        evPrayDate: null,
        evPrayUsed: null,
      }).catch(() => undefined);

      await set(ref(rtdb, `serverEvent/${this.serverEventId}/shops/${uid}`), null).catch(
        () => undefined,
      );
      await set(ref(rtdb, `serverEvent/${this.serverEventId}`), null).catch(() => undefined);

      const evQuery = query(
        ref(rtdb, 'refCodes'),
        orderByKey(),
        startAt('EV2_S_'),
        endAt('EV2_S_\uf8ff'),
      );
      const snap = await get(evQuery).catch(() => null);
      if (snap && snap.exists() && typeof snap.val() === 'object') {
        const keys = Object.keys(snap.val() || {});
        await Promise.all(
          keys
            .slice(0, 60)
            .map((k) => set(ref(rtdb, `refCodes/${k}`), null).catch(() => undefined)),
        );
      }
    } catch {}
  }

  private recomputeServerEventState() {
    if (this.isServerEventExpired()) {
      this.serverEventTotalCustomers = 0;
      this.serverEventLeaderboard = [];
      this.serverEventWishes = [];
      return;
    }

    const byUid = new Map<
      string,
      {
        uid: string;
        shopName: string;
        customers: number;
        updatedAt: number;
        wish?: string;
        vTag?: number;
        cTag?: number;
      }
    >();

    // 1. Đọc từ nhánh chuẩn serverEvent/{eventId}/shops/{uid}
    for (const [uid, raw] of Object.entries(this.rawEventShopsBranch || {})) {
      if (!uid || typeof raw !== 'object' || !raw) continue;
      if (this.isUidBanned(uid) || this.isUidHiddenFromLeaderboard(uid)) continue;
      const customers = Math.min(100000, Math.max(0, Math.floor(Number(raw.c) || 0)));
      const wish = typeof raw.w === 'string' ? raw.w.trim().slice(0, 60) : '';
      if (customers <= 0 && !wish) continue;
      const shopName = String(raw.s || 'Tiệm Trái Cây').trim().slice(0, 28) || 'Tiệm Trái Cây';
      const updatedAt = Math.max(0, Math.floor(Number(raw.u) || 0));
      const vTag = typeof raw.v === 'number' ? raw.v : undefined;
      const cTag = typeof raw.t === 'number' ? raw.t : undefined;
      byUid.set(uid, { uid, shopName, customers, updatedAt, wish: wish || undefined, vTag, cTag });
    }

    // 2. Đọc từ nhánh gói dự phòng refCodes/EV2_S_{uid}_{customers}_{updatedAt}-{shopHex}-{wishHex}
    for (const [key, val] of Object.entries(this.rawEventRefCodesMap || {})) {
      if (!key.startsWith('EV2_S_')) continue;
      const body = key.slice(6);
      const dashIdx = body.indexOf('-');
      const metaPart = dashIdx >= 0 ? body.slice(0, dashIdx) : body;
      const tailPart = dashIdx >= 0 ? body.slice(dashIdx + 1) : '';
      const secondDashIdx = tailPart.indexOf('-');
      const shopHex = secondDashIdx >= 0 ? tailPart.slice(0, secondDashIdx) : tailPart;
      const wishHex = secondDashIdx >= 0 ? tailPart.slice(secondDashIdx + 1) : '';
      const lastUnderscore = metaPart.lastIndexOf('_');
      if (lastUnderscore <= 0) continue;
      const prevUnderscore = metaPart.lastIndexOf('_', lastUnderscore - 1);
      if (prevUnderscore <= 0) continue;

      const parsedUid = metaPart.slice(0, prevUnderscore).trim();
      const uid = String(val || parsedUid || '').trim();
      if (!uid || uid !== parsedUid) continue;
      if (this.isUidBanned(uid) || this.isUidHiddenFromLeaderboard(uid)) continue;

      const customers = Math.min(
        100000,
        Math.max(0, Math.floor(Number(metaPart.slice(prevUnderscore + 1, lastUnderscore)) || 0)),
      );
      const updatedAt = Math.max(0, Math.floor(Number(metaPart.slice(lastUnderscore + 1)) || 0));
      const wish = wishHex ? _decHex(wishHex).trim().slice(0, 60) : '';
      if (customers <= 0 && !wish) continue;

      const shopName = _decHex(shopHex);
      const prev = byUid.get(uid);
      if (
        !prev ||
        customers > prev.customers ||
        (customers === prev.customers && updatedAt > prev.updatedAt)
      ) {
        byUid.set(uid, {
          uid,
          shopName: shopName || prev?.shopName || 'Tiệm Trái Cây',
          customers,
          updatedAt,
          wish: wish || prev?.wish,
          vTag: prev?.vTag,
          cTag: prev?.cTag,
        });
      } else if (prev && wish && !prev.wish) {
        prev.wish = wish;
      }
    }

    const rawServerTotal = Array.from(byUid.values()).reduce((sum, item) => sum + item.customers, 0);
    const serverGoalAlreadyReached = rawServerTotal >= this.serverEventTarget;

    // 3. Đảm bảo tiến độ & lời cầu nguyện của chính người chơi đang đăng nhập luôn phản ánh tức thì
    // (Nếu toàn server đã đủ 100% thì giữ nguyên điểm BXH đã chốt trên server, chỉ tăng điểm đóng góp cá nhân myEventCustomers)
    if (
      this.user &&
      (this.myEventCustomers > 0 || !!this.myEventWish) &&
      !this.isCurrentAccountBanned &&
      !this.isUidBanned(this.user.uid) &&
      !this.isUidHiddenFromLeaderboard(this.user.uid)
    ) {
      const myUid = this.user.uid;
      const existing = byUid.get(myUid);
      const local = this.bridge?.getLocalExport();
      const myShopName =
        (
          local?.summary?.shopName ||
          existing?.shopName ||
          this.user.displayName ||
          'Tiệm Trái Cây'
        )
          .trim()
          .slice(0, 28) || 'Tiệm Trái Cây';
      const bestCustomers = Math.min(
        100000,
        Math.max(this.myEventCustomers, existing?.customers || 0),
      );
      if (bestCustomers > this.myEventCustomers) {
        this.myEventCustomers = bestCustomers;
      }
      const bestWish = (this.myEventWish || existing?.wish || '').trim().slice(0, 60);
      if (bestWish && !this.myEventWish) {
        this.myEventWish = bestWish;
      }
      const otherServerTotal = Math.max(0, rawServerTotal - (existing?.customers || 0));
      const lbCustomers = serverGoalAlreadyReached
        ? existing?.customers || 0
        : Math.min(
            bestCustomers,
            Math.max(existing?.customers || 0, this.serverEventTarget - otherServerTotal),
          );
      if (lbCustomers > 0 || bestWish) {
        byUid.set(myUid, {
          uid: myUid,
          shopName: myShopName,
          customers: lbCustomers,
          updatedAt: existing?.updatedAt || this.getServerNow(),
          wish: bestWish || undefined,
          vTag: this.isCurrentUserAdmin() ? _makeVTag(myUid) : existing?.vTag,
          cTag: this.isCurrentUserCreator() ? _makeCTag(myUid) : existing?.cTag,
        });
      }
    }

    const allEntries = Array.from(byUid.values());
    const list = allEntries
      .filter((x) => x.customers > 0)
      .sort((a, b) => b.customers - a.customers || a.updatedAt - b.updatedAt);
    const total = list.reduce((sum, item) => sum + item.customers, 0);

    const wishes = allEntries
      .filter((x) => typeof x.wish === 'string' && x.wish.trim().length > 0)
      .map((x) => ({
        uid: x.uid,
        shopName: x.shopName,
        wish: x.wish!.trim(),
        customers: x.customers,
        updatedAt: x.updatedAt,
        vTag: x.vTag,
        cTag: x.cTag,
      }))
      .sort((a, b) => b.updatedAt - a.updatedAt || b.customers - a.customers);

    this.serverEventLeaderboard = list.slice(0, 100);
    this.serverEventWishes = wishes.slice(0, 500);
    this.serverEventTotalCustomers = Math.min(this.serverEventTarget, Math.max(0, total));
    this.saveGlobalServerEventTotalCache(this.serverEventTotalCustomers);
    this.emit();
  }

  private async syncMyServerEventShopToRtdb(
    uid: string,
    options?: { syncWishOnly?: boolean },
  ): Promise<void> {
    if (!rtdb || !uid) return;
    const local = this.bridge?.getLocalExport();
    const shopName =
      (local?.summary?.shopName || this.user?.displayName || 'Tiệm Trái Cây').trim().slice(0, 26) ||
      'Tiệm Trái Cây';
    const nowMs = this.getServerNow();
    const today = this.getTodayKey();
    const prayUsed = this.myEventPrayDate === today ? this.myEventPrayUsed : 0;
    const nextPoints = Math.min(100000, Math.max(0, Math.floor(this.myEventCustomers || 0)));
    const wishText = (this.myEventWish || '').trim().slice(0, 60);
    const shopHex = _encHex(shopName);
    const wishHex = wishText ? _encHex(wishText) : '';

    // 1. Luôn lưu điểm đóng góp cá nhân của tiệm (evCust) vào nhánh riêng của người chơi để cày mốc nhận thưởng
    await update(ref(rtdb, `referrals/${uid}`), {
      evId: this.serverEventId,
      evCust: nextPoints,
      evClaimed: this.myEventClaimedMilestones,
      evDays: this.myEventSyncedDayKeys,
      evWish: wishText || null,
      evPrayDate: today,
      evPrayUsed: prayUsed,
      updatedAt: nowMs,
    }).catch(() => undefined);

    // 2. Kiểm tra điểm toàn server hiện tại: Nếu đã đạt đủ 100% (100.000 điểm) thì KHÔNG cộng thêm điểm server và KHÔNG tăng BXH nữa để tiết kiệm băng thông
    if (this.lastServerEventSyncAt === 0 && !this.isServerEventGoalReached()) {
      await this.syncServerEventOnce(false);
    }

    const existingLbEntry = this.serverEventLeaderboard.find((x) => x.uid === uid);
    const existingMyLbPts = Math.max(
      0,
      Math.floor(Number(this.rawEventShopsBranch?.[uid]?.c ?? existingLbEntry?.customers ?? 0)),
    );
    let otherBranchPts = 0;
    for (const [shopUid, raw] of Object.entries(this.rawEventShopsBranch || {})) {
      if (!shopUid || shopUid === uid || typeof raw !== 'object' || !raw) continue;
      if (this.isUidBanned(shopUid) || this.isUidHiddenFromLeaderboard(shopUid)) continue;
      otherBranchPts += Math.min(100000, Math.max(0, Math.floor(Number(raw.c) || 0)));
    }
    const otherLbPts = this.serverEventLeaderboard
      .filter((x) => x.uid !== uid)
      .reduce((sum, item) => sum + item.customers, 0);
    const otherServerPts = Math.max(0, otherBranchPts, otherLbPts);
    const serverAlreadyFull =
      this.serverEventTotalCustomers >= this.serverEventTarget ||
      otherServerPts + existingMyLbPts >= this.serverEventTarget;

    if (serverAlreadyFull && !options?.syncWishOnly) {
      return;
    }

    const publicPoints = serverAlreadyFull
      ? existingMyLbPts
      : Math.min(nextPoints, Math.max(existingMyLbPts, this.serverEventTarget - otherServerPts));

    const shopPayload: Record<string, any> = {
      s: shopName,
      c: publicPoints,
      u: nowMs,
    };
    if (wishText) {
      shopPayload.w = wishText;
    }
    if (this.isCurrentUserAdmin()) {
      shopPayload.v = _makeVTag(uid);
    }
    if (this.isCurrentUserCreator()) {
      shopPayload.t = _makeCTag(uid);
    }

    let branchSaved = false;
    try {
      await set(ref(rtdb, `serverEvent/${this.serverEventId}/shops/${uid}`), shopPayload);
      this.rawEventShopsBranch[uid] = shopPayload;
      branchSaved = true;
    } catch {}

    if (!branchSaved) {
      const oldPrefix = `EV2_S_${uid}_`;
      const oldKeys = Object.keys(this.rawEventRefCodesMap || {}).filter((k) =>
        k.startsWith(oldPrefix),
      );
      const newKey = wishHex
        ? `EV2_S_${uid}_${publicPoints}_${nowMs}-${shopHex}-${wishHex}`
        : `EV2_S_${uid}_${publicPoints}_${nowMs}-${shopHex}`;
      await set(ref(rtdb, `refCodes/${newKey}`), uid).catch(() => undefined);
      this.rawEventRefCodesMap[newKey] = uid;
      for (const oldK of oldKeys) {
        if (oldK !== newKey) {
          delete this.rawEventRefCodesMap[oldK];
          set(ref(rtdb, `refCodes/${oldK}`), null).catch(() => undefined);
        }
      }
    }
    this.recomputeServerEventState();
  }

  async prayAtServerEventTree(): Promise<{
    ok: boolean;
    reward: number;
    pointsAdded: number;
    tierLabel: string;
  }> {
    if (this.isServerEventUpcoming()) {
      this.bridge?.notify(
        'Cây Cổ Thụ sẽ khai mở vào lúc 17:00 chiều nay, hãy quay lại cầu nguyện nhé!',
        'bad',
      );
      return { ok: false, reward: 0, pointsAdded: 0, tierLabel: '' };
    }
    if (!this.isServerEventActive()) {
      this.bridge?.notify('Đêm hội Cây Cổ Thụ đã khép lại!', 'bad');
      return { ok: false, reward: 0, pointsAdded: 0, tierLabel: '' };
    }
    if (!this.user || this.isCurrentAccountBanned || this.isUidBanned(this.user.uid)) {
      this.bridge?.notify('Vui lòng đăng nhập tài khoản để cầu nguyện dưới Cây Cổ Thụ!', 'bad');
      return { ok: false, reward: 0, pointsAdded: 0, tierLabel: '' };
    }
    if (this.serverEventBusy) {
      return { ok: false, reward: 0, pointsAdded: 0, tierLabel: '' };
    }

    const uid = this.user.uid;
    this.loadLocalServerEventCache(uid);
    const today = this.getTodayKey();
    if (this.myEventPrayDate !== today) {
      this.myEventPrayDate = today;
      this.myEventPrayUsed = 0;
    }

    if (this.myEventPrayUsed >= this.serverEventDailyPrayLimit) {
      this.bridge?.notify(
        'Hôm nay bạn đã hết 5 lượt cầu nguyện, hãy quay lại vào ngày mai nhé!',
        'bad',
      );
      return { ok: false, reward: 0, pointsAdded: 0, tierLabel: '' };
    }

    this.serverEventBusy = true;
    this.emit();
    try {
      // Tỷ lệ và phần thưởng cầu nguyện đã được điều chỉnh giảm hợp lý, tối đa 2.000.000đ
      const roll = Math.random();
      let reward = 50000;
      let tierLabel = 'Lộc Lá Đầu Cành';
      if (roll < 0.75) {
        // 75%: 30.000đ -> 120.000đ (bội số 10.000đ)
        reward = (3 + Math.floor(Math.random() * 10)) * 10000;
        tierLabel = 'Lộc Lá Đầu Cành';
      } else if (roll < 0.93) {
        // 18%: 150.000đ -> 350.000đ (bội số 10.000đ)
        reward = (15 + Math.floor(Math.random() * 21)) * 10000;
        tierLabel = 'Sương Đêm Chúc Phúc';
      } else if (roll < 0.988) {
        // 5.8%: 400.000đ -> 900.000đ (bội số 50.000đ)
        reward = (8 + Math.floor(Math.random() * 11)) * 50000;
        tierLabel = 'Ánh Sao Cổ Thụ';
      } else {
        // 1.2% (Hiếm): 1.100.000đ -> 2.000.000đ (bội số 100.000đ)
        reward = (11 + Math.floor(Math.random() * 10)) * 100000;
        tierLabel = 'Đại Lộc Kim Chi';
      }

      const pointsAdded = 10;
      this.myEventPrayUsed = Math.min(this.serverEventDailyPrayLimit, this.myEventPrayUsed + 1);
      this.myEventLastPrayReward = reward;
      this.myEventCustomers = Math.min(100000, Math.max(0, this.myEventCustomers + pointsAdded));
      this.saveLocalServerEventCache(uid);
      this.recomputeServerEventState();

      this.bridge?.grantReferralMoney?.(reward, {});
      await this.syncMyServerEventShopToRtdb(uid);

      this.bridge?.notify(
        this.isServerEventGoalReached()
          ? `✨ Cầu nguyện thành công (${tierLabel}): Nhận +${reward.toLocaleString('vi-VN')}đ & +${pointsAdded} điểm tiệm đóng góp!`
          : `✨ Cầu nguyện thành công (${tierLabel}): Nhận +${reward.toLocaleString('vi-VN')}đ & góp +${pointsAdded} điểm cho Cây Cổ Thụ!`,
        'good',
      );
      return { ok: true, reward, pointsAdded, tierLabel };
    } catch {
      this.bridge?.notify('Chưa thể gửi lời cầu nguyện lúc này, vui lòng thử lại nha!', 'bad');
      return { ok: false, reward: 0, pointsAdded: 0, tierLabel: '' };
    } finally {
      this.serverEventBusy = false;
      this.emit();
    }
  }

  async engraveServerEventWish(rawWish: string): Promise<boolean> {
    if (this.isServerEventUpcoming()) {
      this.bridge?.notify(
        'Cây Cổ Thụ sẽ khai mở vào lúc 17:00 chiều nay, hãy quay lại khắc điều ước nhé!',
        'bad',
      );
      return false;
    }
    if (!this.isServerEventActive()) {
      this.bridge?.notify('Đêm hội Cây Cổ Thụ đã khép lại!', 'bad');
      return false;
    }
    if (!this.user || this.isCurrentAccountBanned || this.isUidBanned(this.user.uid)) {
      this.bridge?.notify('Vui lòng đăng nhập tài khoản để khắc lời cầu nguyện lên cây!', 'bad');
      return false;
    }
    if (this.serverEventBusy) return false;

    const uid = this.user.uid;
    this.loadLocalServerEventCache(uid);
    if (this.myEventWish && this.myEventWish.trim().length > 0) {
      this.bridge?.notify(
        'Mỗi tiệm chỉ được khắc lời cầu nguyện lên Cây Cổ Thụ một lần duy nhất!',
        'bad',
      );
      return false;
    }

    const cleanWish = String(rawWish || '')
      .replace(/[\r\n\t]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 60);

    if (cleanWish.length < 4) {
      this.bridge?.notify('Lời cầu nguyện cần dài từ 4 đến 60 ký tự nha!', 'bad');
      return false;
    }

    this.serverEventBusy = true;
    this.emit();
    try {
      const bonusPoints = 20;
      this.myEventWish = cleanWish;
      this.myEventCustomers = Math.min(100000, Math.max(0, this.myEventCustomers + bonusPoints));
      this.saveLocalServerEventCache(uid);
      this.recomputeServerEventState();

      await this.syncMyServerEventShopToRtdb(uid, { syncWishOnly: true });
      this.bridge?.notify(
        `🌿 Đã khắc lời cầu nguyện lên thân Cây Cổ Thụ và nhận +${bonusPoints} điểm đóng góp!`,
        'good',
      );
      return true;
    } catch {
      this.bridge?.notify('Chưa thể khắc lời cầu nguyện lúc này, vui lòng thử lại nha!', 'bad');
      return false;
    } finally {
      this.serverEventBusy = false;
      this.emit();
    }
  }

  async recordServerEventDayServed(
    servedCount: number,
    gameDay: number,
    createdAt?: number,
  ): Promise<boolean> {
    if (!this.isServerEventActive()) return false;
    if (!this.user || this.isCurrentAccountBanned || this.isUidBanned(this.user.uid)) {
      return false;
    }

    const local = this.bridge?.getLocalExport();
    const level = Math.max(1, Math.floor(Number(local?.summary?.level) || 1));
    if (level < 3) return false;

    const rawServed = Math.floor(Number(servedCount) || 0);
    if (rawServed <= 0) return false;
    // Điểm linh khí góp cho Cây Cổ Thụ khi hoàn thành 1 ngày bán hàng
    const cleanPoints = Math.min(100, Math.max(10, rawServed));
    const safeDay = Math.max(1, Math.floor(Number(gameDay) || Number(local?.summary?.day) || 1));
    const shopAnchor = String(createdAt || local?.fingerprint || 'shop');
    const dayKey = `${shopAnchor}:${safeDay}`;

    const uid = this.user.uid;
    this.loadLocalServerEventCache(uid);
    if (this.myEventSyncedDayKeys.includes(dayKey)) {
      return false;
    }

    this.myEventSyncedDayKeys = [...this.myEventSyncedDayKeys.slice(-59), dayKey];
    const nextPoints = Math.min(100000, Math.max(0, this.myEventCustomers + cleanPoints));
    this.myEventCustomers = nextPoints;
    this.saveLocalServerEventCache(uid);
    this.recomputeServerEventState();

    try {
      await this.syncMyServerEventShopToRtdb(uid);
      this.bridge?.notify(
        this.isServerEventGoalReached()
          ? `🌳 Qua ngày mới: Tiệm được +${cleanPoints} điểm đóng góp (Tổng góp: ${nextPoints} điểm)!`
          : `🌳 Qua ngày mới: Tiệm đã góp +${cleanPoints} điểm nuôi dưỡng Cây Cổ Thụ (Tổng góp: ${nextPoints} điểm)!`,
        'good',
      );
      return true;
    } catch {
      return false;
    }
  }

  async claimServerEventMilestone(milestoneId: number): Promise<boolean> {
    if (!this.isServerEventActive()) {
      this.bridge?.notify('Đêm hội Cây Cổ Thụ chưa mở hoặc đã khép lại!', 'bad');
      return false;
    }
    if (!this.user) {
      this.bridge?.notify('Vui lòng đăng nhập tài khoản để nhận lộc Cây Cổ Thụ nha!', 'bad');
      return false;
    }
    if (this.serverEventBusy) return false;

    const m = this.serverEventMilestones.find((x) => x.id === milestoneId);
    if (!m) return false;

    const uid = this.user.uid;
    this.loadLocalServerEventCache(uid);

    if (this.myEventClaimedMilestones.includes(m.id)) {
      this.bridge?.notify('Bạn đã nhận quà mốc này rồi!', 'bad');
      return false;
    }
    if (this.serverEventTotalCustomers < m.target) {
      this.bridge?.notify(
        `Cây Cổ Thụ cần đạt Cấp ${m.level} (${m.target.toLocaleString('vi-VN')} điểm) để mở khóa quà này!`,
        'bad',
      );
      return false;
    }
    if (this.myEventCustomers < m.minPersonal) {
      this.bridge?.notify(
        `Tiệm của bạn cần đóng góp ít nhất ${m.minPersonal} điểm cho Cây Cổ Thụ để nhận quà mốc này (Hiện tại: ${this.myEventCustomers} điểm)!`,
        'bad',
      );
      return false;
    }

    this.serverEventBusy = true;
    this.emit();
    try {
      const nextClaimed = Array.from(new Set([...this.myEventClaimedMilestones, m.id]));
      this.myEventClaimedMilestones = nextClaimed;
      this.saveLocalServerEventCache(uid);

      await update(ref(rtdb, `referrals/${uid}`), {
        evId: this.serverEventId,
        evCust: this.myEventCustomers,
        evClaimed: nextClaimed,
        updatedAt: this.getServerNow(),
      }).catch(() => undefined);

      this.bridge?.grantReferralMoney?.(m.reward, {});
      this.bridge?.notify(
        `🎁 Nhận lộc ${m.titleVi} thành công: +${m.reward.toLocaleString('vi-VN')}đ!`,
        'good',
      );
      return true;
    } catch {
      this.bridge?.notify('Không thể nhận quà lúc này, vui lòng thử lại nha!', 'bad');
      return false;
    } finally {
      this.serverEventBusy = false;
      this.emit();
    }
  }

  // ============================================================================
  // KÊNH TRÒ CHUYỆN 3 KHU VỰC NGÔN NGỮ (VI / EN / ID) · GIỚI HẠN 60 TIN NHẮN
  // ============================================================================

  chatChannel: 'vi' | 'en' | 'id' = 'vi';
  chatMessagesMap: Record<
    'vi' | 'en' | 'id',
    Array<{
      id: string;
      rawKey: string;
      channel: 'vi' | 'en' | 'id';
      uid: string;
      shopName: string;
      text: string;
      createdAt: number;
      level: number;
      isAdmin: boolean;
      isCreator: boolean;
      replyTo?: { id: string; shopName: string; text: string } | null;
    }>
  > = {
    vi: [],
    en: [],
    id: [],
  };
  chatSending = false;
  chatCooldownUntil = 0;
  private chatUnsubs: Array<() => void> = [];
  private chatListeningChannel: 'vi' | 'en' | 'id' | '' = '';
  private rawChatMapByLang: Record<'vi' | 'en' | 'id', Record<string, string>> = {
    vi: {},
    en: {},
    id: {},
  };
  private rawChatDelByLang: Record<'vi' | 'en' | 'id', Record<string, string>> = {
    vi: {},
    en: {},
    id: {},
  };
  private creatorCheckedForChat = false;

  private normalizeChatLang(raw?: string | null): 'vi' | 'en' | 'id' {
    const clean = String(raw || '')
      .trim()
      .toLowerCase();
    if (clean === 'en') return 'en';
    if (clean === 'id' || clean === 'fr') return 'id';
    return 'vi';
  }

  private getChatCacheStorageKey(lang: 'vi' | 'en' | 'id'): string {
    return `ttc_srv_chat_v2_${lang}`;
  }

  private initChatChannelState() {
    try {
      const savedLang =
        typeof localStorage !== 'undefined' ? localStorage.getItem('tiemtraicay.lang') : 'vi';
      this.chatChannel = this.normalizeChatLang(savedLang);
    } catch {
      this.chatChannel = 'vi';
    }
    this.loadLocalChatCache('vi');
    this.loadLocalChatCache('en');
    this.loadLocalChatCache('id');
  }

  private loadLocalChatCache(lang: 'vi' | 'en' | 'id') {
    try {
      if (typeof localStorage === 'undefined') return;
      const raw = localStorage.getItem(this.getChatCacheStorageKey(lang));
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return;
      const valid = parsed
        .filter(
          (m) =>
            m &&
            typeof m === 'object' &&
            typeof m.id === 'string' &&
            typeof m.uid === 'string' &&
            typeof m.text === 'string' &&
            typeof m.createdAt === 'number' &&
            !this.isUidBanned(m.uid) &&
            !this.isUidHiddenFromLeaderboard(m.uid),
        )
        .slice(-60);
      if (valid.length > 0 && this.chatMessagesMap[lang].length === 0) {
        this.chatMessagesMap[lang] = valid;
      }
    } catch {}
  }

  private saveLocalChatCache(lang: 'vi' | 'en' | 'id') {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') return;
    const list = (this.chatMessagesMap[lang] || []).slice(-60);
    window.setTimeout(() => {
      try {
        localStorage.setItem(this.getChatCacheStorageKey(lang), JSON.stringify(list));
      } catch {}
    }, 0);
  }

  getChatMessages(_lang?: 'vi' | 'en' | 'id') {
    return [];
  }

  syncChatChannelWithGameLang(rawLang?: string | null) {
    const target = this.normalizeChatLang(rawLang);
    if (this.chatChannel !== target) {
      this.chatChannel = target;
    }
  }

  setChatChannel(rawLang: string) {
    const next = this.normalizeChatLang(rawLang);
    this.chatChannel = next;
    this.pauseChatRealtimeListeners();
    this.emit();
  }

  cycleChatChannel(): 'vi' | 'en' | 'id' {
    const order: Array<'vi' | 'en' | 'id'> = ['vi', 'en', 'id'];
    const idx = order.indexOf(this.chatChannel);
    const next = order[(idx + 1) % order.length];
    this.setChatChannel(next);
    return next;
  }

  getChatCooldownRemainingSeconds(): number {
    const remMs = this.chatCooldownUntil - Date.now();
    if (remMs <= 0) return 0;
    return Math.ceil(remMs / 1000);
  }

  private chatStartSeq = 0;

  pauseChatRealtimeListeners() {
    this.chatStartSeq++;
    while (this.chatUnsubs.length > 0) {
      const fn = this.chatUnsubs.pop();
      try {
        fn?.();
      } catch {}
    }
    this.chatListeningChannel = '';
  }

  startChatRealtime(_rawLang?: 'vi' | 'en' | 'id', _forceRestart = false) {
    // Tạm thời vô hiệu hóa Kênh Trò Chuyện và không sử dụng kết nối Realtime
    this.pauseChatRealtimeListeners();
  }

  private recomputeChatMessages(lang: 'vi' | 'en' | 'id') {
    const codeTag = lang.toUpperCase();
    const msgPrefix = `CH1_${codeTag}_`;
    const delPrefix = `CH_DEL_${codeTag}_`;
    const rawMap = this.rawChatMapByLang[lang] || {};
    const delMap = this.rawChatDelByLang[lang] || {};

    const deletedIds = new Set<string>();
    for (const delKey of Object.keys(delMap)) {
      if (delKey.startsWith(delPrefix)) {
        const msgId = delKey.slice(delPrefix.length).trim();
        if (msgId) deletedIds.add(msgId);
      }
    }

    const lbByUid = new Map<string, any>();
    for (const entry of this.leaderboard) {
      if (entry && entry.uid) lbByUid.set(entry.uid, entry);
    }

    const myUid = this.user?.uid || '';
    const isMeAdm = myUid ? this.isCurrentUserAdmin() : false;
    const isMeCre = myUid ? this.isCurrentUserCreator() : false;

    const parsedList: Array<{
      id: string;
      rawKey: string;
      channel: 'vi' | 'en' | 'id';
      uid: string;
      shopName: string;
      text: string;
      createdAt: number;
      level: number;
      isAdmin: boolean;
      isCreator: boolean;
      replyTo?: { id: string; shopName: string; text: string } | null;
    }> = [];

    for (const [fullKey, val] of Object.entries(rawMap)) {
      if (!fullKey.startsWith(msgPrefix)) continue;
      const uid = String(val || '').trim();
      if (!uid || uid.length < 6) continue;
      if (this.isUidBanned(uid) || this.isUidHiddenFromLeaderboard(uid)) continue;

      const body = fullKey.slice(msgPrefix.length);
      const firstDash = body.indexOf('-');
      if (firstDash <= 0) continue;
      const metaPart = body.slice(0, firstDash);
      const restPart = body.slice(firstDash + 1);
      const secondDash = restPart.indexOf('-');
      if (secondDash <= 0) continue;
      const shopHex = restPart.slice(0, secondDash);
      const msgHex = restPart.slice(secondDash + 1);

      const metaTokens = metaPart.split('_');
      if (metaTokens.length < 2) continue;
      const ts = parseInt(metaTokens[0] || '0', 10) || 0;
      const uidShort = metaTokens[1] || '';
      if (!ts || ts < 1700000000000 || !uidShort || uid.slice(0, 6) !== uidShort) continue;

      const msgId = `m_${ts}_${uidShort}`;
      if (deletedIds.has(msgId)) continue;

      const level = Math.max(1, Math.min(1000, parseInt(metaTokens[2] || '2', 10) || 2));
      const admFlag = parseInt(metaTokens[3] || '0', 10) || 0;
      const creFlag = parseInt(metaTokens[4] || '0', 10) || 0;

      const shopName = _decHex(shopHex).trim().slice(0, 28) || 'Tiệm Trái Cây';
      const rawDecoded = _decMsgHex(msgHex);
      let replyTo: { id: string; shopName: string; text: string } | null = null;
      let rawBodyText = rawDecoded;
      if (rawDecoded.startsWith('^R|')) {
        const nlIdx = rawDecoded.indexOf('\n');
        if (nlIdx > 3) {
          const header = rawDecoded.slice(3, nlIdx);
          const parts = header.split('|');
          const rShop = (parts[1] || 'Tiệm Trái Cây').trim().slice(0, 24);
          const rText = (parts[2] || '').trim().slice(0, 50);
          if (rText) {
            replyTo = {
              id: (parts[0] || '').trim().slice(0, 32),
              shopName: rShop || 'Tiệm Trái Cây',
              text: rText,
            };
          }
          rawBodyText = rawDecoded.slice(nlIdx + 1);
        }
      }
      const text = rawBodyText
        .replace(/[\r\n\t]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 160);
      if (!text) continue;

      const lbMatch = lbByUid.get(uid);
      const isAdmin =
        admFlag === 1 ||
        (myUid === uid && isMeAdm) ||
        (lbMatch ? this.isEntryAdmin(lbMatch) : false);
      const isCreator =
        creFlag === 1 ||
        (Boolean(this.creatorUid) && uid === this.creatorUid) ||
        (myUid === uid && isMeCre) ||
        (lbMatch ? this.isEntryCreator(lbMatch) : false);

      parsedList.push({
        id: msgId,
        rawKey: fullKey,
        channel: lang,
        uid,
        shopName,
        text,
        createdAt: ts,
        level,
        isAdmin,
        isCreator,
        replyTo,
      });
    }

    parsedList.sort((a, b) => a.createdAt - b.createdAt || a.id.localeCompare(b.id));
    const latest60 = parsedList.slice(-60);
    this.chatMessagesMap[lang] = latest60;
    this.saveLocalChatCache(lang);
  }

  async sendChatMessage(
    _rawText: string,
    _explicitLevel?: number,
    _replyTo?: { id?: string; shopName?: string; text?: string } | null,
  ): Promise<boolean> {
    return false;
  }

  private async _disabledSendChatMessage(
    rawText: string,
    explicitLevel?: number,
    replyTo?: { id?: string; shopName?: string; text?: string } | null,
  ): Promise<boolean> {
    if (this.chatMaintenance) {
      this.bridge?.notify('Admin đang bảo trì Kênh Trò Chuyện, vui lòng quay lại sau nha!', 'bad');
      return false;
    }
    if (!this.user || this.isCurrentAccountBanned || this.isUidBanned(this.user.uid)) {
      this.bridge?.notify('Vui lòng đăng nhập tài khoản để tham gia Kênh Trò Chuyện!', 'bad');
      return false;
    }
    if (this.isUidHiddenFromLeaderboard(this.user.uid)) {
      this.bridge?.notify('Tài khoản của bạn hiện đang bị hạn chế nhắn tin trên kênh chung!', 'bad');
      return false;
    }
    if (this.chatSending) return false;

    const shop = this.getShopSnapshot();
    const level = Math.max(1, Math.floor(Number(explicitLevel || shop.level || 1)));
    if (level < 2) {
      this.bridge?.notify('Tiệm cần đạt Cấp độ 2 trở lên mới có thể nhắn trên Kênh Trò Chuyện nha!', 'bad');
      return false;
    }

    const remSec = this.getChatCooldownRemainingSeconds();
    if (remSec > 0) {
      this.bridge?.notify(`Vui lòng đợi ${remSec} giây nữa trước khi gửi tin nhắn tiếp theo nha!`, 'info');
      return false;
    }

    const cleanText = String(rawText || '')
      .replace(/[\r\n\t]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 140);

    if (!cleanText) {
      return false;
    }

    const uid = this.user.uid;
    const uidShort = uid.slice(0, 6);
    const lang = this.chatChannel;
    const codeTag = lang.toUpperCase();
    const ts = Math.max(Date.now(), this.getServerNow());
    const shopName =
      (shop.shopName || this.user.displayName || 'Tiệm Trái Cây').trim().slice(0, 26) ||
      'Tiệm Trái Cây';
    const isAdm = this.isCurrentUserAdmin() ? 1 : 0;
    const isCre = this.isCurrentUserCreator() ? 1 : 0;
    const day = Math.max(1, Math.floor(Number(shop.day || 1)));
    const money = Math.max(0, Math.round(Number(shop.money || 0)));

    let encodedBody = cleanText;
    if (replyTo && replyTo.text) {
      const rId = String(replyTo.id || '')
        .replace(/[\r\n|]/g, '')
        .trim()
        .slice(0, 28);
      const rShop =
        String(replyTo.shopName || 'Tiệm Trái Cây')
          .replace(/[\r\n|]/g, ' ')
          .trim()
          .slice(0, 20) || 'Tiệm Trái Cây';
      const rText = String(replyTo.text || '')
        .replace(/[\r\n|]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 42);
      if (rText) {
        encodedBody = `^R|${rId}|${rShop}|${rText}\n${cleanText}`;
      }
    }

    const shopHex = _encHex(shopName);
    const msgHex = _encMsgHex(encodedBody);
    const rawKey = `CH1_${codeTag}_${ts}_${uidShort}_${level}_${isAdm}_${isCre}_${day}_${money}-${shopHex}-${msgHex}`;

    this.chatSending = true;
    this.chatCooldownUntil = Date.now() + 3000;
    if (typeof window !== 'undefined') {
      window.setTimeout(() => {
        this.emit();
      }, 3050);
    }

    // Cập nhật tức thì (Optimistic UI) để người gửi thấy tin nhắn ngay lập tức
    this.rawChatMapByLang[lang][rawKey] = uid;
    this.recomputeChatMessages(lang);
    this.emit();

    try {
      await set(ref(rtdb, `refCodes/${rawKey}`), uid);

      // Tự động dọn các khóa tin nhắn cũ vượt quá 60 tin của chính người chơi để giữ RTDB gọn nhẹ
      const allKeys = Object.keys(this.rawChatMapByLang[lang] || {}).sort();
      if (allKeys.length > 60) {
        const overflowKeys = allKeys.slice(0, allKeys.length - 60);
        for (const oldK of overflowKeys) {
          if (this.rawChatMapByLang[lang][oldK] === uid) {
            delete this.rawChatMapByLang[lang][oldK];
            set(ref(rtdb, `refCodes/${oldK}`), null).catch(() => undefined);
          }
        }
      }
      return true;
    } catch {
      delete this.rawChatMapByLang[lang][rawKey];
      this.recomputeChatMessages(lang);
      this.bridge?.notify('Chưa gửi được tin nhắn, vui lòng kiểm tra mạng rồi thử lại nha!', 'bad');
      return false;
    } finally {
      this.chatSending = false;
      this.emit();
    }
  }

  async deleteChatMessage(msg: {
    id: string;
    rawKey: string;
    channel: 'vi' | 'en' | 'id';
    uid: string;
  }): Promise<boolean> {
    if (!this.user || !msg || !msg.id) return false;
    const myUid = this.user.uid;
    const isAdmin = this.isCurrentUserAdmin();
    if (!isAdmin) return false;

    const lang = this.normalizeChatLang(msg.channel || this.chatChannel);
    const codeTag = lang.toUpperCase();
    const delKey = `CH_DEL_${codeTag}_${msg.id}`;

    delete this.rawChatMapByLang[lang][msg.rawKey];
    this.rawChatDelByLang[lang][delKey] = myUid;
    this.recomputeChatMessages(lang);
    this.emit();

    try {
      const tasks: Array<Promise<any>> = [];
      if (myUid === msg.uid && msg.rawKey) {
        tasks.push(set(ref(rtdb, `refCodes/${msg.rawKey}`), null).catch(() => undefined));
      }
      tasks.push(set(ref(rtdb, `refCodes/${delKey}`), myUid).catch(() => undefined));
      await Promise.all(tasks);
      return true;
    } catch {
      return false;
    }
  }
}

export const ttcCloud = new TtcCloudManager();
if (typeof window !== 'undefined') {
  (window as any).__TTC_CLOUD = ttcCloud;
}

export function getImmuneLotteryTime(): number {
  return ttcCloud.getServerNow();
}

export function getLotteryState(periodSeconds = 1200) {
  return ttcCloud.getLotteryState(periodSeconds);
}
