const fs = require('fs');
const line166 = fs.readFileSync('src/game.js', 'utf8').split('\n')[165];
const fishStart = line166.indexOf('var FISH_TABLE');
const coupleStart = line166.indexOf('function CoupleModal');
const code = line166.slice(fishStart, coupleStart);

let stack = [];
let inStr = false;
let quoteChar = '';
for (let i = 0; i < code.length; i++) {
  let ch = code[i];
  if (inStr) {
    if (ch === '\\') { i++; continue; }
    if (ch === quoteChar) { inStr = false; }
    continue;
  }
  if (ch === '"' || ch === "'" || ch === '`') {
    inStr = true;
    quoteChar = ch;
    continue;
  }
  if (ch === '(' || ch === '{' || ch === '[') {
    stack.push({ ch, i });
  } else if (ch === ')' || ch === '}' || ch === ']') {
    let expected = ch === ')' ? '(' : ch === '}' ? '{' : '[';
    if (!stack.length || stack[stack.length - 1].ch !== expected) {
      console.log('Mismatch at', i, 'char', ch, 'stack top:', stack[stack.length - 1]);
    } else {
      stack.pop();
    }
  }
}
console.log('Unclosed stack items:', stack);
stack.forEach(s => {
  console.log('Unclosed', s.ch, 'at', s.i, ':', code.slice(Math.max(0, s.i - 30), Math.min(code.length, s.i + 60)));
});
